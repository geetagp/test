// Component: Dashboard
// Author : Gita
// Description : This is dashboard component that has sidebar and details component that displays information about the project

'use strict'
import React from 'react';
import {Nav, Navbar, NavItem, Badge, NavDropdown, MenuItem, Tab, Row, Col, ButtonToolbar, DropdownButton} from 'react-bootstrap';
import Dumps from '../pages/dumps.js';
import Pods from '../pages/pods.js';

class Dashboard extends React.Component {

    constructor(props) {
        super(props);
        this.state = {showContent: 'overview'};
    }

    selectedSideBarOption(option)
    {
        this.state = {showContent: option};
        //Gita : use this.setState to re-render component for selected option from sidebar
        this.setState({}) ;
    }

    render() {
        var partial;
        if(this.state.showContent === "overview"){
            partial = <Pods/>
        }
        else{
            partial = <Dumps/>
        }
        return (
            <div>
                <div id="sidebar-wrapper">
                    <ul className="sidebar-nav">
                        <li>
                            <a href="#" onClick={this.selectedSideBarOption.bind(this, 'overview')}>Overview</a>
                        </li>
                        <li>
                            <a href="#" onClick={this.selectedSideBarOption.bind(this, 'applications')}>Applications</a>
                        </li>
                        <li>
                            <a href="#">Builds</a>
                        </li>
                        <li>
                           <a href="#">Settings</a>
                        </li>
                        <li>
                            <a href="#">Resources</a>
                        </li>
                        <li>
                            <a href="#">Storage</a>
                        </li>
                    </ul>
                </div>
                <div id="content">
                    {partial}
                </div>
            </div>
        );
    }
}
export default Dashboard
