// Component: Create Settings
// Author : Gita
// Description : Create Settings form diplays project on-boarding components 

'use strict'
import React from 'react';
import {reduxForm, Field} from 'redux-form';
import {connect} from 'react-redux';
import {Grid, Row, Col} from 'react-bootstrap';
import {submitCreateSettings} from '../../actions/create_settings.js';
import { browserHistory } from 'react-router';

const required = value => (value ? undefined : 'Required')
const alphaNumeric = value =>
  value && /[^a-zA-Z0-9 ]/i.test(value)
    ? 'Only alphanumeric characters'
    : undefined

       
const renderFieldText= ({
    input,
    label,
    type,
    description,
    invalidMessage,
    meta: { touched, error, warning , pristine}
    }) => (
    <div>
        <label className='ecp-property-label'>{label}</label>
        <div className='inputText'>
            <input {...input} placeholder={label} type={type} className='form-control'/>
            {touched && ((error && <span>{error}</span>) || (warning && <span>{warning}</span>))} 
        </div>
        <div className='help-block'>{description}</div>

    </div>
);

const renderFieldCheckbox = ({
    input,
    label,
    type,
    description,
    invalidMessage,
    meta: { touched, error, warning }
    }) => (
    <div>
        <label className='ecp-property-label'>{label}</label>
        <div >
            <label className="ecp-option">
                <input {...input} type={type} className='ecp-option'/> 
                <span >{description}</span>
            </label>
        </div>
    </div>
);

const renderFieldRadio = ({
    input,
    label,
    type,
    description
    }) => (
    <div>
        <label className='ecp-property-label'>{label}</label>
        <div className='help-block'>{description}</div>
        <div>
            <label className="ecp-option">
                <input type={type} className='ecp-option'  name="region" value='internet' checked/> 
                Internet
            </label>
             <label className="ecp-option">
                <input type={type} className='ecp-option'  name="region" value='intranet'/> 
                Intranet
            </label>
        </div>
         
    </div>
);



class CreateSettings extends React.Component {
    constructor(props) {
        super(props);
    } 

    handleFormSubmit(values){
        //console.log('here are values' + values.projectName);
        //console.log('here are values' + this.props);
        this.props.submitCreateSettings(values);
    }

    //Gita: handle cancel button
    handleCancelBtn() {
        //console.log('handle cancel btn');
        browserHistory.push('/projects');
    }

    render() {
        const {handleSubmit, pristine,  submitting, invalid}=this.props;
        return (
            <div className="col-md-12">
                <h1>General</h1>
                <form className="ecp-settings" onSubmit={handleSubmit(this.handleFormSubmit.bind(this))}>
                    <fieldset className="form-group">
                        <Field
                            name="projectName"
                            type="text"
                            component={renderFieldText}
                            label="Project Name"
                            description="A unique name for the project."
                            validate={[required]}
                            warn={alphaNumeric}
                            invalidMessage="***"
                    />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="aimid"
                            type="text"
                            component={renderFieldText}
                            label="AIM ID"
                            description="Learn more about CAR (Central Asset Registry)."
                            validate={[required]}
                            warn={alphaNumeric}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="businessJustification"
                            type="textarea"
                            component={renderFieldText}
                            label="Business Justification"
                            description="Enter business justification for project."
                            validate={[required]}
                            warn={alphaNumeric}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="description"
                            type="text"
                            component={renderFieldText}
                            label="Project Description"
                            description="An American Express application."
                            validate={[required]}
                            warn={alphaNumeric}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="members"
                            type="list"
                            component={renderFieldText}
                            label="Members"
                            description= "Members' ADS ids, separated by commas."
                            validate={[required]}
                            warn={alphaNumeric}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="workgroupName"
                            type="text"
                            component={renderFieldText}
                            label="Workgroup Name"
                            description= "Enter Service Now Workgroup Name here if you plan to promote your application to E2."
                            validate={[required]}
                            warn={alphaNumeric}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="region"
                            type="radio"
                            component={renderFieldRadio}
                            label="Application Type"
                            description= 'On-boarding internet applications'
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="pii"
                            type="checkbox"
                            component={renderFieldCheckbox}
                            label="Personal Identifiable Information"
                            description= 'Application requires access to downstream systems with personal identifiable information (PII) like customer names, social security numbers, etc.'
                            validate={[required]}
                            warn={alphaNumeric}
                        />
                    </fieldset>
                    
                    <button action="submit" className="btn btn-primary" disabled={invalid || pristine || submitting}>Create</button>
                    <button onClick={this.handleCancelBtn.bind(this)} className="btn btn-secondary">Cancel</button>
                </form>
            </div>
        );
    }
}

function mapStateToProps(state){
    return {errorMessage: state.auth.error};
}

export default reduxForm({
    form: 'createSettingsForm' // a unique identifier for this form
})(
    connect(mapStateToProps,  {submitCreateSettings: submitCreateSettings})(CreateSettings)
);

