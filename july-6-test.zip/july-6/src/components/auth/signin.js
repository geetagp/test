// Component: Signin 
// Author : Gita
// Description : This component displays signin info for user to sign in to tickr application 

import React, {Component} from 'react';
import {reduxForm, Field} from 'redux-form';
import {connect} from 'react-redux';
//import * as actions from '../../actions/create_settings.js';
import {signinUser} from '../../actions/index.js';
import {Grid,Col,Row,Button} from 'react-bootstrap';

//const renderInput=field=><input {...field.input} type={field.type} className="form-control" />;

const required = value => (value ? undefined : 'Required')
const alphaNumeric = value =>
  value && /[^a-zA-Z0-9 ]/i.test(value)
    ? 'Only alphanumeric characters'
    : undefined


const renderField = ({
  	input,
  	label,
 	type,
 	meta: { touched, error, warning, prestine }
	}) => (
  	<div>
    	<label>{label}</label>
        <div className='inputText'>
     		<input {...input} placeholder={label} type={type} className="form-control"/>
      		{touched && ((error && <span>{error}</span>) || (warning && <span>{warning}</span>))} 
      	</div>
    </div>
);

class SignIn extends Component{

	handleFormSubmit({username,password}){
		console.log(username,password);
		this.props.signinUser({username,password});
	}
	renderAlertSignIn(){
		if(this.props.errorMessage){
			return(
				<div className="alert alert-danger">
					<strong>Oops!</strong> {this.props.errorMessage}
				</div>
				);
		}
	}
	render(){
		const {handleSubmit}=this.props;
		return(
			<Grid>
			    <Row>
			        <div>
			   			<div className='signinMsg'><span > Please enter your <font color="red"> <strong>Network (Active Directory) </strong></font> username and password. </span></div>
			  	 		<div id='signinForm'>
			  	 	   	 	<p className='loginTitle'> <strong>User Login </strong></p>
							<form onSubmit={handleSubmit(this.handleFormSubmit.bind(this))}>
								<fieldset className="form-group">
									<Field
       		 							name="username"
        								type="text"
        								component={renderField}
        								label="Username"
        								validate={[required]}
        								warn={alphaNumeric}
        								class="form-control"
      								/>
      							</fieldset>
      							<fieldset className="form-group">
									<Field
        								name="password"
        								type="password"
        								component={renderField}
        								label="Password"
        								validate={[required]}
       									warn={alphaNumeric}
       									class="form-control"
      								/>
      							</fieldset>
								{this.renderAlertSignIn()}
								<button action="submit" className="btn btn-primary loginButton">Login</button>
							</form>
						</div>
					</div>
				</Row>
			</Grid>
		);
	}
}

function mapStateToProps(state){
	return {errorMessage: state.auth.error};
}

export default reduxForm({
	form: 'signin'
})(
	//connect(mapStateToProps,actions)(SignIn)
	connect(mapStateToProps,  {signinUser: signinUser})(SignIn)
);
