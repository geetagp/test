// submitCreateSettings Actions
// Author : Gita
import axios from 'axios';
import { browserHistory } from 'react-router';

const ROOT_URL = 'http://localhost:3000';

export function submitCreateSettings(values) {
    return function(dispatch) {

    // Submit email/password to the server
    axios.post(`${ROOT_URL}/api/v3/epaas/projects`, values)
        .then(response => {
        // Redirect to the route '/projects'
        console.log('in submit create settings success');
        browserHistory.push('/projects');
      })
      .catch((error) => {
        // If request is bad...
        // Show an error to the user
        console.log('in submit create settings error' + error);
        //browserHistory.push('/projects');

        if (error && error.status === 401 && error.statusText === 'Unauthorized') {
            errorMessage =  'Your session has expired. Redirecting to login ...';
            var modifiedError = { status: 'error' };
            console.log('status error');

        } else {
            
        }
  }); 

  }
}

