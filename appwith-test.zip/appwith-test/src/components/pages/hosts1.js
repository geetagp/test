// Component: BookItem
// Author : Gita
// BookItem component displays book details of each book
// dispatches addToCart and updateCart actions

"use strict"
import React from 'react';
import {Row, Col, Well, Button} from 'react-bootstrap';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {addToCart,updateCart} from '../../actions/cartActions';
import { TablePagination } from 'react-pagination-table';

class Hosts1 extends React.Component{

    render(){



        const data = [
            { name:"lpdospea00967.phx.aexp.com", ip: "10.16.190.245",role:"<a href='/contact'>to be defined </a>" },
            { name:"lpdospea00968.phx.aexp.com", ip: "10.16.190.243", role:"to be defined"},
            { name:"lpdospea00946.phx.aexp.com", ip: "10.16.190.267", role:"to be defined"},
            { name:"lpdospea00943.phx.aexp.com" , ip: "10.16.190.290", role:"to be defined"},
            { name:"lpdospea00970.phx.aexp.com", ip: "10.16.190.278", role:"to be defined" },
            { name:"lpdospea00979.phx.aexp.com", ip: "10.16.190.890" , role:"to be defined"}
        ];


        //Table header
        const Header = ["Name", "Role", "IP" ];

        /*return (<div>
            <TableSimple
                title="TableSimple"
                subTitle="Sub Title"
                data={ data }
                headers={ Header }
                //Tell the component what order you wanna render.
                columns="name.ip.role"
                arrayOption={ [["size", 'all', ', ']] }
            />
        </div>);*/

        return (<div>
            <TablePagination
                title="Hosts1"
                subTitle=""
                headers={ Header }
                data={ data }
                columns="name.ip.role"
                perPageItemCount={ 5 }
                totalCount={ data.length }
                arrayOption={ [["size", 'all', ' ']] }
            />
        </div>);

    }
}


function mapStateToProps(state){
    return{
        cart:state.cart.cart
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({addToCart:addToCart,updateCart:updateCart}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(Hosts1);
