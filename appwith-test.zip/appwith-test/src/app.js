'use strict'
import {applyMiddleware, createStore} from 'redux';    //Gita: applyMiddleware is used for redux-logger, some task to do (e.g display logs for state in dev env) before reducers change the state of app
import logger from 'redux-logger';
import React from 'react';
import {render} from 'react-dom';
import {Provider} from 'react-redux';  // Gita : Provider wraps the react application and passes the store to the react app. this is how redux communicates with react
import './styles/style.scss';
import './styles/pagination.scss';

//IMPORT COMBINE REDUCERS
import reducers from './reducers/index.js';

// IMPORT ACTIONS
//import {addToCart} from './actions/cartActions'
//import {postBooks, deleteBooks, updateBooks} from './actions/booksActions'

// STEP 1 create the store
const middleware = applyMiddleware(logger); // Gita : pass logger to applymiddleware - use this only in development env
const store = createStore(reducers, middleware); // Gita: create store with middleware , you will be able to see logs as prev state, action dispatched and next state

// no neeed to subscribe if you are using middleware with logger such as redux-logger
//store.subscribe(function(){
    //console.log('current state is ', store.getState());
//})


// import Component
import BooksList from './components/pages/booksList.js';
import Cart from './components/pages/cart.js';
import BooksForm from './components/pages/booksForm.js';
import Main from './main.js';
import About from './components/about.js';
import Contacts from './components/contacts.js';
import Hosts from './components/pages/hosts.js';
import Hosts1 from './components/pages/hosts1.js';

// Router
import {Router, Route, IndexRoute, browserHistory} from 'react-router';


// Gita : with Provider wrap - any component in the application can access store / app state
const Routes = (
    <Provider store={store}>
        <Router history={browserHistory}>
            <Route path='/' component={Main}>
                <IndexRoute component={Hosts1}/>
                <Route path='/admin' component={BooksForm}/>
                <Route path='/cart' component={Cart}/>
                <Route path='/about' component={About}/>
                <Route path='/contacts' component={Contacts}/>
            </Route>
        </Router>
    </Provider>
);

render(
    Routes, document.getElementById('app')
);
