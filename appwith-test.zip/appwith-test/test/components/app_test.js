import { renderComponent, expect } from '../test_helper';
import Contacts from '../../src/components/contacts';

describe('Contacts', () => {
    let component;

    beforeEach(() => {
        component = renderComponent(Contacts);
    });
    it('Contacts Exists', () => {
        expect(component).to.exist;
    });
});
