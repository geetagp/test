// Component: Footer
// Author : Gita
// Description : This is display only component, that forms the footer 

'use strict'
import React from 'react';

class Footer extends React.Component {
    render() {
        return (
            <footer className='footer'>
                <p className='footer-text'> AXP Internal</p>
            </footer>
        );
    }
}
export default Footer
