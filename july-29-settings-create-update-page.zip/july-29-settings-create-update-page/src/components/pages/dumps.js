// Component: Pods
// Author : Gita
// Description : This is display only component, that forms the footer of single page app

'use strict'
import React from 'react';
import {Nav, Navbar, NavItem, Badge, NavDropdown, MenuItem, Tab, Row, Col} from 'react-bootstrap';

class Dumps extends React.Component {
    render() {
        return (
            <div>
            <p>this is dumps</p>

            </div>
        );
    }
}
export default Dumps
