// Component: Create Project 
// Author : Gita
// Description : Create Project form allows user to create new project

'use strict'
import React from 'react';
import {Grid, Row, Col} from 'react-bootstrap';
import UpdateSettings from '../pages/update_settings.js';

class UpdateProject extends React.Component {
    constructor(props) {
        super(props);
    } 

    render() {
        return (

            <Grid>
                <Row>
                    <div className="middle">

                        {/*<div class="ecp-form-notification" ng-if="formService.data.status.message" className="{'ecp-error':!formService.data.status.success, 'ecp-success':formService.data.status.success}">*/}


                        {/* help icon */}
                        <a className="ecp-page-help" href="https://enterprise-confluence.aexp.com/confluence/x/lWNkC" target="blank">
                            <span title="Help" className="fa pficon-help" aria-hidden="true"></span>
                        </a>

                        <div className="projects-header">
                            <div className="projects-bar">
                                <h2>Project Settings</h2>
                            </div>
                            <UpdateSettings/>
                        </div>
                    </div>
                </Row>
            </Grid>
        );
    }
}
export default UpdateProject
