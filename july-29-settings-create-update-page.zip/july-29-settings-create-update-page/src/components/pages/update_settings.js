// Component: Create Settings
// Author : Gita
// Description : Create Settings form diplays project on-boarding components 

'use strict'
import React from 'react';
import {reduxForm, Field} from 'redux-form';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux'; // to dispatch action from react component
import {Grid, Row, Col} from 'react-bootstrap';
import {submitCreateSettings} from '../../actions/create_settings.js';
import {resetResponse} from '../../actions/response_action.js';
import { browserHistory } from 'react-router';

const required = value => (value ? undefined : 'Required')

const alphaNumeric = value =>
  value && /[^a-zA-Z0-9 ]/i.test(value)
    ? 'Only alphanumeric characters'
    : undefined

const minLength = min => value =>
  value && value.length < min ? `Must be ${min} characters or more` : undefined
const minLength1 = minLength(2)

const maxLength = max => value =>
  value && value.length > max ? `Must be ${max} characters or less` : undefined
const maxLength63 = maxLength(63)

export const projectNameVal = value =>
  value && !/^[a-z0-9]([-a-z0-9]*[a-z0-9])?$/i.test(value)
    ? 'Project names may only contain lower-case letters, numbers and dashes (-). Can not start or end with a dash.'
    : undefined

export const membersVal = value =>
  value && !/^[a-zA-Z0-9](([a-zA-Z0-9]+\\.[a-zA-Z0-9]+\\,\\ *)|([a-zA-Z0-9]*\\,\\ *))*(([a-zA-Z0-9]+\\.[a-zA-Z0-9]+\\ *)|([a-zA-Z0-9]*\\ *))$/i.test(value)
    ? 'Members should contain valid ADS ids and must be separated by commas.'
    : undefined

       
const renderFieldText= ({
    input,
    label,
    type,
    description,
    invalidMessage,
    meta: { touched, error, warning , pristine, dirty}
    }) => (
    <div>
        <label className='ecp-property-label'>{label}</label>
        <div className='inputText'>
            <input {...input} placeholder={label} type={type} className='form-control'/>
            {touched && ((error && <span>{error}</span>) || (warning && <span>{warning}</span>))} 
        </div>
        {/* Gita: display description only if no error, else display error */}
        {!(error && dirty ) && <div className='help-block'>{description}</div>} 
        <div className="help-block ecp-error-message">{invalidMessage}</div>

    </div>
);

const renderFieldCheckbox = ({
    input,
    label,
    type,
    description,
    invalidMessage,
    meta: { touched, error, warning }
    }) => (
    <div>
        <label className='ecp-property-label'>{label}</label>
        <div className="ecp-options">
            <label>
                <input {...input} type={type} className="ecp-option"/> 
                <span >{description}</span>
            </label>
        </div>
         <div className="help-block ecp-error-message">{invalidMessage}</div>
    </div>
);

const renderFieldRadio = ({
    input,
    label,
    type,
    description,
    invalidMessage,
    }) => (
    <div>
        <label className='ecp-property-label'>{label}</label>
        <div className='help-block'>{description}</div>
        <div className="ecp-options">
            <label>
                <input type={type}  className="ecp-option" name="region" value='dedicated_internet' defaultChecked={true}/> 
                <span> Internet </span>
            </label>
             <label>
                <input type={type} className="ecp-option"  name="region" value='intranet'/> 
                <span> Intranet </span>
            </label>
        </div>
         <div className="help-block ecp-error-message">{invalidMessage}</div>
         
    </div>
);


class UpdateSettings extends React.Component {
    constructor(props) {
        super(props);
    } 

    handleFormSubmit(values){
        this.props.submitProjectSettings(values);
    }

    //Gita: handle cancel button
    handleCancelBtn() {
        browserHistory.push('/projects');
    }
    //Gita: handle close button
    handleCloseBtn() {
        this.props.resetResponse();
    }

    //Gita: disaply error or success
    renderSubmitResponse(){
        if(this.props.responseMessage && this.props.responseMessage.success === true){
            return(
                <div className="ecp-form-notification ecp-success">
                    <span className="ecp-message">{this.props.responseMessage.message}</span>
                    <span className="ecp-remove-button" onClick={this.handleCloseBtn.bind(this)}>&#10005;</span>
                </div>
                );
        }
        else {
            if(this.props.responseMessage && this.props.responseMessage.success === false){
            return(
                <div className="ecp-form-notification ecp-error">
                    <span className="ecp-message">{this.props.responseMessage.message}</span>
                    <span className="ecp-remove-button" onClick={this.handleCloseBtn.bind(this)}>&#10005;</span>
                </div>
                );
        }
        }
    }

    render() {
        
        const {handleSubmit, pristine,  submitting, invalid}=this.props;
        return (

            <div className="col-md-12">

                {this.renderSubmitResponse()}

                <h1>General</h1>
                <form className="ecp-settings" onSubmit={handleSubmit(this.handleFormSubmit.bind(this))}>
                    <fieldset className="form-group">
                        <Field
                            name="projectName"
                            type="text"
                            component={renderFieldText}
                            label="Project Name"
                            description="A unique name for the project."
                            validate={[required, minLength1, maxLength63, projectNameVal]}
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['projectName']}
                    />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="aimid"
                            type="text"
                            component={renderFieldText}
                            label="AIM ID"
                            description="Learn more about CAR (Central Asset Registry)."
                            validate={[required]}
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['aimid']}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="businessJustification"
                            type="textarea"
                            component={renderFieldText}
                            label="Business Justification"
                            description="Enter business justification for project."
                            validate={[required]}
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['businessJustification']}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="description"
                            type="text"
                            component={renderFieldText}
                            label="Project Description"
                            description="An American Express application."
                            validate={[required]}
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['description']}

                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="members"
                            type="list"
                            component={renderFieldText}
                            label="Members"
                            description= "Members' ADS ids, separated by commas."
                            validate={[required]}
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['members']}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="workgroupName"
                            type="text"
                            component={renderFieldText}
                            label="Workgroup Name"
                            description= "Enter Service Now Workgroup Name here if you plan to promote your application to E2."
                            validate={[required]}
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['workgroupName']}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="region"
                            type="radio"
                            component={renderFieldRadio}
                            label="Application Type"
                            description= 'On-boarding internet applications'
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['region']}
                        />
                    </fieldset>
                    <fieldset className="form-group">
                        <Field
                            name="pii"
                            type="checkbox"
                            component={renderFieldCheckbox}
                            label="Personal Identifiable Information"
                            description= 'Application requires access to downstream systems with personal identifiable information (PII) like customer names, social security numbers, etc.'
                            validate={[required]}
                            invalidMessage={this.props.responseMessage && this.props.responseMessage.validation && this.props.responseMessage.validation['pii']}
 
                        />
                    </fieldset>
                    
                    <button action="submit" className="btn btn-primary" disabled={invalid || pristine || submitting}>Update</button>
                    {/*<button onClick={this.handleCancelBtn.bind(this)} className="btn btn-secondary">Cancel</button> */}
                </form>
            </div>
        );
    }
}


function mapStateToProps(state) {
    return {errorMessage: state.auth.error,responseMessage: state.response.result};
}

// Gita: to dispatch action from react component
function mapDispatchToProps(dispatch) {
    // Gita : pre-binding the action creators to redux store
    return bindActionCreators({submitCreateSettings, resetResponse}, dispatch);
}


// Gita: export with connect for access for state props and dispatch
// this is where react component gets connected to redux store
export default reduxForm({
    form: 'createSettingsForm' // a unique identifier for this form
    // initialValues:{'pii' :true, region:'intranet'}
})(
    connect(mapStateToProps, mapDispatchToProps)(UpdateSettings)
);

