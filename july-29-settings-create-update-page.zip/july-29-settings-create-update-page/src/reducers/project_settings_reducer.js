// Response Reducer
// Author : Gita

export function responseReducer(state = {}, action) {
  switch (action.type) {
    case 'GET_PPROJECT_SETTINGS':
      return { ...state, result: action.payload };
    case 'GET_PPROJECT_SETTINGS_ERROR':
      return { ...state, result: {} };
  }
  return state;
}
