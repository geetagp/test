// Response Actions
// Author : Gita
'use strict'

// reset 
export function resetResponse()  {
    return {
        type:'RESET_MSG'
    }
}

// get 
export function getResponse()  {
    return {
        type:'GET_MSG'
    }
}