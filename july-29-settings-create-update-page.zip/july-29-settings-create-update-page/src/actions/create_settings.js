// submitCreateSettings Actions
// Author : Gita
import axios from 'axios';
import { browserHistory } from 'react-router';

const ROOT_URL = 'http://localhost:3000';

export function submitCreateSettings(values) {
    return function(dispatch) {
    var errorMessage = 'Error occurred creating project.';    
    var successMessage = 'Settings created successfully.';

    // Submit email/password to the server
    axios.post(`${ROOT_URL}/api/v3/epaas/projects`, values)
        .then(response => {       

        // Gita: TBD : successHandler function
        if (response.status === 'success') {
            var result = {
                success: true,
                message: successMessage || 'Success.',
                data: response.data
            };

            //dispatch suceess message 
            dispatch({type:'GET_MSG', payload:result})
        }
        else{
            console.log('Unexpected error occured');
        }

        browserHistory.push('/projects');
      })
      .catch((error) => {
        // If request is bad...
        // Show an error to the user

        // Gita: TBD : errorHandler function
        if (error && error.status === 401 && error.statusText === 'Unauthorized') {
            errorMessage =  'Your session has expired. Redirecting to login ...';
            var modifiedError = { status: 'error' }; 
        } 

        if (!error) {
            error = {
                status: false,
                data: false,
                message: false
            };
        }


        error = error.data ? error.data : error;  // get response for error 

        //set sample error 
        //var error = {   status : "fail", data: { aimid: "Invalid aim id is detected.", region: "Invalid region id is detected.", pii: "Invalid pii is detected."} };
        //end of set sample error 

        var messageFromAPI         = typeof error === 'string' ? error : error.message || (error.data && error.data.message);
        var messageFormValidation  = error.status === 'fail' || error.status === 'Failure' ? 'One or more fields are invalid, correct and try again.' : false;


        console.log(messageFromAPI);
        console.log(messageFormValidation);

        var result  = {
            success: error.status === 'success' && !service.isSessionExpired(error),
            message: messageFromAPI || messageFormValidation || errorMessage || '1337: An unknown error occurred.',
            validation: error.data || []
        };
        //dispatch suceess message 
        dispatch({type:'GET_MSG', payload:result})

    }); 
  }
}

