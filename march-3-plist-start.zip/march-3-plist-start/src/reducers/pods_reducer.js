// Pods Reducer
// Author : Gita

'use strict'
export function podsReducer( state = {pods:[
    {
        id: "1",
        name: "pod 1",
        status: "Succeeded",
        projectName: "Project_1"
    },
    {
        id: "2",
        name: "pod 2",
        status: "Failed",
        projectName: "Project_2"
    },
    {
        id: "3",
        name: "pod 3",
        status: "Running",
        projectName: "Project_3"
    }

    ]}, action) {

    switch (action.type) {

        case 'GET_PODS':
            return {...state, pods:[...state.pods] }
            break;

    }

    return state;
}
