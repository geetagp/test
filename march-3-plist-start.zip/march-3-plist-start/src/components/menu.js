// Component: Menu
// Author : Gita
// Description : This is display only component, that forms the header/menu

'use strict'
import React from 'react';
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import { Link } from 'react-router';
import {getProjects} from '../actions/projects_action';
import {getPods} from '../actions/pods_action';

class Menu extends React.Component {

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        console.log('projects component did mount ');
        this.props.getProjects();
    }

    onProjectClick(item, e) {  
        this.props.getPods();
    }

    createProjectOptions() {
        let items = [];         
        for (let i = 0; i < this.props.projects.length ; i++) {   
            let item =  this.props.projects[i];
            let boundProjectClick = this.onProjectClick.bind(this, item);         
            //items.push(<li key={i}><a href='/tickr'>{this.props.projects[i].name}</a></li>);
            items.push(<li key={i}><a href='javascript:void(0)' onClick={boundProjectClick}>{this.props.projects[i].name}</a></li>);
        }
        return items;
    }  

   renderLinksUser()
    {
        if (this.props.authenticated) {
            return  <li className="dropdown">
                        <a className="dropdown-toggle ecp-dropdown-toggle" data-toggle="dropdown" href="/signout"><span className="fa fa-user" aria-hidden="false"></span>gpawar<span className="caret"></span></a>
                        <ul className="dropdown-menu">
                            <li> <a href='/signout'>Logout</a></li>
                        </ul>
                    </li>
                
        } 
    }
    renderLinksEnv()
    {
        if (this.props.authenticated) {
            return  <li className="dropdown">
                        <a className="dropdown-toggle ecp-dropdown-toggle" data-toggle="dropdown" href="/signout"><span className="fa fa-sitemap" aria-hidden="false"></span>E1<span className="caret"></span></a>
                        <ul className="dropdown-menu">
                            <li> <a href='/signout'>E1</a></li>
                            <li> <a href='/signout'>E2</a></li>
                            <li> <a href='/signout'>E3 IPC1</a></li>
                            <li> <a href='/signout'>E3 IPC2</a></li>
                        </ul>
                    </li>
                
        } 
    }
    renderLinksHelp()
    {
        if (this.props.authenticated) {
            // fa fa-question-circle glyphicon glyphicon-wrench
            return  <li className="dropdown">
                        <a className="dropdown-toggle ecp-dropdown-toggle" data-toggle="dropdown" href="/signout"><span className="fa fa-question-circle" aria-hidden="false"></span><span className="caret"></span></a>
                        <ul className="dropdown-menu">
                            <li> <a href='/signout'>Documentation</a></li>
                            <li> <a href='/signout'>Customer Testimonials</a></li>
                            <li> <a href='/signout'>Release Notes</a></li>
                            <li> <a href='/signout'>Contact Us</a></li>
                        </ul>
                    </li>
                
        } 
    }

    renderLinksTools()
    {
        if (this.props.authenticated) {
            return  <li className="dropdown">
                        <a className="dropdown-toggle ecp-dropdown-toggle" data-toggle="dropdown" href="/signout"><span className="glyphicon glyphicon-wrench" aria-hidden="false"></span><span className="caret"></span></a>
                        <ul className="dropdown-menu">
                            <li> <a href='/signout'>Release</a></li>
                            <li> <a href='/signout'>Monitoring - Grafana</a></li>
                            <li> <a href='/signout'>Logging</a></li>
                        </ul>
                    </li>
                
        } 
    }
    // TBD : change to index html to import js libraries to make projects dropdown work 
    renderLinksProjects()
    {
        if (this.props.authenticated) {
            // show a dropdown with projects list
            return  <li id='ecp-projects-dropdown' className="dropdown">
                        <a className="dropdown-toggle ecp-dropdown-toggle" data-toggle="dropdown" href="#"> Projects  <span id="ecp-projects-dropdown-caret" className="caret pull-right"></span></a>
                        <ul className="dropdown-menu">
                            {this.createProjectOptions()}
                        </ul>
                    </li>

        } 
    }

    renderLinksAddToProject()
    {
        if (this.props.authenticated) {
            return  <li >
                        <a className="project-addto-btn"  href="/signout">Add to Project</a>
                    </li>
                
        } 
    }

    renderLinksHome()
    {
        if (this.props.authenticated) {
            return  <li className="dropdown">
                        <a className="dropdown-toggle ecp-dropdown-toggle" data-toggle="dropdown" href="/signout"><span className="fa fa-home" aria-hidden="false"></span></a>
                    </li>
                
        } 
    }

    renderLinksXpaas()
    {
        if (this.props.authenticated) {
            return  <li className="dropdown">
                        <a className="dropdown-toggle ecp-dropdown-toggle" data-toggle="dropdown" href="/signout"><span className="glyphicon glyphicon-list-alt" aria-hidden="false"></span></a>
                    </li>
                
        } 
    }

    render() {
        return (
            <nav className="navbar navbar-inverse navbar-fixed-top">
            <div className="container-fluid">
            <div className="navbar-header"> 
                <a className="navbar-brand ecp-logo" href="#">
                    <img src="../assets/ecp-logo-64.png"/>
                    <div className="text">eCP Console</div>
                </a>
            </div>
            <ul className="nav navbar-nav">

            </ul>
            <ul className="nav navbar-nav navbar-right">
                {this.renderLinksHome()}
                {this.renderLinksXpaas()}
                {this.renderLinksTools()}
                {this.renderLinksHelp()}
                {this.renderLinksEnv()}
                {this.renderLinksUser()}
            </ul>
            </div>
            </nav>
        );
    }
}

//   authenticated: state.auth.authenticated
function mapStateToProps(state) {
    return {
        authenticated: state.auth.authenticated,
        projects: state.projects.projects
    };
}

//function mapDispatchToProps(dispatch){
//    return bindActionCreators({getProjects: getProjects}, dispatch);
//}
//, getPods: getPods
function mapDispatchToProps(dispatch){
    return bindActionCreators({getProjects: getProjects, getPods: getPods}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Menu);







