// Component: Pods
// Author : Gita
// Description : display pods information in table

"use strict"
import React from 'react';
import {Row, Col, Well, Button, Table, FormControl, FormGroup, ControlLabel, Pagination, Modal } from 'react-bootstrap';
import {findDOMNode} from 'react-dom';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
//import {getPods} from '../../actions/pods_action';


class Pods extends React.Component {

	constructor(props) {
        super(props);
    }

	componentDidMount() {
        //this.props.getPods();
    }

    render() {
        return (
            <div id="pods-table">
                <div>
                    <Table responsive className='table table-bordered table-hover table-mobile table-layout-fixed'>
                        <colgroup>
                            <col className='col-sm-4'/>
                            <col className='col-sm-3'/>
                        </colgroup>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Generate Heap</th>
                                <th>Generate Thread</th>
                                <th>Get GC</th>
                                <th>Select Pod</th>
                                <th>Collect Dumps</th>
                                <th>Provide RFC#</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.pods.length === 0 ? '' : this.renderResultRows()}
                        </tbody>
                    </Table>
                </div>
                <div> 
                    <button className="btn btn-md btn-primary">Reset Pod</button> 
                    <button className="btn btn-md btn-primary">Collect Dump</button> 
                </div>
            </div>
        );
    }

    renderResultRows = () => {
        return this.props.pods.map((pod, index) => {
            return (
                <tr key={index} data-item={pod} >
                    <td data-title='Name'>{pod.name}</td>
                    {this.renderStatus(pod.status)}
                    <td><span><i className='fa fa-check'></i> </span></td>
                    <td><span><i className='fa fa-check'></i> </span></td>
                    <td><span><i className='fa fa-check'></i> </span></td>
                    {this.renderRadio(pod.name)}
                    {this.renderCheckbox(pod.name)}
                    {this.renderText(pod.name)}
                </tr>
            );
        });
    }

    renderStatus = (status) => {
        switch (status) {
            case 'Running':
                return <td><span><i className='fa fa-refresh'></i> {status}</span></td>
            case 'Succeeded':
                return <td><span><i className='fa fa-check text-success'></i> {status}</span></td>
            case 'Failed':
                return <td><span><i className='fa fa-times text-danger'></i> {status}</span></td>
        }
    }

    renderRadio = (name) => {
        let radioId = 'select_' + name ;
        let boundPodClick = this.onRadioClick.bind(this, name); 
        return <td><input type='radio' value={name} name='selectPod' id={radioId} href='javascript:void(0)' onClick={boundPodClick}/></td>
    }

    onRadioClick = (item, e) => {
        console.log('in radio click' + item);
    }

    renderCheckbox = (name) => {
        let checkboxId = 'dump_' + name ;
        return <td><input type='checkbox' id={checkboxId} value={name} /></td>
    }

    renderText = (name) => {
        return <td><input type='text' name='provideRFC'/></td>
    }
}    

//function mapStateToProps(state) {
//    return {
//        pods: state.pods.pods
//    }
//}

//function mapDispatchToProps(dispatch){
//    return bindActionCreators({getPods: getPods}, dispatch);
//}
//export default connect(mapStateToProps, mapDispatchToProps)(Pods)

function mapStateToProps(state) {
    return {
        pods: state.pods.pods
    }
}

export default connect(mapStateToProps)(Pods)




