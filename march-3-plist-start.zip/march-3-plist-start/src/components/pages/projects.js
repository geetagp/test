// Component: Projects List
// Author : Gita
// Description : The projects list is displayed to user upon successful login 

'use strict'
import React from 'react';
import {Nav, Navbar, NavItem, Badge, NavDropdown, MenuItem, Tab, Grid, Row, Col, ButtonToolbar, DropdownButton} from 'react-bootstrap';

// <i className="fa fa-ellipsis-v" aria-hidden="true"></i> 
class Projects extends React.Component {

    constructor(props) {
        super(props);
    }
    render() {
        
        return (
            <Grid>
                <Row>
                    <div className="middle">

                        <button className="btn btn-md btn-primary pull-right ecp-create-project-btn">Create Project</button>

                        <div className="projects-header">
                            <div className="projects-bar">
                                <h1>Multi-application Projects</h1>
                            </div>

                            <div className="list-group list-view-pf projects-list">
                                <div>
                                project 1
                                </div>

                                <div className="dropdown">
                                <a className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fa fa-ellipsis-v" aria-hidden="true"/>
                                </a>
                                <ul className="dropdown-menu" role="menu">
                                <li role="menuitem"> Edit</li>
                                </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </Row>
            </Grid>
        );
    }
}
export default Projects
