// App.js
// Author : Gita

'use strict'
import {applyMiddleware, createStore} from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';
import React from 'react';
import {render} from 'react-dom';
import {Provider} from 'react-redux';
import './styles/style.scss';
import './styles/overrides.scss';
import reducers from './reducers/index.js';
import Dashboard from './components/pages/dashboard.js';
import Main from './main.js';
import Signin from './components/auth/signin.js';
import Pods from './components/pages/pods.js';
import Projects from './components/pages/projects.js';

const middleware = applyMiddleware(thunk, logger);
const store = createStore(reducers, middleware);

import {Router, Route, IndexRoute, browserHistory} from 'react-router';

const Routes = (
    <Provider store={store}>
        <Router history={browserHistory}>
            <Route path='/' component={Main}>
                <IndexRoute component={Signin}/>
                <Route path='/signout' component={Signin}/>
                <Route path='/projects' component={Projects}/>
                <Route path='/dashboard' component={Dashboard}/>
                <Route path='/pods' component={Pods}/>
            </Route>
        </Router>
    </Provider>
);

render(
    Routes, document.getElementById('app')
);
