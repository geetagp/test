import React from 'react';
import {
  Paper, Button, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions
} from '@material-ui/core';
import styled from 'styled-components';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';

const Wrapper = styled.div`
  padding: 0 24px 24px 24px;
  color: #333;

  .schedule-wrapper {
    display: flex;

    > div {
      width: calc(50% - 96px);
      display: flex;
      // flex: 1;
      // padding: 24px 48px;
      flex-direction: column;
    }

    .schedule-left {
      padding: 24px 0 24px 64px;
      width: calc(50% - 64px);

      h3 {
        padding-right: 128px;
      }
    }

    .schedule-right {
      padding: 24px 64px;
      width: calc(50% - 128px);
    }
  }

  .schedule-info {
    padding-right: 128px;
    border-right: solid 2px #006fcf;

    li {
      margin-bottom: 20px;
    }
  }
`;
const date = new Date();

export default function ScheduleRenewal ({setRenewalDate, renewalDate, selectedCerts}) {
  const [openConfirmModal, setOpenConfirmModal] = React.useState(false);
  const hasCertsSelected = selectedCerts.length;

  const handleClose = () => {
    setOpenConfirmModal(false);
  }

  return (
    <Wrapper>
      <Paper elevation={3}>
        <div className="schedule-wrapper">
          <div className="schedule-left">
            <h3>Things to consider before scheduling your certificate renewal</h3>
            <ul className="schedule-info">
              <li>Certificates are ordered by earliest expiration date in E3 followed by certificates in other environments</li>
              <li>Remember to re-deploy your application for renewed E1 certificate to be effective</li>
              <li>Remember to promote your application to E2 or E3 for renewed E2 or E3 certificates to be effective</li>
              <li>Did you know you can view all certificates that need reneweal for a specific application - Here is how you can group them by application name</li>
              <li>When scheduling deployment or promotion of your renewed certificates, make sure to pick a date before certificate(s) expiration date</li>
            </ul>
          </div>
          <div className="schedule-right">
            <h3>Deploy certificates renewal</h3>
            <div style={{maxWidth: 350, flex: 1}}>
              <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <KeyboardDatePicker
                  disableToolbar
                  variant="inline"
                  format="MM/dd/yyyy"
                  margin="normal"
                  id="date-picker"
                  label="Select renewal date"
                  value={renewalDate}
                  onChange={setRenewalDate}
                  KeyboardButtonProps={{
                    'aria-label': 'change date',
                  }}
                  minDate={date.setDate(date.getDate())}
                />
              </MuiPickersUtilsProvider>
            </div>
            <div style={{alignSelf: 'flex-end'}}>
              <Button
                variant="contained"
                color="primary"
                size="large"
                disabled={!hasCertsSelected || !renewalDate}
                onClick={e => setOpenConfirmModal(true)}
              >Renew</Button>
            </div>
          </div>
        </div>
      </Paper>
      <Dialog open={openConfirmModal} onClose={handleClose}>
        <DialogTitle>Certificate Renewal Submitted</DialogTitle>
        <DialogContent>
          <DialogContentText>{`Your attempt to renew certificate for ${hasCertsSelected && selectedCerts[0].name} application in ${hasCertsSelected && selectedCerts[0].environment} is applied.`}</DialogContentText>
          <DialogContentText>For certificate renewal to take immediate effect, you must re-deploy and promote your application.</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Okay, got it.
          </Button>
          <Button onClick={handleClose} color="primary">
            Re-deploy in XLR
          </Button>
        </DialogActions>
      </Dialog>
    </Wrapper>
  )
}
