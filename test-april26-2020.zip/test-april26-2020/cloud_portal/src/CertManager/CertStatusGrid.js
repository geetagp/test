import React from 'react';
import { MdSchedule } from 'react-icons/md';
import { TiInputChecked } from 'react-icons/ti';
import MUIDataTable from 'mui-datatables';
import styled from 'styled-components';
import { Button } from '@material-ui/core';

const Wrapper = styled.div`
  padding: 24px;
  flex: 1;
  display: flex;
  flex-direction: column;

  tr {
    > th:first-child, > td:nth-child(2) { padding-left: 30px; }
  }
`;

const tableHeadData = [
  { name: 'serviceName', label: 'Application' },
  { name: 'projectName', label: 'Project' },
  { name: 'env', 
    label: 'Certificate environment',
    options: {
      customBodyRender: env => env.toUpperCase()
    },
  },
];

export default function CertStatusGrid (props) {
  const { certificates } = props;
  const scheduledData = certificates.filter(cert => (cert.renewStatus  === 'install_pending'));
  const completedData = certificates.filter(cert => (cert.renewStatus === 'installed'));

  return (
    <Wrapper>
      <div style={{ marginBottom: 16 }}>
        Scheduled / Completed Installations
        <Button
          color="primary"
          style={{marginLeft: 60}}
          href="/certificate-manager">
          View Dashboard
        </Button>
      </div>  

      <div style={{ marginBottom: 32 }}>
        <MUIDataTable
          columns={tableHeadData}
          data={scheduledData}
          title={(
            <div style={{
              display: 'flex',
              alignItems: 'center',
            }}>
            <MdSchedule style={{
                  marginRight: 5,
              }}
            />
              Scheduled Installations
            </div>
          )}
          options={{
            selectableRows: 'none',
            search: false,
            print: false,
            download: false,
            viewColumns: false,
          }}
        />
      </div>

      <div style={{ marginBottom: 32 }}>
        <MUIDataTable
          columns={tableHeadData}
          data={completedData}
          title={(
            <div style={{
              display: 'flex',
              alignItems: 'center',
            }}>

            <TiInputChecked style={{
                  marginRight: 5,
              }}
            />
              Completed Installations
            </div>
          )}
          options={{
            selectableRows: 'none',
            search: false,
            print: false,
            download: false,
            viewColumns: false,
          }}
          style={{
            boxShadow: '0px 3px 3px -2px rgba(0,0,0,0.2), 0px 3px 4px 0px rgba(0,0,0,0.14), 0px 1px 8px 0px rgba(0,0,0,0.12)'
          }}
        />
      </div>
    </Wrapper>
  )
}
