import React from 'react';
import Header from '../App/Header';
import { Button, IconButton, Typography, Menu, MenuItem, Link} from '@material-ui/core';
import { FaUserCircle } from 'react-icons/fa';
import { FiLogOut } from 'react-icons/fi';

const helpLink = 'https://enterprise-confluence.aexp.com/confluence/display/ED/Certificate+Renewal+Manager+FAQ';

export default function CertRenewalHeader ({user, host, resetModel}) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleMenu = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleClose();
    resetModel();
  }
  const logoutRedirectURL = "https://" + host;

  return (
    <div>
      <Header
        title="Certificate Renewal Manager"
        showMenuToggle={false}
        icon={
          <img
            src={`${process.env.PUBLIC_URL}/ecp-logo.png`}
            style={{
              marginRight: 20,
              width: 'auto',
              height: 32,
            }}
            alt="eCP Logo"
          />
        }
        rightContent={
          <div style={{ color: '#fff' }}>
            <Button
              href={helpLink}
              target="_blank"
              style={{
                fontSize: '1.1rem',
                borderRight: '1px solid #fff',
                marginRight: 12,
                paddingRight: 28,
                color: '#fff',
                textTransform: 'none',
                borderRadius: 0,
              }}
            >
              Help &amp; Support
            </Button>
            <IconButton
              style={{
                color: '#fff',
              }}
              onClick={handleMenu}>
              <FaUserCircle color="#fff" style={{ marginRight: 12 }} />
              {
                !user ? null : <Typography style={{ fontSize: '1.1rem' }}>{user}</Typography>
              }
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'center',
              }}
              getContentAnchorEl={null}
              keepMounted
              open={open}
              onClose={handleClose}
            >
              <MenuItem>
                <FiLogOut style={{ marginRight: 6 }} />
                <Link href={logoutRedirectURL}>Logout</Link>
              </MenuItem>
            </Menu>
          </div>
        }
        style={{background: 'rgb(0, 23, 90)'}}
      />
    </div>
  )
}
