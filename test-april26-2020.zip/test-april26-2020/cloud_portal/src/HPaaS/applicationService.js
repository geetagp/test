let host = window.location.host;
//e1 and e2
let apiHost = 'v5apieng1-dev.aexp.com';
if (host.includes('qa1-dev')) {
  apiHost = 'v5apiqa1-dev.aexp.com';
} else{
  if (host.includes('prod-dev')) { 
    apiHost = 'v5apiprod-dev.aexp.com';
  } else {
    if (host.includes('prod-qa')) { 
      apiHost = 'v5apiprod-qa.aexp.com';
    }
  }
}
//e3
if (host.includes('eng1.aexp')) {
  apiHost = 'v5apieng1.aexp.com';
} else{
  if (host.includes('qa1.aexp')) { 
    apiHost = 'v5apiqa1.aexp.com';
  } else{
    if (host.includes('prod.aexp')) { 
      apiHost = 'v5apiprod.aexp.com';
    }
  }
}

const APPLICATION_API_URL =  'https://' + apiHost + '/services';

export const fetchApplications = async () => {

  return new Promise(async (res, rej) => {
    return await fetch(APPLICATION_API_URL)
      .then(res => res.json())
      // .then(data => !data.data || data.status === 'error' ? res([JSON.parse(data.message)]) : res(data.data))
      .then(data => res(data))
      .catch(err => rej(err));
  });

}

export const createApplication = async (formData) => {

  return new Promise(async (res, rej) => {
    return await fetch(APPLICATION_API_URL, {
      method: 'POST',
      body: JSON.stringify(formData),
      // headers: {
      //   Authorization: `Bearer ${token}`,
      // }
    })
      .then(res => res.json())
      //.then(data => !data.data || data.status === 'error' ? res([JSON.parse(data.message)]) : res(data.data))
      .then(data => res(data))
      .catch(err => rej(err));
  });

}

export const fetchApplication = async (id) => {
  // console.log('fetchWorkspace', id);
  
  return new Promise(async (res, rej) => {

    return await fetch(`${APPLICATION_API_URL}/${id}`)
      .then(res => res.json())
      .then(data => res(data))
      // .then(data => !data.data || data.status === 'error' ? res([JSON.parse(data.message)]) : res(data.data))
      .catch(err => rej(err));

  });

}

export const fetchApplicationsByWorkSpace = async (projectUID) => {
  
  return new Promise(async (resolve, reject) => {

    return await fetch(`${APPLICATION_API_URL}?workspaceId=${projectUID}`)
      .then(res => res.json())
      .then(data => resolve(data))
      // .then(data => !data.data || data.status === 'error' ? res([JSON.parse(data.message)]) : res(data.data))
      .catch(err => reject(err));

  });

}

export const updateApplication = async (formData) => {
  return new Promise(async (resolve, reject) => {

    return await fetch(`${APPLICATION_API_URL}/${formData.serviceUID}`, {
      method: 'PUT',
      body: JSON.stringify(formData),
      headers: {
        'Content-Type': 'application/json'
      },
    })
    .then(res => {
      if (res.status === 204) {
        resolve(true);
      }
      console.log(res);
    })
      // .then(res => res.json())
      // .then(data => res(data))
      // .then(data => !data.data || data.status === 'error' ? res([JSON.parse(data.message)]) : res(data.data))
      .catch(err => reject(err));
  
  });

}



