import { fetchApplications, createApplication, fetchApplication, updateApplication, fetchApplicationsByWorkSpace } from './applicationService';
import history from '../App/history';

const initialState = {
  applications: [],
  application: {},
  user: '',
  token: '',
  host: '',
  hasAuth: false,
  checkedAuth: false,
  response: {},
};

const model = {
  state: { ...initialState },

  reducers: {
    storeApplications: (state, applications) => ({
      ...state,
      applications,
      hasAuth: true,
    }),
    storeApplication: (state, application) => ({
      ...state,
      application,
      hasAuth: true,
    }),
    storeParams: (state, params) => ({
      ...state,
      ...params,
    }),
    resetModel: (state) => ({...initialState}),
    setCheckedAuth: (state, checkedAuth) => ({ ...state, checkedAuth }),
    setResponse: (state, response) => ({ ...state, response }),
  },

  effects: dispatch => ({
    async getApplications(payload, state) {
        const applicationsResponse = await fetchApplications();
        if (applicationsResponse && applicationsResponse.status === "success") {
          dispatch.applications.storeApplications(applicationsResponse.data);
        } else {
          // handle error here
          console.log('error fetching applications');
        }
    },

    async getApplicationsByWorkspace(workspaceId, state) {
      const applicationsResponse = await fetchApplicationsByWorkSpace(workspaceId);
      if (applicationsResponse && applicationsResponse.status === "success") {
        dispatch.applications.storeApplications(applicationsResponse.data);
      } else {
        // handle error here
        console.log('error fetching applications');
      }
    },

    async getApplication(payload, state) {
      const applicationRes = await fetchApplication(payload);
      
      //dispatch.application.storeApplication(require('./localdata/application.json').data);
      if (applicationRes && applicationRes.status === "success") {
        dispatch.application.storeApplication(applicationRes.data);
      } else {
        // handle error here
        console.log('error fetching application');
        //dispatch.application.storeApplication(require('./localdata/application.json').data);
      }
    },

    async submitCreateAppicationForm(payload, state) {
      const applicationResponse = await createApplication(payload);
      let applicationRes = {};
        
      //check for success
      if (applicationResponse && applicationResponse.status === "success") {
        applicationRes = {
          "status": applicationResponse.status,
          "message": "Application created successfully.",
        };
        history.push(`/hpaas/workspace/${payload.projectUID}`);
        history.go(`/hpaas/workspace/${payload.projectUID}`);
      }

      //check for error 
      if (applicationResponse && applicationResponse.status === "fail") {
        let errorsObj = applicationResponse.errors ;
        let message = Object.keys(errorsObj)[0]+ ": " + errorsObj[Object.keys(errorsObj)[0]]; 

        applicationRes = {
          "status": applicationResponse.status ,
          "message": message,
        };
      }

      dispatch.application.resetModel();
      dispatch.application.setResponse(applicationRes);

    },

    async submitEditApplicationForm(payload, state) {
      const applicationResponse = await updateApplication(payload);
      let applicationRes = {};
    
      if (applicationResponse) {
        dispatch.application.getApplication(payload.serviceUID)
        applicationRes = {
          "status": "success",
          "message": "Application updated successfully.",
        };
        dispatch.application.resetModel();
        dispatch.application.setResponse(applicationRes);
      } else {
        // handle error here.
      }
    },
  })
}

export default model;
