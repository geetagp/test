import React, { Fragment, useEffect } from 'react';
import {Grid, Typography, TextField, Select, Checkbox, FormControl, InputLabel, FormControlLabel, Tooltip, IconButton, Toolbar} from '@material-ui/core';
import Divider from '@material-ui/core/Divider';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import { Link } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { useForm, Controller } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import styled from 'styled-components';

import { TopBar, TopBarActions } from './styledComponents';
import { HtmlTooltip } from './EditWorkspaceForm';

const Wrapper = styled.div`
  // padding: 12px;
  display: flex;
  flex-grow: 1;
  flex: 1;

  .form-info {
    padding: 0 40px 0 0;
  }
`;

const FormElementWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: row;
  margin-bottom: 5px;

  > :first-child {
    max-width: calc(100% - 64px);
  }
`;

export default function CreateWorkspaceForm(props) {
  const response = props.response;
  const dispatch = useDispatch();
  const { control, register, handleSubmit, watch, errors, triggerValidation, formState } = useForm({
    reValidateMode: 'onBlur',
    mode: 'onBlur',
    validateCriteriaMode: "firstErrorDetected",
    submitFocusError: true,
    nativeValidation: false,
  })
  const onSubmit = data => dispatch.wspace.submitCreateWorkspaceForm({
    ...data,
    clusters: ['cluster_for_non_pii_services', 'cluster_for_pii_services'],
    status: 'pending',
    name: data.projectName,
  });

  const displayResponse = (response) => {
    switch(response.status) {
      case "success":   return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>{response.message}</span>;
      case "fail":   return <span style={{ color: 'red', fontSize: 12, fontWeight: 600}}>{response.message}</span>;
      default: return <span></span>
    }
  }

  useEffect(() => {
    dispatch.wspace.setResponse('');
  }, []);

  return (
    <Wrapper>
      <Grid container>
        <Grid item xs={12}>
          <form onSubmit={handleSubmit(onSubmit)}>
            <TopBar>
              <Breadcrumbs separator="›" aria-label="breadcrumb">
                <Link color="inherit" href="/hpaas/dashboard">
                  Dashboard
                </Link>
                <Typography color="textPrimary">Create Workspace</Typography>
              </Breadcrumbs>
              <TopBarActions>
                <Typography variant="h6">
                  Create Workspace 
                </Typography>
                <Typography variant="subtitle1">
                  {displayResponse(response)}
                </Typography>
                <Button variant="contained" color="primary" spacing={2} type="submit" disabled={!formState.isValid}>
                  Create
                </Button>
                <Button variant="contained" color="default" href="/hpaas/dashboard">
                  Cancel
                </Button>
              </TopBarActions>
            </TopBar>

            <Divider light align="bottom" style={{marginBottom: 20}} />

            <div style={{padding: '0 12px 12px'}}>
              <Grid container>
              <Grid item xs={12} md={4} xl={3}>
                <div className="form-info">
                  <Typography variant="subtitle1">
                    General Information 
                  </Typography>
                  <Typography variant="caption">
                    General Information regarding workspace needs to be provided. 
                    AIM Director approval is required for creating a new workspace. 
                  </Typography>
                </div>
              </Grid>
              <Grid item xs={12} md={8} xl={9}>

                <Typography variant="subtitle1">
                  Enter following details to create new workspace 
                </Typography>
                <FormElementWrapper>
                  <Controller
                    as={<TextField />}
                    control={control}
                    defaultValue=""
                    inputRef={register}
                    rules={{
                      required: {
                        value: true,
                        message: 'Workspace name is required.',
                      },
                      maxLength: {
                        value: 63,
                        message: 'Workspace Name name should be max 63 char',
                      },
                      minLength: {
                        value: 3,
                        message: 'Workspace Name name should be min 3 char',
                      },
                      pattern: {
                        value: /^[a-z0-9]([-a-z0-9]*[a-z0-9])?$/,
                        message: `Workspace names may only contain lower-case letters, numbers and dashes (-). Can't start or end with a dash.`
                      }
                    }}
                    error={errors.hasOwnProperty('projectName')}
                    helperText={errors.hasOwnProperty('projectName') && errors.projectName.message}
                    name="projectName"
                    id="projectName"
                    placeholder="Enter Workspace Name"
                    label="* Workspace Name"
                    margin="dense"
                    fullWidth
                  />

                  <HtmlTooltip interactive
                    title={
                    <Fragment>
                    <Typography color="inherit">Workspace Name</Typography>
                      <em>{"A unique name of a workspace"}</em> 
                    </Fragment>
                    }
                    >
                    <Button size="small">?
                    </Button>
                  </HtmlTooltip>
                </FormElementWrapper>

                <FormElementWrapper>
                  <Controller
                    as={<TextField />}
                    control={control}
                    defaultValue=""
                    inputRef={register}
                    rules={{
                      required: {
                        value: true,
                        message: 'AIM ID is required.',
                      },
                      pattern: {
                        value: /[0-9]/,
                        message: `AIM ID should contain only numbers.`
                      },
                      pattern: {
                        value: /^\d{9}$/,
                        message: `AIM ID should contain exactly 9 digits.`
                      },
                    }}
                    error={errors.hasOwnProperty('aimID')}
                    helperText={errors.hasOwnProperty('aimID') && errors.aimID.message}
                    name="aimID"
                    id="aimID"
                    placeholder="Enter AIMID"
                    label="* AIM ID"
                    margin="dense"
                    fullWidth
                  />

                  <HtmlTooltip interactive
                    title={
                    <Fragment>
                    <Typography color="inherit">AIM ID </Typography>
                    <em>{"Learn more about CAR (Central Asset Registry)"}</em> <a href='https://square.americanexpress.com/docs/DOC-55683' target='_blank'>here</a>
                    </Fragment>
                    }
                    >
                    <Button>?</Button>
                  </HtmlTooltip>
                </FormElementWrapper>

                <FormElementWrapper>
                  <Controller
                    as={<TextField />}
                    control={control}
                    defaultValue=""
                    inputRef={register}
                    rules={{
                      required: {
                        value: true,
                        message: 'Business Justification is required.',
                      },
                      maxLength: {
                        value: 253,
                        message: 'Business Justification should be max 253 char.',
                      },
                      minLength: {
                        value: 20,
                        message: 'Business Justification should be min 20 char.',
                      },
                    }}
                    error={errors.hasOwnProperty('businessJustification')}
                    helperText={errors.hasOwnProperty('businessJustification') && errors.businessJustification.message}
                    multiline
                    rows={2}
                    name="businessJustification"
                    id="businessJustification"
                    placeholder="Enter Business Justification"
                    label="* Business Justification"
                    margin="dense"
                    fullWidth
                  />
                </FormElementWrapper>

                <FormElementWrapper>
                  <Controller
                    as={<TextField />}
                    control={control}
                    defaultValue=""
                    inputRef={register}
                    rules={{
                      required: {
                        value: true,
                        message: 'Members are required.',
                      },
                    }}
                    error={errors.hasOwnProperty('members')}
                    helperText={errors.hasOwnProperty('members') && errors.members.message}
                    name="members"
                    id="members"
                    placeholder="Members"
                    label="* Members"
                    margin="dense"
                    fullWidth
                  />
                
                  <HtmlTooltip interactive
                    title={
                      <Fragment>
                        <Typography color="inherit">Members </Typography>
                        <em>{"Members' ADS ids, should be separated by commas"}</em> 
                      </Fragment>
                    }>
                    <Button>?</Button>
                  </HtmlTooltip>
                </FormElementWrapper>

                <FormElementWrapper>
                  <Controller
                    as={<TextField />}
                    control={control}
                    defaultValue=""
                    inputRef={register}
                    rules={{
                      required: {
                        value: true,
                        message: 'Workspace description is required.',
                      },
                      maxLength: {
                        value: 253,
                        message: 'Workspace description should be max 253 char.',
                      },
                      minLength: {
                        value: 10,
                        message: 'Workspace description should be min 10 char.',
                      },
                    }}
                    error={errors.hasOwnProperty('description')}
                    helperText={errors.hasOwnProperty('description') && errors.description.message}
                    name="description"
                    id="description"
                    placeholder="Enter Workspace Description"
                    label="* Workspace Description"
                    margin="dense"
                    fullWidth
                  />
                </FormElementWrapper>

                {/* <FormElementWrapper>
                  <FormControl fullWidth  style={{margin: '10px 0 15px 0'}}>
                    <InputLabel htmlFor="age-native-simple">* Cluster</InputLabel>
                    <Controller
                      as={(
                        <Select>
                          <option value='cluster_for_non_pii_services'>Cluster for Non-PII Services</option>
                          <option value='cluster_for_pii_services' disabled>Cluster for PII Services</option>
                        </Select>
                      )}
                      control={control}
                      defaultValue="cluster_for_non_pii_services"
                      inputRef={register}
                      rules={{
                        required: {
                          value: true,
                          message: 'Cluster is required.',
                        },
                      }}
                      error={errors.hasOwnProperty('clusters')}
                      native
                      value="cluster_for_non_pii_services"
                      id="clusters"
                      name="clusters"
                    />
                  </FormControl>
                  <HtmlTooltip interactive
                    title={
                      <Fragment>
                        <Typography color="inherit">Clusters </Typography>
                        <em>{"Cluster Information "}</em> <a href='' target='_blank'></a>
                      </Fragment>
                    }>
                    <Button>?</Button>
                  </HtmlTooltip>
                </FormElementWrapper>                 */}

              

              </Grid>
            </Grid>
            </div>
          </form>
        </Grid>
      </Grid>
    </Wrapper>
  )
}
  