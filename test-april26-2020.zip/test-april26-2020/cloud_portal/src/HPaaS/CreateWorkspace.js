import React, { useEffect, Fragment } from 'react';
import styled from 'styled-components';
import HPaaSHeader from './HPaaSHeader';
import CreateWorkspaceForm from './CreateWorkspaceForm';
import HPaaSFooter from './HPaaSFooter';
import { connect } from 'react-redux';

const Wrapper = styled.div``;

const CreateWorkspace = ({
  workspace,
  getWorkspaces,
  location,
  storeParams,
  user,
  resetModel,
  hasAuth,
  checkedAuth,
  host,
  response,
}) => {
  return (
    <Wrapper>
      <HPaaSHeader user='suser' host='localhost' resetModel='false' />
      <CreateWorkspaceForm response={response}/>
      <HPaaSFooter />
    </Wrapper>
  )
}

const mapProps = state => ({
  workspace: state.wspace.workspace,
  user: state.wspace.user,
  hasAuth: state.wspace.hasAuth,
  checkedAuth: state.wspace.checkedAuth,
  host: state.wspace.host,
  response: state.wspace.response,
})

const mapDispatch = dispatch => ({
  resetModel: dispatch.wspace.resetModel,
  setResponse: dispatch.wspace.setResponse,
  setCheckedAuth: dispatch.wspace.setCheckedAuth,
})

export default connect(mapProps, mapDispatch)(CreateWorkspace)

