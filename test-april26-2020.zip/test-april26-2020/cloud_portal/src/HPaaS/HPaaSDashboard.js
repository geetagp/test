import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { Button, Menu, MenuItem, Link, Card, CardContent } from '@material-ui/core';
import SortIcon from '@material-ui/icons/Sort';
import WorkspaceCard from './WorkspaceCard';
import { MdAddCircleOutline } from 'react-icons/md';

const useStyles = theme => ({
  root: {
    flexGrow: 1,
    padding: '0 24px 64px 24px',
    overflow: 'auto',
  },
  defaultRoot: {
    flexGrow: 1,
  },
  paper: {
    margin: 2,
    height: 100,
    width: 240,
  },
  createWsPaper: {
    margin: 6,
    marginTop: 6,
    height: 100,
    width: 240,
  },
  wsTitle:{
    paddingTop:20,
    paddingBottom:20
  },
  wsDetails:{
    marginTop: 8,
    marginLeft: 8,
  },
  wsDate:{
    marginTop: 22,
  },
  wsList:{
    listStyle: "none",
  },
  sideWsMenu:{
    marginTop: 8,
    marginRight: 4,
  },
  createWsButton:{
    marginTop: 22,
    marginLeft: 8,
    height: 40,
    color:"#006fcf",
    fontSize: 16,
    fontWeight: 600,
    textTransform: "none",
    backgroundColor: "#FFF",
    display: 'flex',
    "&:hover": {
        backgroundColor: "#FFF",
    }
  },
  defaultCreateWsPaper: {
    margin: 4,
    marginTop: 35,
    height: 100,
    width: 240,
  },
  defaultWsPaper: {
    margin: 4,
    marginTop: 60,
    height: 300,
    width: 1000,
  },
  messageLink: {
    textAlign: "center",
    top: 60,
  },
  img: {
    marginTop:5,
    textAlign: "center",
    top: 60,
  }
});

class HPaaSDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = { anchorEl: null, open:false, workspaces:[]};
  }

  render() {
    const { classes } = this.props;
    const { workspaces } = this.props;
    const noOfWorkspaces = (workspaces && workspaces.length > 0 ? workspaces.length : 0)
    const defaultLinks = [{'name':'Get Started', 'link':''}, {'name':'Whats new', 'link':''}, {'name':'Resources', 'link':''}, {'name':'Learn More', 'link':''}];

    const handleSortByDate = event => {
      workspaces.sort(custom_sort);
      this.setState({workspaces: workspaces});
    };

    function custom_sort(a, b) {
      return (new Date(b.creationTimestamp).getTime() - new Date(a.creationTimestamp).getTime());
    }

    if(noOfWorkspaces === 0) {  // no workpaces found for user, default page 
      return (    
        <div className={classes.defaultRoot} > 
          <Grid container spacing={1} justify="center"> {/* top container with image and message to take tour */}
            <Paper className={classes.defaultWsPaper} variant="outlined">
              <Grid container spacing={1} direction="column">
                  <Grid item className={classes.img}>
                    <img src={`${process.env.PUBLIC_URL}/platform.png`} style={{width: 'auto', height: 120}}/>
                  </Grid>
                  <Grid item>
                    <Typography variant="body2" className={classes.messageLink}>
                      You have no workspaces. Get started by <a href="/hpaas/workspace/create"> creating a new workspace </a> or take a <a href="/hpaas/workspace/create">tour of the dashboard </a> to learn more. 
                    </Typography>
                  </Grid>
              </Grid> 
              <Grid container spacing={1} justify="center">
                <Paper className={classes.defaultCreateWsPaper} variant="outlined">
                  <Grid container>
                    <Grid item>
                      <Button
                        href="/hpaas/workspace/create"
                        className={classes.createWsButton}
                        align="center" 
                        >
                        <Typography variant="subtitle1" align="center" className={classes.createWsButton} style={{ cursor: 'pointer' }}>
                            + Create New Workspace
                        </Typography>
                      </Button>
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            </Paper>
          </Grid>
          <Grid container spacing={1} justify="center"> {/* bottom container with 4 default buttons */}
            {defaultLinks.map((dl , i)=> (
              <Paper className={classes.createWsPaper} variant="outlined" key={dl.name.replace(/ /g, '-')}>
                <Grid container key={dl.name} > 
                  <Grid item >
                      <Button
                        href="/hpaas/workspace/create"
                        className={classes.createWsButton}
                        align="center" 
                      >
                        <Typography variant="subtitle1" align="center" className={classes.createWsButton} style={{ cursor: 'pointer' }}>
                          {dl.name}
                        </Typography>
                      </Button>
                    </Grid>
                  </Grid>
                </Paper>
                  ))}
          </Grid>
        </div>
      ) 
    } else { // user has existing workspaces  startIcon={<MdAddCircleOutline />}
      return (
      <div className={classes.root}>
        <Grid container spacing={1} justify="center"> 
          <Grid item xs>
            <Grid item className={classes.wsTitle} > 
              <Typography variant="h6" display="inline" className={classes.wsTitle}> Workspaces ({noOfWorkspaces})</Typography>
              <Typography variant="body2" color="textSecondary" display="inline" onClick={handleSortByDate} style={{ cursor: 'pointer' }}> <SortIcon onClick={handleSortByDate} style={{ cursor: 'pointer' }}></SortIcon> Sort by date created (Newest first)</Typography> 
            </Grid>
            <Grid container spacing={2}>   {/* container for all items , displaying create workspace first */}
              <Grid item xs={6} sm={4} lg={2}>
                <Card style={{height: '90%', border: '1px solid rgba(0,0,0,0.15)'}} elevation={0}>
                  <CardContent style={{display: 'flex', height: '100%', padding: 0}}>
                    <Button
                      style={{margin: 'auto'}}
                      href="/hpaas/workspace/create"
                      className={classes.createWsButton}
                      align="center"
                    >
                     + Create New Workspace
                    </Button>
                </CardContent>
                </Card>
              </Grid>
              {
                workspaces.map(ws => (
                  <Grid item xs={6} sm={4} lg={2} key={ws.projectUID}>
                    <WorkspaceCard workspace={ws} />
                  </Grid>
                ))
              }
            </Grid>
          </Grid>
        </Grid>
      </div>
      )}
    }
}
export default withStyles(useStyles)(HPaaSDashboard)