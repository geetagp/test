import React from 'react';
import Header from '../App/Header';
import { Button, IconButton, Typography, Menu, MenuItem, Link, Avatar, Badge } from '@material-ui/core';
import { FaUserCircle } from 'react-icons/fa';
import { FiLogOut } from 'react-icons/fi';
import { MdCloudQueue } from 'react-icons/md';
import styled from 'styled-components';

const cloudHealthLink = 'https://ecpops.aexp.com/index.html';

const StackedButton = styled.span`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-content: center;
  align-items: center;

  .MuiButtonBase-root {
    margin-right: 0;
    padding: 6px;
  }

  .MuiAvatar-root, > svg {
    width: 28px;
    height: 28px;
    margin-bottom: 2px;
  }
`;

const HealthIndicatorBadge = styled.span`
  position: absolute;
  width: 16px;
  height: 16px;
  border-radius: 8px;
  background: rgb(31, 177, 61);
  top: 5px;
  left: calc(50% - 5px);
`;

const Wrapper = styled.div`
  header {
    padding: 0 !important;
  }
`;

export default function HPaaSHeader ({user, host, resetModel}) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleMenu = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleClose();
    resetModel();
  }
  const logoutRedirectURL = "https://" + host;

  return (
    <Wrapper>
      <Header
        title="Hybrid PaaS"
        showMenuToggle={false}
        icon={
          <img
            src={`${process.env.PUBLIC_URL}/logo_amexwhite.png`}
            style={{
              marginRight: 20,
              width: 'auto',
              height: 40,
              fontSize: '1.5rem',
              color: '#fff',
            }}
            alt="eCP Logo"
          />
        }
        rightContent={
          <div style={{ color: '#fff' }}>
            {/*<Button
              href={cloudHealthLink}
              target="_blank"
              style={{
                fontSize: 'secon',
                marginRight: 12,
                paddingRight: 20,
                color: '#fff',
                textTransform: 'none',
                borderRadius: 0,
              }}
            >
              <StackedButton>
                <HealthIndicatorBadge color="green" />
                <MdCloudQueue size={32} />
                Cloud Health
              </StackedButton>
            
            </Button>*/}
            <IconButton
              style={{
                color: '#fff',
              }}
              onClick={handleMenu}>
              <StackedButton>
                {
                  !user ? <FaUserCircle color="#fff" /> : <Avatar style={{background: 'rgb(100, 202, 244)'}}>{ user.substring(0, 2).toUpperCase() }</Avatar>
                }
                {
                  !user ? null : <Typography style={{ fontSize: 'secon' }}>{user}</Typography>
                }
              </StackedButton> 
            </IconButton>
            {/*<Menu
              id="menu-appbar"
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'center',
              }}
              getContentAnchorEl={null}
              keepMounted
              open={open}
              onClose={handleClose}
            >
              <MenuItem>
                <FiLogOut style={{ marginRight: 6 }} />
                <Link href={logoutRedirectURL}>Logout</Link>
              </MenuItem> 
            </Menu>*/}
          </div>
        }
      />
    </Wrapper>
  )
}
