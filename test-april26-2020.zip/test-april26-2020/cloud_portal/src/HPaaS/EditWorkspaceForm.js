import React, { Fragment, useEffect, useState } from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import {Grid, Typography, TextField, Select, Checkbox, FormControl, InputLabel, FormControlLabel, Tooltip, IconButton, Toolbar, Paper, Tab, Tabs, Box} from '@material-ui/core';
import Divider from '@material-ui/core/Divider';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import { Link } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { useForm, Controller } from 'react-hook-form';
import { useDispatch, useStore } from 'react-redux';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { TopBar, TopBarActions } from './styledComponents';
import { useParams } from 'react-router-dom';

const useStyles = makeStyles({});

const Wrapper = styled.div`
  //padding: 12px;
  display: flex;
  flex-grow: 1;

  .form-info {
    padding: 0 40px 0 0;
  }
`;

const TopNavigation = styled.div`
  display: flex;
  flex-direction: column;  
`;

const FormActions = styled.div`
  display: flex;
  padding: 10px 0 15px 0;

  > h6 {
    display: inline-block;
    flex-grow: 1;
  }

  > button {
    margin-right: 10px;
  }
`;

const TabsList = styled.div`
  {
    margin: 0 50px 5px 0;
  }
`;

const WorkGroups = styled.div`
  {
    margin-top: 20px;
  }
`;

const FormElementWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: row;
  margin-bottom: 5px;

  > :first-child {
    max-width: calc(100% - 64px);
  }
`;

export const HtmlTooltip = withStyles(theme => ({
  tooltip: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}))(Tooltip);

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </Typography>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
};

export default function EditWorkspaceForm(props) {
  const response = props.response;
  const dispatch = useDispatch();
  const store = useStore();
  const { control, register, handleSubmit, watch, errors, getValues, formState } = useForm({
    reValidateMode: 'onBlur',
    mode: 'onBlur',
    validateCriteriaMode: "firstErrorDetected",
    submitFocusError: true,
    nativeValidation: false,
  });
  const { workspaceId } = useParams();
  const [tabValue, setTabValue] = useState(0);
  const { workspace } = store.getState().wspace;
  const { projectUID, projectName, aimID, members, businessJustification, description, region, pii } = workspace;

  const displayResponse = (response) => {
    switch(response.status) {
      case "success":   return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>{response.message}</span>;
      case "error":   return <span style={{ color: 'red', fontSize: 12, fontWeight: 600}}>{response.message}</span>;
      default: return <span></span>
    }
  }

  useEffect(() => {
    dispatch.wspace.getWorkspace(workspaceId);
    dispatch.wspace.setResponse('');
  }, [dispatch, workspaceId]);

  const onSubmit = data => {
    dispatch.wspaces.submitEditWorkspaceForm({
      ...workspace,
      ...data,
      members: data.members.split(','),
      status: 'pending',
    });
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Wrapper>
      <Grid container>
        <Grid item xs={12}>
          <form onSubmit={handleSubmit(onSubmit)}>
            <TopBar>
              <Breadcrumbs separator="›" aria-label="breadcrumb">
                <Link color="inherit" href="/hpaas/dashboard">
                  Dashboard
                </Link>
                <Typography color="textPrimary">Update Workspace</Typography>
              </Breadcrumbs>

              <TopBarActions>
                <Typography variant="h6">
                  Update Workspace 
                </Typography>
                <Typography variant="subtitle1">
                  {displayResponse(response)}
                </Typography>
                <Button variant="contained" color="primary" spacing={2} type="submit">
                  Update
                </Button>
                <Button variant="contained" color="default" href="/hpaas/dashboard">
                  Cancel
                </Button>
              </TopBarActions>
            </TopBar>

            <Divider light align="bottom"/>

            <TabsList>
              <Tabs
                value={tabValue}
                indicatorColor="primary"
                textColor="primary"
                aria-label="disabled tabs example"
                onChange={handleTabChange}
              >
                <Tab label="General" {...a11yProps(0)}/>
                <Tab label="Workgroups" disabled {...a11yProps(1)}/>
                <Tab label="Environments" disabled {...a11yProps(2)}/>
              </Tabs>
            </TabsList>
        
            <TabPanel value={tabValue} index={0}>
              <div style={{padding: '0 12px 12px'}}>
                <Grid container>
                  <Grid item xs={12} md={4} xl={3}>
                    <div className="form-info">
                      <Typography variant="subtitle1">
                        General Information 
                      </Typography>
                      <Typography variant="caption">
                        General Information regarding workspace needs to be provided. 
                        AIM Director approval is required for creating a new workspace. 
                      </Typography>
                    </div>
                  </Grid>
                  <Grid item xs={12} md={8} xl={9}>

                    <Typography variant="subtitle1">
                      Update general information 
                    </Typography>
                    <FormElementWrapper>
                      <Controller
                        as={<TextField />}
                        control={control}
                        defaultValue={projectName}
                        key={projectName}
                        inputRef={register()}
                        error={errors.hasOwnProperty('projectName')}
                        helperText={errors.hasOwnProperty('projectName') && 'Some helper text here to explain the name requirements to the user.'}
                        name="projectName"
                        id="projectName"
                        placeholder="Enter Workspace Name"
                        label="* Workspace Name"
                        margin="dense"
                        fullWidth
                        disabled
                      />

                      <HtmlTooltip interactive
                        title={
                        <Fragment>
                        <Typography color="inherit">Workspace Name</Typography>
                          <em>{"A unique name of a workspace"}</em> 
                        </Fragment>
                        }
                        >
                        <Button size="small">?
                        </Button>
                      </HtmlTooltip>
                    </FormElementWrapper>

                    <FormElementWrapper>
                      <Controller
                        as={<TextField />}
                        control={control}
                        defaultValue={aimID}
                        key={aimID}
                        inputRef={register({ required: true })}
                        error={errors.hasOwnProperty('aimID')}
                        name="aimID"
                        id="aimID"
                        placeholder="Enter AIMID"
                        label="* AIM ID"
                        margin="dense"
                        fullWidth
                        disabled
                      />

                      <HtmlTooltip interactive
                        title={
                        <Fragment>
                        <Typography color="inherit">AIM ID </Typography>
                        <em>{"Learn more about CAR (Central Asset Registry)"}</em> <a href='https://square.americanexpress.com/docs/DOC-55683' target='_blank'>here</a>
                        </Fragment>
                        }
                        >
                        <Button>?</Button>
                      </HtmlTooltip>
                    </FormElementWrapper>

                    <FormElementWrapper>
                      <Controller
                        as={<TextField />}
                        control={control}
                        key={businessJustification}
                        defaultValue={businessJustification}
                        inputRef={register({ required: true })}
                        error={errors.hasOwnProperty('businessJustification')}
                        multiline
                        rows={2}
                        name="businessJustification"
                        id="businessJustification"
                        placeholder="Enter Business Justification"
                        label="* Business Justification"
                        margin="dense"
                        fullWidth
                        disabled
                      />
                    </FormElementWrapper>

                    <FormElementWrapper style={{margin: '10px 0 15px 0'}}>
                      <Controller
                        as={<TextField />}
                        control={control}
                        defaultValue={members}
                        key={members}
                        inputRef={register({ required: true })}
                        rules={{
                          required: {
                            value: true,
                            message: 'Members are required.',
                          },
                        }}
                        error={errors.hasOwnProperty('members')}
                        helperText={errors.hasOwnProperty('members') && errors.members.message}
                        name="members"
                        id="members"
                        placeholder="Members"
                        label="* Members"
                        margin="dense"
                        fullWidth
                      />
                    
                      <HtmlTooltip interactive
                        title={
                          <Fragment>
                            <Typography color="inherit">Members </Typography>
                            <em>{"Members' ADS ids, should be separated by commas"}</em> 
                          </Fragment>
                        }>
                        <Button>?</Button>
                      </HtmlTooltip>
                    </FormElementWrapper>

                    <FormElementWrapper>
                      <Controller
                        as={<TextField />}
                        control={control}
                        defaultValue={description}
                        key={description}
                        inputRef={register({ required: true })}
                        rules={{
                          required: {
                            value: true,
                            message: 'Workspace description is required.',
                          },
                          maxLength: {
                            value: 253,
                            message: 'Workspace description should be max 253 char.',
                          },
                          minLength: {
                            value: 10,
                            message: 'Workspace description should be min 10 char.',
                          },
                         
                        }}
                        error={errors.hasOwnProperty('description')}
                        helperText={errors.hasOwnProperty('description') && errors.description.message}
                        name="description"
                        id="description"
                        placeholder="Enter Workspace Description"
                        label="* Workspace Description"
                        margin="dense"
                        fullWidth
                      />
                    </FormElementWrapper>

                    {/* 
                     <FormElementWrapper>
                      <FormControl fullWidth  style={{margin: '10px 0 15px 0'}}>
                        <InputLabel htmlFor="age-native-simple">* Cluster</InputLabel>
                        <Controller
                          as={(
                            <Select>
                              <option value='cluster_for_non_pii_services'>Cluster for Non-PII Services</option>
                              <option value='cluster_for_pii_services' disabled>Cluster for PII Services</option>
                            </Select>
                          )}
                          control={control}
                          defaultValue={region}
                          key={region}
                          inputRef={register({ required: true })}
                          error={errors.hasOwnProperty('region')}
                          native
                          value="cluster_for_non_pii_services"
                          id="clusters"
                          name="clusters"
                          disabled
                        />
                      </FormControl>
                      <HtmlTooltip interactive
                        title={
                          <Fragment>
                            <Typography color="inherit">Clusters </Typography>
                            <em>{"Cluster Information "}</em> <a href='' target='_blank'>click here.</a>
                          </Fragment>
                        }>
                        <Button>?</Button>
                      </HtmlTooltip>
                    </FormElementWrapper> */}

                  </Grid>
                </Grid>
              </div>
            </TabPanel>
            <TabPanel value={tabValue} index={1}>
              <div style={{padding: '0 12px 12px'}}>
                <Grid container>
                  <Grid item xs={12} md={4} xl={3}>
                    <div className="form-info">
                      <Typography variant="subtitle1">
                        Workgroup Information 
                      </Typography>
                      <Typography variant="caption">
                        Workgroups
                      </Typography>
                    </div>
                  </Grid>
                  <Grid item xs={12} md={8} xl={9}>
                    <Typography variant="subtitle1">
                      Update workgroup information  
                    </Typography>
                    
                    <FormElementWrapper>
                      <Controller
                        as={<TextField />}
                        control={control}
                        defaultValue=""
                        inputRef={register({ required: false })}
                        error={errors.hasOwnProperty('workgroupName')}
                        helperText={errors.hasOwnProperty('workgroupName') && 'Some helper text here to explain the name requirements to the user.'}
                        name="workgroupName"
                        id="workgroupName"
                        placeholder="Application Workgroup name in ServiceNow"
                        label="Workgroup Name"
                        margin="dense"
                        fullWidth
                      />

                      <HtmlTooltip interactive
                        title={
                        <Fragment>
                        <Typography color="inherit">Workspace Name</Typography>
                          <em>{"Enter Service Now Workgroup Name here if you plan to promote your application to E2"}</em> 
                        </Fragment>
                        }
                        >
                        <Button size="small">?
                        </Button>
                      </HtmlTooltip>
                    </FormElementWrapper>

                    <FormElementWrapper>
                      <WorkGroups>
                        <Grid item><Typography variant="subtitle1">Work Group(s)</Typography> </Grid>
                        <Grid item><Typography variant="subtitle2" display="inline">e1: </Typography> <Typography variant="body2" color="textSecondary" display="inline"> e1 GG-ADS-E1-ePaaS-admin-ecp-sample-project </Typography></Grid>
                        <Grid item><Typography variant="subtitle2" display="inline">e2: </Typography> <Typography variant="body2" color="textSecondary" display="inline"> e2 GG-ADS-E1-ePaaS-admin-ecp-sample-project </Typography></Grid>
                        <Grid item><Typography variant="subtitle2" display="inline">e3: </Typography> <Typography variant="body2" color="textSecondary" display="inline"> e3 GG-ADS-E1-ePaaS-admin-ecp-sample-project </Typography></Grid>
                      </WorkGroups>

                      <HtmlTooltip interactive
                        title={
                        <Fragment>
                          <Typography color="inherit">Workgroup Details </Typography>
                          <em>{"Request Owner privileges."}</em> <a href='https://enterprise-confluence.aexp.com/confluence/x/aFFkC' target='_blank'>click here.</a>
                        </Fragment>
                        }
                        >
                        <Button size="small">?
                        </Button>
                      </HtmlTooltip>
                    </FormElementWrapper>
                  </Grid>
                </Grid>
              </div>
            </TabPanel>
          </form>
        </Grid>
      </Grid>
    </Wrapper>
  )
}
  