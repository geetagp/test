import { fetchWorkspaces, createWorkspace, fetchWorkspace, updateWorkspace, createService } from './workspaceService';
import history from '../App/history';

const initialState = {
  workspaces: [],
  workspace: {},
  user: '',
  token: '',
  host: '',
  hasAuth: false,
  checkedAuth: false,
  response: {},
};

const model = {
  state: { ...initialState },

  reducers: {
    storeWorkspaces: (state, workspaces) => ({
      ...state,
      workspaces,
      hasAuth: true,
    }),
    storeWorkspace: (state, workspace) => ({
      ...state,
      workspace,
      hasAuth: true,
    }),
    storeParams: (state, params) => ({
      ...state,
      ...params,
    }),
    resetModel: (state) => ({...initialState}),
    setCheckedAuth: (state, checkedAuth) => ({ ...state, checkedAuth }),
    setResponse: (state, response) => ({ ...state, response }),
  },

  effects: dispatch => ({
    async getWorkspaces(payload, state) {
        const workspacesResponse = await fetchWorkspaces();
        if (workspacesResponse && workspacesResponse.status === "success") {
          dispatch.wspaces.storeWorkspaces(workspacesResponse.data);
        } else {
          // handle error here
          console.log('error fetching workspaces');
        }
    },

    async getWorkspace(payload, state) {
      const workspaceRes = await fetchWorkspace(payload); 
      if (workspaceRes && workspaceRes.status === "success") {
        dispatch.wspace.storeWorkspace(workspaceRes.data);
      } else {
        // handle error here
        console.log('error fetching workspace');
        //dispatch.wspace.storeWorkspace(require('./localdata/workspace.json').data);
      }

    },

    async submitCreateWorkspaceForm(payload, state) {
      payload['members'] = payload.members.split(',');  
      const workspacesResponse = await createWorkspace(payload);
      let workspaceRes = {};

      //check for success
      if (workspacesResponse && workspacesResponse.status === "success") {
        workspaceRes = {
          "status": workspacesResponse.status,
          "message": "Workspace created successfully.",
        };
        dispatch.wspace.resetModel();
        dispatch.wspace.setResponse(workspaceRes);
        history.push('/hpaas/dashboard');
        history.go('/hpaas/dashboard');
      }

      //check for error 
      if (workspacesResponse && workspacesResponse.status === "fail") {
        let errorsObj = workspacesResponse.errors ;
        let message = Object.keys(errorsObj)[0] + ":" + errorsObj[Object.keys(errorsObj)[0]]; 

        workspaceRes = {
          "status": workspacesResponse.status,
          "message": message,
        };

        dispatch.wspace.resetModel();
        dispatch.wspace.setResponse(workspaceRes);
      }
    },

    async submitEditWorkspaceForm(payload, state) {
      const workspaceResponse = await updateWorkspace(payload);
      dispatch.wspace.getWorkspace(payload.projectUID);
      let workspaceRes = {};

      // if (workspaceRes) {
      //   if (workspaceRes.status === 'success') {
      //     // dispatch.wspace.storeWorkspace(workspaceRes.data);
      //     dispatch.wspace.getWorkspace(payload.projectUID)
      //   } else if (workspaceRes.status === 'error') {
      //     // handle error here.
      //   }
      // }

      if(workspaceResponse) {
        workspaceRes = {
          "status": "success",
          "message": "Workspace updated successfully.",
        };
        dispatch.wspace.resetModel();
        dispatch.wspace.setResponse(workspaceRes);
      }
      
    },

  })
}

export default model;
