import React, { PureComponent } from 'react';
import styled from 'styled-components';

const date = new Date();
const Wrapper = styled.div`
  background: #283747;
  display: flex;
  padding: 16px 24px;
  color: #fff;
  display: flex;
  font-size: 14px;
  bottom: 0;
  position: fixed;
  width: calc(100vw - 48px);

  .copyright {
    flex: 1;
  }

  .links {
    a {
      color: #fff;
      text-decoration: none;
      margin-right: 60px;

      &:last-child {
        margin-right: 0;
      }
    }
  }
`;
const links = [
  {
    'title': 'About',
    'url': '',
  },
  {
    'title': 'Terms',
    'url': '#',
  },
  {
    'title': 'Privacy Policy',
    'url': '#',
  },
]

export default class HPaaSFooter extends PureComponent {
  render() {
    return (
      <Wrapper>
        <div className="copyright">&copy; {date.getFullYear()} American Express Company. All Rights Reserved</div>
        <div className="links">
          {
            links.map((link, i) => <a key={i} href={link.url}>{link.title}</a>)
          }
        </div>
      </Wrapper>
    )
  }
}
