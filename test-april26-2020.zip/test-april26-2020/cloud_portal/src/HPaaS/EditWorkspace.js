import React, { useEffect, Fragment } from 'react';
import styled from 'styled-components';
import HPaaSHeader from './HPaaSHeader';
import EditWorkspaceForm from './EditWorkspaceForm';
import HPaaSFooter from './HPaaSFooter';
import { connect } from 'react-redux';
import { useParams } from 'react-router-dom';

const Wrapper = styled.div``;

const EditWorkspace = ({
  workspace,
  getWorkspace,
  location,
  storeParams,
  user,
  resetModel,
  hasAuth,
  checkedAuth,
  host,
  response,
}) => {

  return (
    <Fragment>
      <Wrapper>
        <HPaaSHeader user='suser' host='localhost' resetModel='false' />
        <EditWorkspaceForm response={response}/>
        <HPaaSFooter />
      </Wrapper>
    </Fragment>
  )
}

const mapProps = state => ({
  workspace: state.wspace.workspace,
  user: state.wspace.user,
  hasAuth: state.wspace.hasAuth,
  checkedAuth: state.wspace.checkedAuth,
  host: state.wspace.host,
  response: state.wspace.response,
})

const mapDispatch = dispatch => ({
  getWorkspace: dispatch.wspace.getWorkspace,
  resetModel: dispatch.wspace.resetModel,
  setResponse: dispatch.wspace.setResponse,
})

export default connect(mapProps, mapDispatch)(EditWorkspace)
