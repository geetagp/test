import React, { useEffect, Fragment } from 'react';
import styled from 'styled-components';
import HPaaSHeader from './HPaaSHeader';
import HPaaSDashboard from './HPaaSDashboard';
import HPaaSFooter from './HPaaSFooter';
import { connect } from 'react-redux';

const Wrapper = styled.div``;

const HPaaSManager = ({
  workspaces,
  getWorkspaces,
  location,
  storeParams,
  user,
  resetModel,
  hasAuth,
  checkedAuth,
  host,
}) => {
  useEffect(() => {
    const {search} = location;
    if (search.length > 0) {
      const paramsObj = JSON.parse('{"' + decodeURI(search.substring(1)).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g,'":"') + '"}');
      storeParams(paramsObj);
      // window.history.replaceState({}, document.title, CERTIFICATE_MANAGER_URL);
    }
    getWorkspaces();
  }, [getWorkspaces, location, storeParams])

  return (
    <Fragment>
      <Wrapper>
        <HPaaSHeader user='suser' host='localhost' resetModel='false' />
        <HPaaSDashboard workspaces={workspaces}/>
        <HPaaSFooter />
      </Wrapper>
    </Fragment>
  )
}

const mapProps = state => ({
  workspaces: state.wspaces.workspaces,
  user: state.wspaces.user,
  hasAuth: state.wspaces.hasAuth,
  checkedAuth: state.wspaces.checkedAuth,
  host: state.wspaces.host,
})

const mapDispatch = dispatch => ({
  getWorkspaces: dispatch.wspaces.getWorkspaces,
  resetModel: dispatch.wspaces.resetModel,
  storeParams: dispatch.wspaces.storeParams,
})

export default connect(mapProps, mapDispatch)(HPaaSManager)
