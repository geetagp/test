import React, { useEffect } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components';
import { Breadcrumbs, Link, Typography, Button, Grid, Divider, IconButton, Avatar } from '@material-ui/core';
import MUIDataTable from 'mui-datatables';
import { MdList, MdMoreVert, MdEdit } from 'react-icons/md';
import { FiPlusCircle } from 'react-icons/fi';
import HPaaSHeader from './HPaaSHeader';
import HPaaSFooter from './HPaaSFooter';
import { TopBar, TopBarActions } from './styledComponents';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

const Wrapper = styled.div`
  display: flex;
  flex-grow: 1;

  .content-wrapper {
    display: flex;
    flex: 1;
  }

  .content {
    padding: 12px 24px 24px 24px;
  }

  table {
    .MuiTableCell-body {
      padding: 4px 16px;
    }
  }
`;

const Sidebar = styled.div`
  background: rgb(242, 242, 250);
  height: 100%;
  padding: 12px 24px;
`;

const OverviewList = styled.ul`
  list-style-type: none;
  margin: 0;
  padding: 0;

  li {
    margin: 0 0 24px 0;

    span { display: flex; }

    .key {
      margin-bottom: 12px;
      color: #006fcf;
    }

    .value {
      
    }

    .MuiAvatar-circle {
      margin-right: 6px;
    }
  }
`;

const tableHeadData = [
  { name: 'serviceName', label: 'Name' },
  { name: 'region', label: 'Region' },
  { name: 'podSize', label: 'Pod Size' },
  { name: 'status', label: 'Status' },
  {
    name: 'serviceUID', 
    label: 'Edit',
    options: {
      customBodyRender: serviceUID => (
        <IconButton href={`/hpaas/workspace/service/${serviceUID}/edit`}>
          <MdEdit />
        </IconButton>
      ),
    },
  }
];

const WorkspaceOverview = props => {
  const { workspaceId } = useParams();
  const dispatch = useDispatch();
  const applications = useSelector(state => state.applications.applications);
  const workspace = useSelector(state => state.wspace.workspace);
  const { projectName, businessJustification, aimID, description, members } = workspace;
  const membersString = new Array(members).join(',');

  useEffect(() => {
    //dispatch.application.resetModel();
    localStorage.clear(); // need better solution post mvp
    dispatch.wspace.getWorkspace(workspaceId);
    dispatch.application.getApplicationsByWorkspace(workspaceId);
  }, [dispatch, workspaceId])

  return (
    <Wrapper>
      <HPaaSHeader user='suser' host='localhost' resetModel='false' />
      <TopBar>
        <Breadcrumbs separator="›" aria-label="breadcrumb">
          <Link color="inherit" href="/hpaas/dashboard">
            Dashboard
          </Link>
          <Typography color="textPrimary">{projectName}</Typography>
        </Breadcrumbs>
        <TopBarActions>
          <div style={{flex: 1}}>
            <Typography variant="h6" style={{display: 'inline'}}>
              {projectName}
            </Typography>
            {/*<Button startIcon={<MdList />} style={{marginLeft: 80}}>
              Activity Log
            </Button>*/}
          </div>
          <div style={{display: 'flex'}}>
            {/*<Button variant="outlined" color="primary">
              File a ticket
            </Button>*/}
            {/* <IconButton>
              <MdMoreVert />
            </IconButton> */}
            <Button variant="contained" color="primary" style={{marginRight: 15}} href={`/hpaas/workspace/${workspaceId}/service/create`} >
              Create Application
            </Button>
          </div>
        </TopBarActions>
      </TopBar>
      <div className="content-wrapper">
        <Grid container>
          <Grid item xs={12} md={4} xl={3}>
            <Sidebar>
              <h2>Workspace Overview</h2>
              <OverviewList>
              <li>
                  <span className="key">AIM ID</span>
                  <span className="value">{ aimID }</span>
                </li>
                <li>
                  <span className="key">Workspace Description</span>
                  <span className="value">{ description }</span>
                </li>
                <li>
                  <span className="key">Business Justification</span>
                  <span className="value">{ businessJustification }</span>
                </li>
                <li>
                  <span className="key">Team Members</span>
                  <span className="value">
                    { membersString }
                    {/* members.forEach(member => <Avatar key={member}>{member.substr(0, 2).toUpperCase()}</Avatar>) <IconButton><FiPlusCircle /></IconButton> */}
                  </span>
                </li>
              </OverviewList>
            </Sidebar>
          </Grid>
          <Grid item xs={12} md={8} xl={9}>
            <div className="content">
              <h2>Applications ({ applications.length })</h2>
              <Divider />

              <MUIDataTable
                columns={tableHeadData}
                data={applications}
                title={null}
                options={{
                  selectableRows: 'none',
                  search: false,
                  print: false,
                  download: false,
                  viewColumns: false,
                  filter: false,
                  elevation: 1,
                  rowsPerPage: 5,
                  textLabels: {
                    body: {
                      noMatch: 'You have no applications. Start by creating a new application.'
                    }
                  }
                }}
              />

            </div>
          </Grid>
        </Grid>
      </div>
      <HPaaSFooter />
    </Wrapper>
  )
}

WorkspaceOverview.propTypes = {

}

export default WorkspaceOverview
