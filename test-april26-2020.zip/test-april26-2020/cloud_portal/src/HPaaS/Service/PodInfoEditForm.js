import React, { Fragment } from 'react'
import PropTypes from 'prop-types'
import { Typography, TextField, Select, Checkbox, FormControl, InputLabel, FormControlLabel, Button,
  RadioGroup, Radio, FormLabel,
} from '@material-ui/core';
import { useForm, Controller } from 'react-hook-form';
import { FormElementWrapper } from '../styledComponents';
import { HtmlTooltip } from '../EditWorkspaceForm';


const PodInfoForm = ({ errors, register, control, application }) => {
  const { podSize } = application;
  return (
    <div style={{padding: '0 12px 12px'}}>
      <Typography variant="subtitle1">
        Pods Information  
      </Typography>

      <FormElementWrapper>
        <FormControl fullWidth  style={{margin: '10px 0 15px 0'}}>
          <InputLabel htmlFor="age-native-simple">POD Size</InputLabel>
          <Controller
            as={(
              <Select>
                <option value='small'>SMALL</option>
                <option value='medium'>MEDIUM</option>
                <option value='large'>LARGE</option>
              </Select>
            )}
            control={control}
            inputRef={register({ required: true })}
            error={errors.hasOwnProperty('podSize')}
            native
            id="podSize"
            name="podSize"
            disabled
            defaultValue={podSize}
          />
        </FormControl>
        <HtmlTooltip interactive
          title={
            <Fragment>
              <Typography color="inherit">Application Type - Internet </Typography>
              <em>{"Select POD size that closely matches your application's needs."}</em> <a href='https://enterprise-confluence.aexp.com/confluence/pages/viewpage.action?pageId=199306866' target='_blank'>Request a custom size? </a>
            </Fragment>
          }>
          <Button>?</Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper style={{margin: '20px 0 0 0'}}>
        <FormControl component="fieldset">
          <FormLabel component="legend">Monitoring</FormLabel>
          <Controller 
            as={
              <RadioGroup aria-label="monitoring" >
                <FormControlLabel value="none" control={<Radio />} label="None" disabled/>
                <FormControlLabel value="grafana" control={<Radio />} label="Grafana - Enable monitoring in all environments: E1, E2, and E3" disabled/>
                <FormControlLabel value="dynatrace" control={<Radio />} label="Dynatrace - Enable monitoring in all environments: E1, E2, and E3" disabled/>
              </RadioGroup>
            }
            control={control}
            name="monitoring"
            id="monitoring"
            margin="dense"
            value="none"
            color="primary"
            defaultValue="none"
            />
        </FormControl>
      </FormElementWrapper>

      <FormElementWrapper style={{margin: '10px 0 0 0'}}>
        <FormControl component="fieldset">
          <FormLabel component="legend">Logging</FormLabel>
          <Controller 
            as={
              <RadioGroup aria-label="logging" >
                <FormControlLabel value="none" control={<Radio />} label="None" disabled/>
                <FormControlLabel value="splunk" control={<Radio />} label="Splunk - Enable logging in all environments: E1, E2, and E3" disabled/>
              </RadioGroup>
            }
            control={control}
            name="logging"
            id="logging"
            margin="dense"
            value="none"
            color="primary"
            defaultValue="none"
            />
        </FormControl>
      </FormElementWrapper>

    </div>
  )
}

PodInfoForm.propTypes = {

}

export default PodInfoForm




