import React, { Fragment, useEffect } from 'react'
import PropTypes from 'prop-types'
import { 
  Typography, TextField, FormControl, FormControlLabel, Button, RadioGroup, Radio, FormLabel,
} from '@material-ui/core';
import { Controller } from 'react-hook-form';
import { FormElementWrapper } from '../styledComponents';
import { HtmlTooltip } from '../EditWorkspaceForm';

const HealthCheckForm = ({ errors, register, control }) => {
  return (
    <div style={{padding: '0 12px 12px'}}>
      <Typography variant="subtitle1">
        Health Check information 
      </Typography>
      <FormElementWrapper style={{margin: '10px 0 15px 0'}}>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Application URL Prefix is required.',
              },
              maxLength: {
                value: 30,
                message: 'Application URL Prefix should be max 30 char',
              },
              pattern: {
                value: /^[a-z0-9]*$/,
                message: `Application URL prefix can only include letters, numbers and be 30 characters or less.`
              }
            })
          }
          error={errors.hasOwnProperty('applicationUrlPrefix')}
          helperText={errors.hasOwnProperty('applicationUrlPrefix') && errors.applicationUrlPrefix.message}
          name="applicationUrlPrefix"
          id="applicationUrlPrefix"
          placeholder="Enter Application URL Prefix"
          label="* Application URL Prefix"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Application URL Prefix</Typography>
            <em>{"Prefix to be used for each environment's application URLs."}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper style={{margin: '30px 0'}}>
        <FormControl component="fieldset">
          <FormLabel component="legend">Routability</FormLabel>
          <Controller 
            as={
              <RadioGroup aria-label="routableService">
                <FormControlLabel value="authblue" control={<Radio />} label="Routable with AuthBlue SSO." disabled/>
                <FormControlLabel value="default" control={<Radio />} label="Routable with SSO - Application is accessible from outside project. All application pages require SSO authentication." disabled/>
                <FormControlLabel value="nosso" control={<Radio />} label="Routable with no SSO - Application is accessible with no SSO protection. All application pages are exposed to anonymous users." disabled/>
              </RadioGroup>
            }
            control={control}
            name="routableService"
            id="routableService"
            margin="dense"
            value="authblue"
            defaultValue="nosso"
            disabled
            />
        </FormControl>
      </FormElementWrapper>

    </div>
  )
}

HealthCheckForm.propTypes = {

}

export default HealthCheckForm

