import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import { Grid, Typography, TextField, Select, Checkbox, FormControl, InputLabel, FormControlLabel,
  Tooltip, IconButton, Toolbar, Paper, Tab, Tabs, Box, Divider, Link, Button, Breadcrumbs, RadioGroup,
  Radio, FormLabel, AppBar,
} from '@material-ui/core';
import { useForm, Controller, FormContext, useFormContext } from 'react-hook-form';
import { useDispatch, useStore } from 'react-redux';
import styled from 'styled-components';

import HPaaSHeader from '../HPaaSHeader';
import HPaaSFooter from '../HPaaSFooter';
import GeneralForm from './GeneralForm';
import HealthCheckForm from './HealthCheckForm';
import PodInfoForm from './PodInfoForm';
import { TopBar, TopBarActions, FormElementWrapper } from '../styledComponents';
import { useParams } from 'react-router-dom';
import { connect } from 'react-redux';

const Wrapper = styled.div`
  display: flex;
  flex-grow: 1;
  flex: 1;
  min-height: 100%;

  .form-info {
    padding: 0 40px 0 0;
  }
  
`;

function CreateService(props) {
  const dispatch = useDispatch();
  const [ currentTab, setCurrentTab ] = useState(0);
  const response = props.response;

  const createServiceFormDefaults = {
    projectUID: props.match.params.workspaceId,
    healthcheckUri: '/',
    gtmHealthcheckUri: '/',
    maxEnv: 'e3',
    status: 'pending',
    region: 'intranet',
    pii: false,
    deploymentMethod: 'rolling',
    availability: 'active_passive',
    podSize: 'small',
    logging: 'none',
  }

  const methods = useForm({
    reValidateMode: 'onBlur',
    mode: 'onBlur',
    validateCriteriaMode: "firstErrorDetected",
    submitFocusError: true,
    nativeValidation: false,
    defaultValues: createServiceFormDefaults,
  });
  const {
    handleSubmit, errors, formState, reset,
  } = methods;

  const store = useStore();
  const { workspaceId } = useParams();

  useEffect(() => {
    dispatch.wspace.getWorkspace(workspaceId);
    dispatch.application.setResponse('');
  }, [dispatch, workspaceId]);

  const { workspace } = store.getState().wspace;
  const projectName = workspace.projectName;

  const displayResponse = (response) => {
    switch(response.status) {
      case "success":   return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>{response.message}</span>;
      case "fail":   return <span style={{ color: 'red', fontSize: 12, fontWeight: 600}}>{response.message}</span>;
      default: return <span></span>
    }
  }

  const onSubmit = async data => {
    const createApplicationRes = await dispatch.application.submitCreateAppicationForm({ ...createServiceFormDefaults, ...data, projectName: projectName });
    //reset();
    //props.history.push(`/hpaas/workspace/${props.match.params.workspaceId}`);
  }

  const onReset = () => {
    reset();
    //props.history.push('/hpaas/dashboard');
    props.history.push(`/hpaas/workspace/${props.match.params.workspaceId}`);
  }

  return (
    <Wrapper>
      <HPaaSHeader user='suser' host='localhost' resetModel='false' />
        <Grid container style={{ flex: 1 }}>
          <Grid item xs={12}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <TopBar>
                <Breadcrumbs separator="›" aria-label="breadcrumb">
                  <Link color="inherit" href="/hpaas/dashboard">
                    Dashboard
                  </Link>
                  <Link color="inherit" href={`/hpaas/workspace/${props.match.params.workspaceId}`}>
                    List Applications
                  </Link>
                  <Typography color="textPrimary">Create Application</Typography>
                </Breadcrumbs>

                <TopBarActions>
                  <Typography variant="h6">
                    Service Settings
                  </Typography>
                  <Typography variant="subtitle1">
                    {displayResponse(response)}
                  </Typography>
                  <Button variant="contained" color="primary" spacing={2} type="submit" disabled={!formState.isValid}>
                    Save
                  </Button>
                  <Button variant="contained" color="default" onClick={onReset} type="button">
                    Cancel
                  </Button>
                </TopBarActions>
              </TopBar>

              <Divider light align="bottom"/>
              <Tabs
                indicatorColor="primary"
                textColor="primary"
                value={currentTab}
                onChange={(e, newTab) => setCurrentTab(newTab)}>
                <Tab label="General" />
                <Tab label="Health Check" />
                <Tab label="Pod Info" />
                <Tab label="Environment Configuration" disabled />
              </Tabs>

              <div style={{padding: '24px 12px 12px', display: 'flex', flexGrow: 1, flex: 1}}>
              <Grid container>
                <Grid item xs={12} md={4} xl={3}>
                  <div className="form-info">
                    <Typography variant="subtitle1">
                      General Information 
                    </Typography>
                    <Typography variant="caption">
                      General Information regarding a project needs to be provided. 
                    </Typography>
                  </div>
                </Grid>
                <Grid item xs={12} md={8} xl={9}>

                
              <div
                style={{
                  visibility: currentTab === 0 ? 'visible' : 'hidden',
                  height: currentTab === 0 ? 'auto' : 0,
                }}>
                <GeneralForm { ...methods } />
              </div>
              <div
                style={{
                  visibility: currentTab === 1 ? 'visible' : 'hidden',
                  height: currentTab === 1 ? 'auto' : 0,
                }}>
                <HealthCheckForm { ...methods } />
              </div>
              <div
                style={{
                  visibility: currentTab === 2 ? 'visible' : 'hidden',
                  height: currentTab === 2 ? 'auto' : 0,
                }}>
                <PodInfoForm { ...methods } />
              </div>
              </Grid>
                </Grid>
                </div>
            </form>
          </Grid>
        </Grid>
      <HPaaSFooter />
    </Wrapper>
  )
}

CreateService.propTypes = {

}

const mapProps = state => ({
  response: state.application.response,
})

const mapDispatch = dispatch => ({
  setResponse: dispatch.application.setResponse,
})

export default connect(mapProps, mapDispatch)(CreateService)
