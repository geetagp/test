import React from 'react'
import PropTypes from 'prop-types'

const EnvConfigForm = props => {
  return (
    <div>
      env config form
    </div>
  )
}

EnvConfigForm.propTypes = {

}

export default EnvConfigForm
