export async function asyncForEach(array, callback) {
  for (let index = 0; index < array.length; index++) {
    await callback(array[index], index, array);
  }
}

export const getEnvNumberFromString = envString => {
  let env = 0;
  const envStringLowerCase = envString.toLowerCase();

  if (envStringLowerCase.includes('e1')) {
    env = 1;
  } else if (envStringLowerCase.includes('e2')) {
    env = 2;
  } else if (envStringLowerCase.includes('e3')) {
    env = 3;
  }

  return env;
}
