import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from 'react-router-dom';
import history from './history';
import CertManager from '../CertManager/CertManager';
import CertStatus from '../CertManager/CertStatus';
import HPaaSManager from '../HPaaS/HPaaSManager';
import HPaaSCreateWorkspace from '../HPaaS/CreateWorkspace';
import HPaaSEditWorkSpace from '../HPaaS/EditWorkspace';
import HPaaSWorkspaceOverview from '../HPaaS/WorkspaceOverview';
import HPaaSCreateService from '../HPaaS/Service/CreateService';
import HPaaSEditService from '../HPaaS/Service/EditService';

import Home from './Home';

export const CERTIFICATE_MANAGER_URL = '/certificate-manager';
export const CERTIFICATE_STATUS_URL = '/certificate-status';
export const HPAAS_MANAGER_URL = '/hpaas/dashboard';
export const HPAAS_EDIT_WORKSPACE_URL = '/hpaas/workspace/:workspaceId/edit';
export const HPAAS_CREATE_WORKSPACE_URL = '/hpaas/workspace/create';
export const HPAAS_WORKSPACE_OVERVIEW_URL = '/hpaas/workspace/:workspaceId';
export const HPAAS_CREATE_SERVICE_URL = '/hpaas/workspace/:workspaceId/service/create';
export const HPAAS_EDIT_SERVICE_URL = '/hpaas/workspace/service/:serviceId/edit';


export const HOME_URL = '/';

// Our route config is just an array of logical 'routes'
// with `path` and `component` props, ordered the same
// way you'd do inside a `<Switch>`.
const routesConfig = [
  {
    path: CERTIFICATE_MANAGER_URL,
    component: CertManager,
  },
  {
    path: CERTIFICATE_STATUS_URL,
    component: CertStatus,
  },
  {
    path: HPAAS_MANAGER_URL,
    component: HPaaSManager,
  },
  {
    path: HPAAS_EDIT_WORKSPACE_URL,
    component: HPaaSEditWorkSpace,
  },
  {
    path: HPAAS_CREATE_WORKSPACE_URL,
    component: HPaaSCreateWorkspace,
  },
  {
    path: HPAAS_CREATE_SERVICE_URL,
    component: HPaaSCreateService,
  },
  {
    path: HPAAS_EDIT_SERVICE_URL,
    component: HPaaSEditService,
  },
  {
    path: HPAAS_WORKSPACE_OVERVIEW_URL,
    component: HPaaSWorkspaceOverview,
  },
  {
    path: HOME_URL,
    component: Home,
  }
];

export default function Routes() {
  return (
    <Router history={history}>
      <Switch>
        {
          routesConfig.map((route, i) => (
            <Route key={i} {...route} />
          ))
        }
      </Switch>
    </Router>
  );
}


