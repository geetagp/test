import { createMuiTheme } from '@material-ui/core/styles';

// All the following keys are optional.
// We try our best to provide a great default value.
const muiTheme = createMuiTheme({
  palette: {
    primary: {
      main: '#006fcf',
      contrastText: '#fff'
    },
    secondary: {
      main: '#fff',
      contrastText: '#fff'
    }
  },
  typography: {
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
    fontSize: 12,
    useNextVariants: true,
  },
});

export default muiTheme;
