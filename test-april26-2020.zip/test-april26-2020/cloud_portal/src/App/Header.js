import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { AppBar, Toolbar, Typography, IconButton } from '@material-ui/core';
import { FiMenu as MenuIcon } from 'react-icons/fi';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
}));

export default function Header(props) {
  const classes = useStyles();
  const { title, showMenuToggle, icon, rightContent, style } = props;
  return (
    <div className={classes.root}>
      <AppBar position="static" style={{...style, padding: '6px 0'}}>
        <Toolbar variant="dense">
          {
            showMenuToggle === false
              ? null
              : (
                <IconButton edge="start" className={classes.menuButton} color="inherit" aria-label="menu">
                  <MenuIcon />
                </IconButton>
              )
          }
          { !icon ? null : icon }
          <Typography variant="h6" color="inherit" style={{flex: 1}}>
            { title }
          </Typography>
          { !rightContent ? null : rightContent }
        </Toolbar>
      </AppBar>
    </div>
  );
}

