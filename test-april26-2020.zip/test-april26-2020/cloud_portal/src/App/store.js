import { init } from '@rematch/core';
import createRematchPersist from '@rematch/persist';
import app from './appModel';
import certs from '../CertManager/certModel';
import wspaces from '../HPaaS/workspaceModel';
import wspace from '../HPaaS/workspaceModel';
import applications from '../HPaaS/applicationModel';
import application from '../HPaaS/applicationModel';

const models = {
  app,
  certs,
  wspace,
  wspaces,
  application,
  applications,
};

const persistPlugin = createRematchPersist({
  whitelist: ['certs', 'wspace', 'wspaces', 'application', 'applications'],
  throttle: 5000,
  version: 1,
})

const store = init({
  models,
  plugins: [
    persistPlugin,
  ],
});

export default store;
