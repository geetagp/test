export default {
  state: {
    showSidebar: false,
  },

  reducers: {
    setShowSidebar: state => ({
      ...state,
      showSidebar: !state.showSidebar,
    })
  },

  effects: dispatch => ({})
}