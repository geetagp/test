'use strict'
import {applyMiddleware, createStore} from 'redux';
import logger from 'redux-logger';
import React from 'react';
import {render} from 'react-dom';
import {Provider} from 'react-redux';
import './styles/style.scss';
import reducers from './reducers/index.js';
import Main from './main.js';
import Nodes from './components/pages/nodes.js';

const middleware = applyMiddleware(logger);
const store = createStore(reducers, middleware);

// Gita: no neeed to subscribe if you are using middleware with logger such as redux-logger
//store.subscribe(function(){
    //console.log('current state is ', store.getState());
//})

import {Router, Route, IndexRoute, browserHistory} from 'react-router';

const Routes = (
    <Provider store={store}>
        <Router history={browserHistory}>
            <Route path='/' component={Main}>
                <IndexRoute component={Nodes}/>
                <Route path='/all' component={Nodes}/>
                <Route path='/all' component={Nodes}/>
            </Route>
        </Router>
    </Provider>
);

render(
    Routes, document.getElementById('app')
);
