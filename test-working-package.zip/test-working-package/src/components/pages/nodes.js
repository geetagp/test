"use strict"
import React from 'react';
import {Row, Col, Well, Button, Table, FormControl, FormGroup, ControlLabel} from 'react-bootstrap';
import {findDOMNode} from 'react-dom';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {getNodes} from '../../actions/nodesActions';

class Nodes extends React.Component{

    componentDidMount(){
        this.props.getNodes();
    }

    searchTable(){
        const searchString = findDOMNode(this.refs.search).value;
        const data = this.props.nodes.filter(function (node) {
            return node.name.toLowerCase().search(searchString.toLowerCase()) !== -1;
        });
        console.log(data);
    }


    render(){
        return (
            <div id="nodes-table">
                <FormGroup controlId ='title'>
                    <ControlLabel>All Nodes</ControlLabel>
                    <FormControl type='text'
                        placeholder='Search'
                        ref='search' onChange={this.searchTable.bind(this)}/>
                </FormGroup>
                <Table responsive className="table table-hover table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>name</th>
                            <th>role</th>
                            <th>ip</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.nodes.length === 0 ? '' : this.renderResultRows()}
                    </tbody>
                </Table>
            </div>
        );
    }

    renderResultRows = () => {
        return this.props.nodes.map((node, index) => {
            return (
                <tr key={index} data-item={node} >
                    <td data-title="Name"><a href="/all">{node.name}</a></td>
                    <td data-title="Role">{node.role}</td>
                    <td data-title="IP">{node.ip}</td>
                </tr>
            );
        });
    }

}  // end of class

function mapStateToProps(state) {
    return {
        nodes: state.nodes.nodes
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({getNodes: getNodes}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Nodes)
