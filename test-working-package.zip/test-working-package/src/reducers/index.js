//Gita : combine reducers

"use strict"
import {combineReducers} from 'redux';
import {nodesReducers} from './nodesReducers';

export default combineReducers({
  nodes: nodesReducers
})
