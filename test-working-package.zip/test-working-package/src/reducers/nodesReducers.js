// Gita : define node reducers for each node action

'use strict'

export function nodesReducers( state = {nodes:[
    { name:"lpdospea00967.phx.aexp.com", ip: "10.16.190.245",role:"to be defined" },
    { name:"lpdospea00968.phx.aexp.com", ip: "10.16.190.243", role:"to be defined"},
    { name:"lpdospea00946.phx.aexp.com", ip: "10.16.190.267", role:"to be defined"},
    { name:"lpdospea00943.phx.aexp.com" , ip: "10.16.190.290", role:"to be defined"},
    { name:"lpdospea00970.phx.aexp.com", ip: "10.16.190.278", role:"to be defined" },
    { name:"lpdospea00979.phx.aexp.com", ip: "10.16.190.890" , role:"to be defined"}

    ]}, action) {

    switch (action.type) {

        case 'GET_NODES':
            return {...state, nodes:[...state.nodes] }
            break;

    }

    return state;
}
