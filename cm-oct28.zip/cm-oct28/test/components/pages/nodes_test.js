import { renderComponent, expect } from '../../test_helper';
import Nodes from '../../../src/components/pages/nodes';

describe('Nodes', () => {
    let component;
    beforeEach(() => {
        component = renderComponent(Nodes);
    });
    it('Nodes Exists', () => {
        expect(component).to.exist;
    });
    it('has a table', () => {
        expect(component.find('table')).to.exist;
    });
    it('has a search', () => {
        expect(component.find('text')).to.exist;
    });
    it('has a pagination', () => {
        expect(component.find('pagination')).to.exist;
    });
    it('has a modal', () => {
        expect(component.find('Modal')).to.exist;
    });

});
