import { renderComponent, expect } from '../test_helper';
import Menu from '../../src/components/menu';

// describe - to group together similar tests
describe('Menu', () => {
    let component;
    beforeEach(() => {
        component = renderComponent(Menu);
    });
    // it - to test single attribute of the target (e.g component)
    it('Menu Exists', () => {
        // expect - to make an assertion of the target (e.g. component)
        expect(component).to.exist;  // chai syntanx to.exist
    });
});
