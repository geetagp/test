import { renderComponent, expect } from '../test_helper';
import Footer from '../../src/components/footer';

describe('Footer', () => {
    let component;
    beforeEach(() => {
        component = renderComponent(Footer);
    });
    it('Footer Exists', () => {
        expect(component).to.exist;
    });
});
