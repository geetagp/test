// Nodes Actions
// Author : Gita
'use strict'

// Get nodes
export function getNodes()  {
    return {
        type:'GET_NODES'
    }
}

//****** api calls to be implemeted ******// **** also will need api.js to set up base url *********/////
//***** needs axios (http client , supports promise and allows to write xml http request)
//***** and redux-thunk (for asyc action dispatch)

/*
import axios from 'axios';
const ROOT_URL = 'https://e1cloud-v3.aexp.com/opsapi/v1';
// GET NODES
export function getNodes(){
  return function(dispatch){
    axios.get(ROOT_URL + '/inventory/nodes')
        .then(function(response){
            console.log(response);
            dispatch({type:'GET_NODES', payload:response.data})
      })
        .catch(function(err){
            dispatch({type:'GET_NODES_REJECTED', payload:err})
        })
    }
}
*/
