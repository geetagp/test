// Component: Nodes
// Author : Gita
// Description : This component displays nodes from inventory.

"use strict"
import React from 'react';
import {Row, Col, Well, Button, Table, FormControl, FormGroup, ControlLabel, Pagination, Modal } from 'react-bootstrap';
import {findDOMNode} from 'react-dom';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {getNodes} from '../../actions/nodesActions';

class Nodes extends React.Component {

    //TODO: determine the number of pages dynamacally depending on no of nodes
    constructor(props) {
        super(props);
        this.state = {
            nodes: [],
            showModal: false,
            numOfPages: 3,
            activePage: 1,
            nodesPerPage: 2
        };
        //this.searchTable = this.searchTable.bind(this);
        //this.open = this.open.bind(this);
    }

    open(node) {
        this.setState({
            nodes: this.state.nodes,
            showModal: true,
            name: node.name
        });
    }

    close() {
        this.setState({
            nodes: this.state.nodes,
            showModal: false
        });
    }

    componentDidMount() {
        if (this.state.showModal === false) {
            this.props.getNodes();
            //get page nodes
            const nodesOnPage = this.getCurrentPageNodes(this.state.activePage);
            this.setState({ nodes: nodesOnPage,
                activePage: 1,
                nodesPerPage: 2
            });
        }
    }

    // handle search
    searchTable() {
        const searchString = findDOMNode(this.refs.search).value;
        //if(searchString.length > 0) {
            const data = this.props.nodes.filter(function (node) {
                return node.name.toLowerCase().search(searchString.toLowerCase()) !== -1;
            });
            this.setState({nodes: data});
        //}
        //else{}
    }

    // handle pagination
    handlePageSelect(eventKey) {
        //get page nodes
        const nodesOnPage = this.getCurrentPageNodes(eventKey);
        this.setState({ nodes: nodesOnPage,
            activePage: eventKey,
            nodesPerPage: 2
        });
    }

    // get current page nodes
    getCurrentPageNodes(activePage){
        var index = this.state.nodesPerPage * (activePage - 1);
        const nodesData = this.props.nodes.slice(index,index+this.state.nodesPerPage); //this.props.nodes from mapStateToProps
        return nodesData;
    }

    render() {
        return (
            <div id="nodes-table">
                <div>
                    <FormGroup controlId ='title'>
                        <ControlLabel>Hosts</ControlLabel>
                        <FormControl type='text'
                            placeholder='Search'
                            ref='search' onChange={this.searchTable.bind(this)}/>
                    </FormGroup>
                    <Table responsive className="table table-hover table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>name</th>
                                <th>id</th>
                                <th>ip</th>
                                <th>created by</th>
                                <th>updated by</th>
                                <th>Environment</th>
                                <th>Group</th>
                                <th>Zone</th>
                                <th>Status</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.nodes.length === 0 ? '' : this.renderResultRows()}
                        </tbody>
                    </Table>
                </div>
                <div className ='pull-right'>
                    <Pagination
                        className={this.state.nodes.length === 0 ? 'hidden' : 'shown'}
                        prev
                        next
                        first
                        last
                        ellipsis
                        items={this.state.numOfPages}
                        activePage={this.state.activePage}
                        onSelect={this.handlePageSelect.bind(this)}>
                    </Pagination>
                </div>

                <Modal show={this.state.showModal} onHide={this.close.bind(this)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Host ID :  aec7b4fe-9d65-11e7-8b42-acbc329e7dbd</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <h6> name: {this.state.name} </h6>
                        <h6> type: openshift </h6>
                                                <h6> schedulable: true</h6>
                                                <h6> availability zone: AZ2</h6>
                                                <h6> pii: no</h6>
                                                <h6> region: internet</h6>
                                                <h6> tier: egress</h6>
                                                <h6> vlan: TRCW_E2_ACI_eCP_PAAS_INTER4</h6>
                                                <h6> max_pods: 20</h6>

                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.close.bind(this)}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        );
    }

    renderResultRows = () => {
        return this.state.nodes.map((node, index) => {
            return (
                <tr key={index} data-item={node} >
                    <td data-title="Name">{node.name}</td>
                    <td data-title="ID">{node.id}</td>
                    <td data-title="IP">{node.ip_address}</td>
                    <td data-title="Created By">{node.created_by}</td>
                    <td data-title="Updated By">{node.updated_by}</td>
                    <td data-title="Environment">{node.env}</td>
                    <td data-title="Group">{node.group}</td>
                    <td data-title="Zone">{node.zone}</td>
                    <td data-title="Status">{node.status}</td>
                    <td data-title="Type" href='' onClick={this.open.bind(this, node)}> <u>{node.type}</u></td>
                </tr>
            );
        });
    }
}

function mapStateToProps(state) {
    return {
        nodes: state.nodes.nodes
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({getNodes: getNodes}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Nodes)
