// Component: Menu
// Author : Gita
// Description : This is display only component, that forms the header of single page app

'use strict'
import React from 'react';
import {Nav, Navbar, NavItem, Badge, NavDropdown, MenuItem} from 'react-bootstrap';

class Menu extends React.Component {
    render() {
        return (
            <Navbar inverse fixedTop>
                <Navbar.Header>
                <Navbar.Brand >
                    <a href="/">Nodes Inventory</a>
                </Navbar.Brand>
                <Navbar.Toggle />
                </Navbar.Header>
                <Navbar.Collapse>
                <Nav>
                    <NavItem eventKey={1} href="/hosts">hosts</NavItem>
                    <NavItem eventKey={2} href="/vlan">vlan</NavItem>
                    <NavItem eventKey={3} href="/vip">vip</NavItem>
                    <NavItem eventKey={4} href="/service">service</NavItem>
                    <NavItem eventKey={5} href="/nfs">nfs</NavItem>
                </Nav>
                <Nav pullRight>
                    {/*<NavItem eventKey={1} href="/logout">Logout</NavItem>*/}
                </Nav>
                </Navbar.Collapse>
            </Navbar>
        );
    }
}

export default Menu
