// App.js
// Author : Gita

'use strict'
import {applyMiddleware, createStore} from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';
import React from 'react';
import {render} from 'react-dom';
import {Provider} from 'react-redux';
import './styles/style.scss';
import './styles/overrides.scss';
import reducers from './reducers/index.js';
import Main from './main.js';
import Nodes from './components/pages/nodes.js';

const middleware = applyMiddleware(thunk);
const store = createStore(reducers, middleware);

import {Router, Route, IndexRoute, browserHistory} from 'react-router';

const Routes = (
    <Provider store={store}>
        <Router history={browserHistory}>
            <Route path='/' component={Main}>
                <IndexRoute component={Nodes}/>
                <Route path='/hosts' component={Nodes}/>
            </Route>
        </Router>
    </Provider>
);

render(
    Routes, document.getElementById('app')
);
