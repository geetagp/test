// NodesReducers
// Author : Gita

'use strict'
export function nodesReducers( state = {nodes:[
            {
                id: "aec28de7-9d65-11e7-8b41-acbc329e7dbd",
                name: "lpqosper50200.phx.aexp.com",
                create_timestamp: "2017-09-19T18:09:30.733Z",
                update_timestamp: "2017-09-19T18:09:30.733Z",
                created_by: "userId",
                updated_by: "userId",
                env: "e2_blue",
                group: "router_sso",
                ip_address: "10.0.129.59",
                zone: "AZ1",
                properties: {
                    save_sso_reg: "False",
                    sso_aco: "epaasv2rl1inter_agent_config",
                    sso_environment: "e3",
                    sso_zone: "internet"
                },
                openshift: null,
                status: "Ready",
                type:'epaas'
            },
            {
                id: "aeb89bba-9d65-11e7-8b40-acbc329e7dbd",
                name: "lgposped50039.gso.aexp.com",
                create_timestamp: "2017-09-19T18:09:30.668Z",
                update_timestamp: "2017-09-19T18:09:30.668Z",
                created_by: "userId",
                updated_by: "userId",
                env: "e2_blue",
                group: "amq",
                ip_address: "10.36.108.53",
                zone: "AZ2",
                properties: null,
                openshift: null,
                status: "NotReady",
                type:''
            },
            {
                id: "aec7b4fe-9d65-11e7-8b42-acbc329e7dbd",
                name: "lpqospeg50222.phx.aexp.com",
                create_timestamp: "2017-09-19T18:09:30.767Z",
                update_timestamp: "2017-09-19T18:09:30.767Z",
                created_by: "userId",
                updated_by: "userId",
                env: "e2_blue",
                group: "egress",
                ip_address: "10.0.184.66",
                zone: "AZ2",
                properties: null,
                openshift: {
                    scheduleable: true,
                    node_labels: {
                        availabilityzone: "AZ2",
                        pii: "no",
                        region: "internet",
                        tier: "egress",
                        vlan: "TRCW_E2_ACI_eCP_PAAS_INTER4"
                    },
                    kubelet_args: {
                        max_pods: "['20']"
                    }
                },
                status: "",
                type:'openshift'
        },
        {
            id: "xec28de7-9d65-11e7-8b41-acbc329e7dbd",
            name: "lpqosper50201.phx.aexp.com",
            create_timestamp: "2017-09-19T18:09:30.733Z",
            update_timestamp: "2017-09-19T18:09:30.733Z",
            created_by: "userId",
            updated_by: "userId",
            env: "e2_blue",
            group: "router_sso",
            ip_address: "10.0.129.60",
            zone: "AZ1",
            properties: {
                save_sso_reg: "False",
                sso_aco: "epaasv2rl1inter_agent_config",
                sso_environment: "e3",
                sso_zone: "internet"
            },
            openshift: null,
            status: "Ready",
        type:'epaas'
        },
        {
            id: "yeb89bba-9d65-11e7-8b40-acbc329e7dbd",
            name: "lgposped50040.gso.aexp.com",
            create_timestamp: "2017-09-19T18:09:30.668Z",
            update_timestamp: "2017-09-19T18:09:30.668Z",
            created_by: "userId",
            updated_by: "userId",
            env: "e2_blue",
            group: "amq",
            ip_address: "10.36.108.54",
            zone: "AZ2",
            properties: null,
            openshift: null,
            status: "NotReady",
        type:''
        },
        {
            id: "zec7b4fe-9d65-11e7-8b42-acbc329e7dbd",
            name: "lpqospeg50223.phx.aexp.com",
            create_timestamp: "2017-09-19T18:09:30.767Z",
            update_timestamp: "2017-09-19T18:09:30.767Z",
            created_by: "userId",
            updated_by: "userId",
            env: "e2_blue",
            group: "egress",
            ip_address: "10.0.184.67",
            zone: "AZ2",
            properties: null,
            openshift: {
                scheduleable: true,
                node_labels: {
                    availabilityzone: "AZ2",
                    pii: "no",
                    region: "internet",
                    tier: "egress",
                    vlan: "TRCW_E2_ACI_eCP_PAAS_INTER4"
                },
                kubelet_args: {
                    max_pods: "['20']"
                }
            },
            status: "",
        type:'openshift'
    }


    ]}, action) {

    switch (action.type) {

        case 'GET_NODES':
            return {...state, nodes:[...state.nodes] }
            break;

    }

    return state;
}
