'use strict'

// Gita : define cart reducers for each cart action
export function cartReducers(state = {cart:[]}, action) {
    switch (action.type){

        /* Gita: working  code
        case "ADD_TO_CART":
        return {cart:[...state, ...action.payload]}
        break;

        case "DELETE_CART_ITEM":
        return {cart:[...state, ...action.payload]}
        break;
        */

        // Gita : changed code - need to test
        case 'GET_CART':
            //return{...state, cart:action.payload, totalAmount: totals(action.payload).amount, totalQty: totals(action.payload).qty}
            break;

        case 'ADD_TO_CART':
            //return {...state, cart:action.payload, totalAmount: totals(action.payload).amount, totalQty: totals(action.payload).qty}
            return {cart:[...state, ...action.payload] , totalAmount: totals(action.payload).amount}

            break;

        case 'DELETE_CART_ITEM':
            return {...state,
                cart: action.payload,
                totalAmount: totals(action.payload).amount,
                totalQty: totals(action.payload).qty
            }
            break;

        case 'UPDATE_CART':
            // Create a copy of the current array of books
            const currentBookToUpdate =[...state.cart]
            // Determine at which index in books array is the book to be updated
            const indexToUpdate = currentBookToUpdate.findIndex(
                function(book){
                return book._id === action._id;
            } )

            // updated quantity by adding unit
            const newBookToUpdate = {...currentBookToUpdate[indexToUpdate], quantity: currentBookToUpdate[indexToUpdate].quantity + action.unit}

            //console.log("what is it newBookToUpdate",newBookToUpdate);

            //use slice to remove the book at the specified index, replace with the new object and concatenate with the rest of items in the array
            let updatedCart = [...currentBookToUpdate.slice(0,indexToUpdate), newBookToUpdate, ...currentBookToUpdate.slice(indexToUpdate + 1)];

            //return {cart:[...state, ...updatedCart]} // Gita: working code

            //Gita : changed code - need to test
            /*
            return {...state,
                cart:updatedCart,
                totalAmount: totals(updatedCart).amount,
                totalQty: totals(action.payload).qty
            }*/

            //console.log("from update cart",updatedCart);
            return {cart:[...state, ...updatedCart] , totalAmount: totals(updatedCart).amount}

        break;
    }
    return state
}

// CALCULATE TOTALS
export function totals(payloadArr){

    const totalAmount = payloadArr.map(function(cartArr){
        return cartArr.price * cartArr.quantity;
    }).reduce(function(a, b) {
        return a + b;
    }, 0); //start summing from index0


    const totalQty = payloadArr.map(function(qty){
        return qty.quantity;
    }).reduce(function(a, b) {
        return a + b;
    }, 0);

    return {amount:totalAmount.toFixed(2), qty:totalQty}
}
