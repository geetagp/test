// Component: Footer
// Author : Gita
// This is display only component, that forms the footer of single page app GPBooksShop
'use strict'
import React from 'react';

class Footer extends React.Component {
    render() {
        return (
            <footer className='footer text-center'>
                <div className='container'>
                    <p className='footer-text'> Copyright 2017 GPBookshop. All rights reserved.</p>
                </div>
            </footer>
        );
    }
}
export default Footer
