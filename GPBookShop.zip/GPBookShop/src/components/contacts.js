// Component: Contacts
// Author : Gita
// This is display only component
'use strict'
import React from 'react';

class Contacts extends React.Component {
    render() {
        return (
            <div className='container'>
                <p> Contact Us : bookshop@service.com </p>
            </div>
        );
    }
}
export default Contacts;
