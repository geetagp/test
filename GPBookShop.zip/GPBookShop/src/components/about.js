// Component: Author
// Author : Gita
// This is display only component
'use strict'
import React from 'react';

class About extends React.Component {
    render() {
        return (
            <div className='container'>
                <p> About Bookshop </p>
            </div>

        );
    }
}
export default About;
