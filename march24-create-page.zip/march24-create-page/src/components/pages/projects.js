// Component: Projects List
// Author : Gita
// Description : The projects list is displayed to user upon successful login 

'use strict'
import React from 'react';
import { browserHistory } from 'react-router';
import {Nav, Navbar, NavItem, Badge, NavDropdown, MenuItem, Tab, Grid, Row, Col, ButtonToolbar, DropdownButton} from 'react-bootstrap';

class Projects extends React.Component {
    constructor(props) {
        super(props);
    }

    //Gita: create button to navigate to new project creation
    handleCreateProjectBtn() {
        console.log('handle create project btn');
        browserHistory.push('/create_project'); 
       
    }  

    render() {
        return (
            <Grid>
                <Row>
                    <div className="middle">
                        {/*<button className="btn btn-md btn-primary pull-right ecp-create-project-btn">Create Project</button> */}
                        <div className="projects-header">
                            <div className="projects-bar">
                                <h1>Multi-application Projects</h1>
                                <div className="projects-options">
                                    <div className="projects-add">
                                        <button onClick={this.handleCreateProjectBtn.bind(this)} className="btn btn-md btn-primary pull-right ecp-create-project-btn">Create Project</button> 
                                    </div>
                                </div>
                                <div className="projects-search">
                                </div>
                            </div>

                            {/* placeholder div for clearing filters */}
                            <div>
                            </div>

                            <div className="list-group list-view-pf projects-list">
                               {/* begin project tile 1 */}
                            
                                <div className="list-group-item project-info tile-click">
                                    {/* placeholder div for status bar */}
                                    <div className="pending-bar approval-status-bar"></div>
                                    <div className="list-view-pf-main-info">
                                        <div className="list-view-pf-description project-names">
                                            <div className="list-group-item-heading project-name-item">
                                                <h2 className="h1">
                                                    <a className="tile-target" href="http://www.google.com" title="Project1"><span> Project1 </span></a>
                                                </h2>
                                            </div>
                                        </div>    
                                        <div className="list-view-pf-additional-info project-additional-info">
                                            <span className="list-group-item-text project-description">
                                                American Express Application 
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div className="list-view-pf-actions list-pf-actions">
                                        <div className="dropdown">
                                            <a className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i className="fa fa-ellipsis-v" aria-hidden="true"/>
                                            </a>
                                            <ul className="dropdown-menu" role="menu">
                                                <li role="menuitem">Edit</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                {/* end of project tile 1  */}
                            </div>
                        </div>
                    </div>
                </Row>
            </Grid>
        );
    }
}
export default Projects
