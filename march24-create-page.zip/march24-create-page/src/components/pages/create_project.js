// Component: Create Project 
// Author : Gita
// Description : Create Project form allows user to create new project

'use strict'
import React from 'react';
import {Grid, Row, Col} from 'react-bootstrap';

class CreateProject extends React.Component {
    constructor(props) {
        super(props);
    } 

    render() {
        return (

            <Grid>
                <Row>
                    <div className="middle">

                        {/* help icon */}
                        <a className="ecp-page-help" href="https://enterprise-confluence.aexp.com/confluence/x/lWNkC" target="blank">
                            <span title="Help" className="fa pficon-help" aria-hidden="true"></span>
                        </a>

                        <div className="projects-header">
                            <div className="projects-bar">
                                <h1>Create Project</h1>
                            </div>

                            <div className="help-block">AIM Director approval is required for creating a new project. The approving AIM Director may request additional information as part of the review process. Be prepared to share technical details of your project with AIM Director including application type, firewall rules, VIPs, and application URLs. Your request will expire in 7 days after submission. You should work with AIM Director to ensure timely approval.</div>
                           
                            <div className="help-block"><u><a href="https://enterprise-confluence.aexp.com/confluence/display/ED/PaaS+Onboarding+Process" target="_blank">Be sure you understand the on-boarding process and timelines before proceeding.</a></u></div>
                           
                        </div>
                    </div>
                </Row>
            </Grid>
        );
    }
}
export default CreateProject
