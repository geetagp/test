// Pods Reducer
// Author : Gita

'use strict'
export function podsReducer( state = {pods:[
    {
        id: "1",
        name: "pod 1"
    },
    {
        id: "2",
        name: "pod 2"
    }

    ]}, action) {

    switch (action.type) {

        case 'GET_PODS':
            return {...state, pods:[...state.pods] }
            break;

    }

    return state;
}
