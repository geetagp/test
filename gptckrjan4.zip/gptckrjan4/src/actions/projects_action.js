// Projects Actions
// Author : Gita
'use strict'

// Get Projects
export function getProjects()  {
    return {
        type:'GET_PROJECTS'
    }
}

//****** api calls to be implemeted ******// **** also will need api.js to set up base url *********/////
//***** needs axios (http client , supports promise and allows to write xml http request)
//***** and redux-thunk (for asyc action dispatch)

/*
import axios from 'axios';
const ROOT_URL = 'https://e1cloud-v3.aexp.com/opsapi/v1';
// GET Projects
export function getProjects(){
  return function(dispatch){
    axios.get(ROOT_URL + '/projects')
        .then(function(response){
            console.log(response);
            dispatch({type:'GET_PROJECTS', payload:response.data})
      })
        .catch(function(err){
            dispatch({type:'GET_PROJECTS_REJECTED', payload:err})
        })
    }
}
*/
