// Component: Pods
// Author : Gita
// Description : display pods information in table

"use strict"
import React from 'react';
import {Row, Col, Well, Button, Table, FormControl, FormGroup, ControlLabel, Pagination, Modal } from 'react-bootstrap';
import {findDOMNode} from 'react-dom';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {getPods} from '../../actions/pods_action';


class Pods extends React.Component {

	constructor(props) {
        super(props);
    }

	componentDidMount() {
		console.log('pods component did mount ');
        this.props.getPods();
    }

    render() {
        return (
            <div id="pods-table">
                <div>
                    <Table responsive className="table table-hover table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>name</th>
                                <th>id</th>
                            </tr>
                        </thead>
                        <tbody>
                                {this.props.pods.length === 0 ? '' : this.renderResultRows()}
                        </tbody>
                    </Table>
                </div>
            </div>
        );
    }

    renderResultRows = () => {
       return this.props.pods.map((pod, index) => {
            return (
                <tr key={index} data-item={pod} >
                    <td data-title="Name">{pod.name}</td>
                    <td data-title="ID">{pod.id}</td>
                </tr>
            );
        });

    }
}    


function mapStateToProps(state) {
    return {
        pods: state.pods.pods
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({getPods: getPods}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Pods)




