// Component: Tickr
// Author : Gita
// Description : This is display only component, that forms the footer of single page app

'use strict'
import React from 'react';
import {Nav, Navbar, NavItem, Badge, NavDropdown, MenuItem, Tab, Row, Col, ButtonToolbar, DropdownButton} from 'react-bootstrap';
import Dumps from '../pages/dumps.js';
import Pods from '../pages/pods.js';

class Tickr extends React.Component {
    render() {
        return (
            <div>
            
            <Tab.Container id="left-tabs-example" defaultActiveKey="first">
                            <Row className="clearfix">
                            <Col sm={2}>
                            <Nav bsStyle="pills" stacked>
                            <NavItem eventKey="first">
                            Pods
                            </NavItem>
                            <NavItem eventKey="second">
                            Dumps
                            </NavItem>
                            </Nav>
                            </Col>
                            <Col sm={10}>
                            <Tab.Content animation>
                                <Tab.Pane eventKey="first">
                                <Pods/>
                                </Tab.Pane>
                                <Tab.Pane eventKey="second">
                                <Dumps/>
                                </Tab.Pane>
                            </Tab.Content>
                            </Col>
                            </Row>
            </Tab.Container>

            </div>
        );
    }
}
export default Tickr
