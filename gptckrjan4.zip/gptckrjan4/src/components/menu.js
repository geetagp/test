// Component: Menu
// Author : Gita
// Description : This is display only component, that forms the header/menu

'use strict'
import React from 'react';
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import { Link } from 'react-router';
import {getProjects} from '../actions/projects_action';

class Menu extends React.Component {

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        console.log('projects component did mount ');
        this.props.getProjects();
    }

    renderLinksRight()
    {
        if (this.props.authenticated) {
            // show a link to sign out
            return <li className="nav-item">
                <Link className="nav-link" to="/signout">Logout</Link>
            </li>
        } else {
            return <li className="nav-item">
                <Link className="nav-link" to="/signout">Logout</Link>
            </li>
        }
    }

    // TBD : change to index html to import js libraries to make projects dropdown work
    renderLinksLeft()
    {
        if (this.props.authenticated) {
            // show a dropdown with projects list
            return  <li className="dropdown">
                        <a className="dropdown-toggle" data-toggle="dropdown" href="#"> Projects <span className="caret"></span></a>
                            <ul className="dropdown-menu">
                                <li><a href="/tickr">Page 1-1</a></li>
                            </ul>
                    </li>

        } else {
            return  <li className="dropdown">
                        <a className="dropdown-toggle" data-toggle="dropdown" href="#"> Projects <span className="caret"></span></a>
                            <ul className="dropdown-menu">
                                <li><a href="/tickr">Page 1-1</a></li>
                            </ul>
                    </li>
        }
    }

    render() {
        return (
            <nav className="navbar navbar-inverse navbar-fixed-top">
            <div className="container-fluid">
            <div className="navbar-header">
                <a className="navbar-brand" href="#">eCP Tickr Console</a>
            </div>
            <ul className="nav navbar-nav">
                {this.renderLinksLeft()}
            </ul>
            <ul className="nav navbar-nav navbar-right">
                {this.renderLinksRight()}
            </ul>
            </div>
            </nav>
        );
    }
}

function mapStateToProps(state) {
    return {
        authenticated: state.auth.authenticated,
        projects: state.projects.projects
    };
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({getProjects: getProjects}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Menu);







