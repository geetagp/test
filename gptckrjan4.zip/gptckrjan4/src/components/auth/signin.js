// Component: Signin 
// Author : Gita
// Description : This component displays signin info for user to sign in to tickr application 

import React, {Component} from 'react';
import {reduxForm, Field} from 'redux-form';
import {connect} from 'react-redux';
import * as actions from '../../actions';
import {Grid,Col,Row,Button} from 'react-bootstrap';

const renderInput=field=><input {...field.input} type={field.type} className="form-control" />;

class SignIn extends Component{

	handleFormSubmit({email,password}){
		console.log(email,password);
		this.props.signinUser({email,password});
	}
	renderAlert(){
		if(this.props.errorMessage){
			return(
				<div className="alert alert-danger">
					<strong>Oops!</strong> {this.props.errorMessage}
				</div>
				);
		}
	}
	render(){
		const {handleSubmit}=this.props;

		return(
			<Grid>
			   <Row>
			        <p> Please enter your Network (Active Directory) username and password. </p>
					<form onSubmit={handleSubmit(this.handleFormSubmit.bind(this))}>
						<fieldset className="form-group">
							<label>Email:</label>
							<Field
								name="email"
								component={renderInput}
								type="email"
							/>
						</fieldset>
						<fieldset className="form-group">
							<label>Password:</label>
							<Field
								name="password"
								component={renderInput}
								type="password"
							/>
						</fieldset>
						{this.renderAlert()}
						<button action="submit" className="btn btn-primary">Login</button>
					</form>
				</Row>
			</Grid>
		);
	}
}

function mapStateToProps(state){
	return {errorMessage: state.auth.error};
}

export default reduxForm({
	form: 'signin'
})(
	connect(mapStateToProps,actions)(SignIn)
);
