// Pods Actions
// Author : Gita
'use strict'

// Get pods
export function getPods()  {
    return {
        type:'GET_PODS'
    }
}

//****** api calls to be implemeted ******// **** also will need api.js to set up base url *********/////
//***** needs axios (http client , supports promise and allows to write xml http request)
//***** and redux-thunk (for asyc action dispatch)

/*
import axios from 'axios';
const ROOT_URL = 'https://e1cloud-v3.aexp.com/opsapi/v1';
// GET PODS
export function getPods(){
  return function(dispatch){
    axios.get(ROOT_URL + '/pods')
        .then(function(response){
            console.log(response);
            dispatch({type:'GET_PODS', payload:response.data})
      })
        .catch(function(err){
            dispatch({type:'GET_PODS_REJECTED', payload:err})
        })
    }
}
*/
