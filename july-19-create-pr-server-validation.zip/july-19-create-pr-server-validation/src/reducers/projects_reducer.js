// Projects Reducer
// Author : Gita

'use strict'
export function projectsReducer( state = {projects:[
        {
             id: "1",
             name: "Project_1"
        },
        {
             id: "2",
             name: "Project_2"
        }

    ]}, action) {

    switch (action.type) {

        case 'GET_PROJECTS':
            return {...state, projects:[...state.projects] }
            break;

    }

    return state;
}
