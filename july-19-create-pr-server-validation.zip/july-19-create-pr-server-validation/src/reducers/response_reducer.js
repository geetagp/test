// Response Reducer
// Author : Gita

export function responseReducer(state = {}, action) {
  switch (action.type) {
    case 'GET_MSG':
      return { ...state, result: action.payload };
    case 'RESET_MSG':
      return { ...state, result: {} };
  }
  return state;
}
