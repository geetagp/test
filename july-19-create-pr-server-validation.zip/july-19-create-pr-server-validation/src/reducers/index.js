// Combine Reducers
// Author : Gita

'use strict'
import { combineReducers } from 'redux';
import { reducer as form } from 'redux-form';
import authReducer from './auth_reducer';
import {podsReducer} from './pods_reducer';
import {projectsReducer} from './projects_reducer';
import {responseReducer} from './response_reducer';

export default combineReducers({
    form,
    auth: authReducer,
    pods: podsReducer,
    projects: projectsReducer,
    response: responseReducer
})
