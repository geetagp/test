import { getApiHost } from './common/environment';
const apiHost = getApiHost();
//const APPLICATION_API_URL =  'https://' + apiHost + '/services';
const APPLICATION_API_URL =  'https://engv5bomapi-dev.aexp.com/v5/services';

export const fetchApplicationsByWorkSpace = async (workspaceId, idToken) => {
  let responseObj = {data: {}, status: ''};
  return new Promise(async (resolve, reject) => {
    fetch(APPLICATION_API_URL + `?workspaceName=${workspaceId}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${idToken}`,
      }
    })
    .then(res => { 
      if (res.ok) {
        res.json().then((data) => {
          responseObj.data = data; 
          responseObj.status = "success"; 
          resolve(responseObj); 
        });
      }
      else{
        responseObj.data = res.statusText; 
        responseObj.status = "fail"; 
        resolve(responseObj); 
      }
    })
    .catch(err => reject(err));
    });
 }

 export const fetchApplication = async (idToken, applicationId) => {
  let responseObj = {data: {}, status: ''};
  return new Promise(async (resolve, reject) => {
      //return await fetch(`${APPLICATION_API_URL}?applicationName=${id}`, {
      return await fetch(APPLICATION_API_URL + `?applicationName=${applicationId}`, { // fake call to get first application - for now - since api is not ready
      method: 'GET',
      headers: {
        Authorization: `Bearer ${idToken}`,
      }
    })
    .then(res => { 
      if (res.ok) {
        res.json().then((data) => {
          responseObj.data = data[0]; 
          //console.log(data[0]);
          responseObj.status = "success"; 
          resolve(responseObj); 
        });
      }
      else{
        responseObj.data = res.statusText; 
        responseObj.status = "fail"; 
        resolve(responseObj); 
      }
    })
    .catch(err => reject(err));
   });
}

 export const createApplication = async (formData, idToken) => {
  let responseObj = {data: {}, status: ''};
  return new Promise(async (resolve, reject) => {
    return await fetch(APPLICATION_API_URL, {
      method: 'POST',
      body: JSON.stringify(formData),
      headers: {
        Authorization: `Bearer ${idToken}`,
      }
    })
    .then(res => { 
      if (res.ok) {
        res.json().then((data) => {
          responseObj.data = data; 
          responseObj.status = "success"; 
          resolve(responseObj); 
        });
      }
      else{
        res.json().then((data) => {
          responseObj.errors = data; 
          responseObj.status = "fail"; 
          resolve(responseObj); 
        });
      }
    })
    .catch(err => reject(err));
   });
}

export const updateApplication = async (formData, idToken) => {
  return new Promise(async (resolve, reject) => {

    return await fetch(`${APPLICATION_API_URL}/${formData.applicationName}`, {
      method: 'PATCH',
      body: JSON.stringify(formData.patchData),
      headers: {
        'Content-Type': 'application/json',
         Authorization: `Bearer ${idToken}`,
      },
    })
    .then(res => {
      if (res.status === 204) {
        resolve(true);
      }
      console.log(res);
    })
    .catch(err => reject(err));

  });
}

