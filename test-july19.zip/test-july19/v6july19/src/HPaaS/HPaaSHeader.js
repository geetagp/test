import React, { useEffect } from 'react';
import Header from '../App/Header';
import { IconButton, Menu, MenuItem, Avatar, ListItemIcon, ListItemText } from '@material-ui/core';
import { FaUserCircle } from 'react-icons/fa';
import { FiLogOut } from 'react-icons/fi';
import styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import { useOktaAuth } from '@okta/okta-react';
import { useHistory } from 'react-router-dom';

const cloudHealthLink = 'https://ecpops.aexp.com/index.html';

const StackedButton = styled.span`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-content: center;
  align-items: center;

  .MuiButtonBase-root {
    margin-right: 0;
    padding: 6px;
  }

  .MuiAvatar-root, > svg {
    width: 28px;
    height: 28px;
    margin-bottom: 2px;
  }
`;

const HealthIndicatorBadge = styled.span`
  position: absolute;
  width: 16px;
  height: 16px;
  border-radius: 8px;
  background: rgb(31, 177, 61);
  top: 5px;
  left: calc(50% - 5px);
`;

const Wrapper = styled.div`
  header {
    padding: 0 !important;
  }
`;

export default function HPaaSHeader ({user, host, resetModel}) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const okta = useSelector(state => state.app.okta);
  const { authState, authService } = useOktaAuth();
  const dispatch = useDispatch();
  const history = useHistory();

  const handleMenu = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleClose();
    resetModel();
  }
  const logoutRedirectURL = "https://" + host;

  useEffect(() => {
    if (authState && !authState.isAuthenticated) {
      // When user isn't authenticated, forget any user info
      dispatch.app.setOkta(null)
    } else {
      authService.getUser().then((info) => {
        dispatch.app.setOkta({ ...info, ...authState, });
      });
    }
  }, [authState, authService]); // Update if authState changes

  return (
    <Wrapper>
      <Header
        title={
          <span 
            style={{ cursor: 'pointer' }}
            onClick={() => history.push('/hpaas/dashboard')}>
            Hybrid PaaS
          </span>
        }
        showMenuToggle={false}
        icon={
          <img
            src={`${process.env.PUBLIC_URL}/logo_amexwhite.png`}
            style={{
              marginRight: 20,
              width: 'auto',
              height: 40,
              fontSize: '1.5rem',
              color: '#fff',
              cursor: 'pointer',
            }}
            alt="eCP Logo"
            onClick={() => history.push('/hpaas/dashboard')}
          />
        }
        rightContent={
          <div style={{ color: '#fff' }}>
            {/*<Button
              href={cloudHealthLink}
              target="_blank"
              style={{
                fontSize: 'secon',
                marginRight: 12,
                paddingRight: 20,
                color: '#fff',
                textTransform: 'none',
                borderRadius: 0,
              }}
            >
              <StackedButton>
                <HealthIndicatorBadge color="green" />
                <MdCloudQueue size={32} />
                Cloud Health
              </StackedButton>
            
            </Button>*/}
            <IconButton
              style={{
                color: '#fff',
              }}
              onClick={handleMenu}>
                <Avatar style={{background: 'rgb(100, 202, 244)'}}>
                {
                  !okta || !okta.given_name || !okta.family_name ?
                    <FaUserCircle color="#fff" /> :
                    okta.given_name.charAt(0).toUpperCase() + okta.family_name.charAt(0).toUpperCase()
                }
                </Avatar>
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'center',
              }}
              getContentAnchorEl={null}
              keepMounted
              open={open}
              onClose={handleClose}
            >
              {
                !okta || !okta.name ? null : (
                  <MenuItem onClick={() => history.push('/profile')}>
                    <ListItemText primary={okta.name} secondary="View Profile" />
                  </MenuItem>
                )
              }
              <MenuItem onClick={authService.logout}>
                <ListItemIcon>
                  <FiLogOut />
                </ListItemIcon>
                <ListItemText primary="Logout" />
              </MenuItem> 
            </Menu>
          </div>
        }
      />
    </Wrapper>
  )
}
