import React, { useEffect, Fragment } from 'react';
import styled from 'styled-components';
import HPaaSHeader from './HPaaSHeader';
import HPaaSDashboard from './HPaaSDashboard';
import HPaaSFooter from './HPaaSFooter';
import { useSelector, useDispatch } from 'react-redux';

const Wrapper = styled.div``;

const HPaaSManager = () => {
  const dispatch = useDispatch();
  const isFetching = useSelector(state => state.wspaces.isFetching);

  useEffect(() => {
    dispatch.wspaces.getWorkspaces();
  }, [dispatch]);

  const workspaces = useSelector(state => state.wspaces.workspaces);

  return (
    <Wrapper>
      <HPaaSHeader />
      <HPaaSDashboard workspaces={workspaces} isFetchingWorkspaces={isFetching} />
      <HPaaSFooter />
    </Wrapper>
  )
}

export default HPaaSManager;
