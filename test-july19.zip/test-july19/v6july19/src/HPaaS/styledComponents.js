import React from 'react';
import styled from 'styled-components';

const TopBar = styled.div`
  display: flex;
  flex-direction: column;  
  padding: 12px 24px 0 24px;
  box-shadow: 0 0 6px 5px rgba(0, 0, 0, 0.1);
  z-index: 11;
`;

const TopBarActions = styled.div`
  display: flex;
  padding: 10px 0 15px 0;

  > h6 {
    display: inline-block;
    flex-grow: 1;
  }

  > button {
    margin-right: 10px;
  }
`;

const FormElementWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: row;
  margin-bottom: 5px;

  > :first-child {
    max-width: calc(100% - 64px);
  }
`;

export { TopBar, TopBarActions, FormElementWrapper };