import { fetchWorkspaces, createWorkspace, fetchWorkspace, updateWorkspace } from './workspaceService';
import history from '../App/history';
import { getUserAdsId } from './common/utils';

const initialState = {
  workspaces: [],
  workspace: {},
  response: {},
  isFetching: false,
};

const model = {
  state: { ...initialState },

  reducers: {
    storeWorkspaces: (state, workspaces) => ({
      ...state,
      workspaces,
    }),
    storeWorkspace: (state, workspace) => ({
      ...state,
      workspace,
    }),
    storeParams: (state, params) => ({
      ...state,
      ...params,
    }),
    resetModel: (state) => ({...initialState}),
    setResponse: (state, response) => ({ ...state, response }),
    setIsFetching: (state, isFetching) => ({ ...state, isFetching }),
  },

  effects: dispatch => ({
    async getWorkspaces(payload, state) {
      this.setIsFetching(true);
      const workspacesResponse = await fetchWorkspaces(state.app.okta.idToken, getUserAdsId(state.app.okta.preferred_username));
      if (workspacesResponse && workspacesResponse.status === "success") {
        dispatch.wspaces.storeWorkspaces(workspacesResponse.data);
        this.setIsFetching(false);
      } else {
        // handle error here
        console.log('error fetching workspaces');
        this.setIsFetching(false);
      }
    },

    async getWorkspace(payload, state) {
      const workspaceRes = await fetchWorkspace(payload, state.app.okta.idToken); 
      if (workspaceRes && workspaceRes.status === "success") {
        dispatch.wspace.storeWorkspace(workspaceRes.data);
      } else {
        // handle error here
        console.log('error fetching workspace');
      }
    },

    async submitCreateWorkspaceForm(payload, state) {
      const workspacesResponse = await createWorkspace(payload, state.app.okta.idToken);
      let workspaceRes = {};

      //check for success
      if (workspacesResponse && workspacesResponse.status === "success") {
        workspaceRes = {
          "status": workspacesResponse.status,
          "message": "Workspace created successfully.",
        };
        dispatch.wspace.resetModel();
        dispatch.wspace.setResponse(workspaceRes);
        history.push('/hpaas/dashboard');
        history.go('/hpaas/dashboard');
      }

      //check for error 
      if (workspacesResponse && workspacesResponse.status === "fail") {
        let errorsObj = workspacesResponse.errors ;
        let message = Object.keys(errorsObj)[0] + ":" + errorsObj[Object.keys(errorsObj)[0]]; 

        workspaceRes = {
          "status": workspacesResponse.status,
          "message": message,
        };

        dispatch.wspace.resetModel();
        dispatch.wspace.setResponse(workspaceRes);
      }
    },

    async submitEditWorkspaceForm(payload, state) {
      const workspaceResponse = await updateWorkspace(payload, state.app.okta.idToken);
      dispatch.wspace.getWorkspace(payload.workspaceName);
      let workspaceRes = {};

      if(workspaceResponse) {
        workspaceRes = {
          "status": "success",
          "message": "Workspace updated successfully.",
        };
        dispatch.wspace.resetModel();
        dispatch.wspace.setResponse(workspaceRes);
      }
      
    },

  })
}

export default model;
