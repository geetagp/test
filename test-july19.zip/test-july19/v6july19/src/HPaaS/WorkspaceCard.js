import React, { Fragment } from 'react'
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { Menu, MenuItem, Link, Typography, Card, CardHeader, CardContent } from '@material-ui/core';
import { format } from 'date-fns';

const getStatusElement = (status) => {
  switch(status) {
    case "pending":   return <span style={{ color: '#006fcf', fontSize: 12, fontWeight: 600 }}>pending approval</span>;
    case "success":  return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>success</span>;
    //case "pending":  return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>success</span>;
    case "approved": return <span style={{ color: 'green', fontSize: 12, fontWeight: 600}}>approved</span>;
    case "rejected": return <span style={{ color: 'red', fontSize: 12, fontWeight: 600}}>rejected</span>;
    case "undefined":  return <span style={{ color: 'gray', fontSize: 12, fontWeight: 600}}>not defined</span>;
    default:      return <span></span>
  }
}

function WorkspaceCard({ workspace }) {
  const { workspaceName, status } = workspace;
  const { createdAt } = workspace.metadata;

  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <Card elevation={0} style={{ height: '90%', border: '1px solid rgba(0,0,0,0.15)'}}>
      <CardHeader
        title={<Typography gutterBottom variant="subtitle1">{workspaceName}</Typography>}
        subheader={<Typography variant="body2">{getStatusElement(!status ? 'undefined' : status)}</Typography>}
        action={
          <Fragment>
            <Typography variant="body2" style={{ cursor: 'pointer'}}>
              <MoreVertIcon onClick={handleClick}/>
            </Typography>
            <Menu
              key={workspace.id}
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'center',
              }}
              getContentAnchorEl={null}
              keepMounted
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <MenuItem><Link href={`/hpaas/workspace/${workspaceName}/edit`}>Update Workspace</Link></MenuItem>
              <MenuItem><Link href={`/hpaas/workspace/${workspaceName}/service/create`}>Create Application</Link></MenuItem>
              <MenuItem><Link href={`/hpaas/workspace/${workspaceName}`}>List Applications</Link></MenuItem>
            </Menu>
          </Fragment>
        } />
      <CardContent>
        <Typography variant="body2" color="textSecondary" style={{marginTop: 0}}> 
          {
            !createdAt ? 'No timestamp provided.' : 'Created ' + format(new Date(createdAt), 'MMM dd, yyyy')
          }
          {/* Created { format(new Date(creationTimestamp), 'MMM dd, yyyy') } */}
        </Typography>
      </CardContent>
    </Card>
  )
}

WorkspaceCard.propTypes = {

}

export default WorkspaceCard

