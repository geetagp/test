import { getApiHost } from './common/environment';
const apiHost = getApiHost();

//const WORKSPACE_API_URL =  'https://' + apiHost + '/workspaces';
const WORKSPACE_API_URL =  'https://engv5bomapi-dev.aexp.com/v5/workspaces';

export const fetchWorkspaces = async (idToken, userId) => {
  let responseObj = {data: {}, status: ''};
  return new Promise(async (resolve, reject) => {
    fetch(WORKSPACE_API_URL + `?user=${userId}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${idToken}`,
      }
    })
    .then(res => { 
      if (res.ok) {
        res.json().then((data) => {
          responseObj.data = data; 
          responseObj.status = "success"; 
          resolve(responseObj); 
        });
      }
      else{
        responseObj.data = res.statusText; 
        responseObj.status = "fail"; 
        resolve(responseObj); 
      }
    })
    .catch(err => reject(err));
    });
 }

export const createWorkspace = async (formData, idToken) => {
  let responseObj = {data: {}, status: ''};
  return new Promise(async (resolve, reject) => {
    return await fetch(WORKSPACE_API_URL, {
      method: 'POST',
      body: JSON.stringify(formData),
      headers: {
        Authorization: `Bearer ${idToken}`,
      }
    })
    .then(res => { 
      if (res.ok) {
        res.json().then((data) => {
          responseObj.data = data; 
          responseObj.status = "success"; 
          resolve(responseObj); 
        });
      }
      else{
        res.json().then((data) => {
          responseObj.errors = data; 
          responseObj.status = "fail"; 
          resolve(responseObj); 
        });
      }
    })
    .catch(err => reject(err));
   });
}

export const fetchWorkspace = async (id, idToken) => {
  let responseObj = {data: {}, status: ''};
  return new Promise(async (resolve, reject) => {
      //return await fetch(`${WORKSPACE_API_URL}?workspaceName=${id}`, {
      return await fetch(WORKSPACE_API_URL + `?user=gpawar`, { // fake call to get first workspace - for now - since api is not ready
      method: 'GET',
      headers: {
        Authorization: `Bearer ${idToken}`,
      }
    })
    .then(res => { 
      if (res.ok) {
        res.json().then((data) => {
          responseObj.data = data[0]; 
          console.log(data[0]);
          responseObj.status = "success"; 
          resolve(responseObj); 
        });
      }
      else{
        responseObj.data = res.statusText; 
        responseObj.status = "fail"; 
        resolve(responseObj); 
      }
    })
    .catch(err => reject(err));
   });
}

export const updateWorkspace = async (formData, idToken) => {
  return new Promise(async (resolve, reject) => {

    return await fetch(`${WORKSPACE_API_URL}/${formData.workspaceName}`, {
      method: 'PATCH',
      body: JSON.stringify(formData.patchData),
      headers: {
        'Content-Type': 'application/json',
         Authorization: `Bearer ${idToken}`,
      },
    })
    .then(res => {
      if (res.status === 204) {
        resolve(true);
      }
      console.log(res);
    })
    .catch(err => reject(err));

  });
}
