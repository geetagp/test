import React, { useEffect, useState } from 'react'
import { Grid, Typography, Tab, Tabs, Divider, Link, Button, Breadcrumbs, CircularProgress } from '@material-ui/core';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components';

import HPaaSHeader from '../HPaaSHeader';
import HPaaSFooter from '../HPaaSFooter';
import GeneralEditForm from './GeneralEditForm';
import GroupsEditForm from './GroupsEditForm';
import { TopBar, TopBarActions } from '../styledComponents';
import { useParams, useHistory } from 'react-router-dom';
import { generateWorkspaceUpdateObj } from '../common/utils';
import EnvironmentConfig from './EnvironmentConfig';


const Wrapper = styled.div`
  //padding: 12px;
  display: flex;
  flex-grow: 1;

  .form-info {
    padding: 0 40px 0 0;
  }
  
`;

function EditWorkspace(props) {
  const dispatch = useDispatch();
  const [ currentTab, setCurrentTab ] = useState(0);
  const { workspaceId } = useParams();
  const workspace = useSelector(state => state.wspace.workspace);
  const response = useSelector(state => state.wspace.response);
  const history = useHistory();

  const methods = useForm({
    reValidateMode: 'onBlur',
    mode: 'onBlur',
    validateCriteriaMode: "firstErrorDetected",
    submitFocusError: true,
    nativeValidation: false,
  });

  const { handleSubmit, formState, reset } = methods;

  useEffect(() => {
    reset();
    dispatch.wspace.resetModel();
    dispatch.wspace.getWorkspace(workspaceId);
    dispatch.wspace.setResponse('');

    return () => {
      dispatch.wspace.resetModel();
    }
  }, [dispatch, workspaceId]);

  const onSubmit = async data => {
    const workspaceUpdateObj = generateWorkspaceUpdateObj(data, workspace);
    let workspaceSubmitObj = {};
    workspaceSubmitObj.workspaceName = data.workspaceName;
    workspaceSubmitObj.patchData = workspaceUpdateObj;

    console.log(workspaceSubmitObj.patchData);
    if (workspaceSubmitObj.patchData.length > 0 ) {
      const editeWorkspaceRes = await dispatch.wspace.submitEditWorkspaceForm(workspaceSubmitObj);
    } else {
      dispatch.wspace.setResponse({status: "success", message: 'No changes detected to Workspace metadata.'});
    }
  }


  const displayResponse = (response) => {
    switch(response.status) {
      case "success":   return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>{response.message}</span>;
      case "error":   return <span style={{ color: 'red', fontSize: 12, fontWeight: 600}}>{response.message}</span>;
      default: return <span></span>
    }
  }

  const onReset = () => {
    reset();
    dispatch.wspace.resetModel();
    history.push(`/hpaas/dashboard`);
  }

  return (
    <Wrapper>
      <HPaaSHeader user='suser' host='localhost' resetModel='false' />
        <Grid container style={{ flex: 1 }}>
          <Grid item xs={12}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <TopBar>
                <Breadcrumbs separator="›" aria-label="breadcrumb">
                  <Link color="inherit" onClick={onReset}>
                    Dashboard
                  </Link>
                  <Typography color="textPrimary">Update Workspace</Typography>
                </Breadcrumbs>

                <TopBarActions>
                  <Typography variant="h6">
                    Service Settings
                  </Typography>
                  <Typography variant="subtitle1">
                    {displayResponse(response)}
                  </Typography>
                  <Button variant="contained" color="primary" spacing={2} type="submit" disabled={!formState.isValid}>
                    Save
                  </Button>
                  <Button variant="contained" color="default" onClick={onReset} type="button">
                    Cancel
                  </Button>
                </TopBarActions>
              </TopBar>

              <Divider light align="bottom"/>
              <Tabs
                indicatorColor="primary"
                textColor="primary"
                value={currentTab}
                onChange={(e, newTab) => setCurrentTab(newTab)}>
                <Tab label="General" />
                <Tab label="Workgroups" />
                <Tab label="Environment Configuration" />
              </Tabs>

              <div style={{padding: '24px 12px 12px', display: 'flex', flexGrow: 1, flex: 1}}>
                <Grid container>
                  <Grid item xs={12} md={4} xl={3}>
                    <div className="form-info">
                      <div
                        style={{
                          visibility: currentTab === 0 ? 'visible' : 'hidden',
                          height: currentTab === 0 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          General Information 
                        </Typography>
                        <Typography variant="caption">
                          General Information regarding a workspace needs to be provided. 
                        </Typography>
                      </div>
                      <div
                        style={{
                          visibility: currentTab === 1 ? 'visible' : 'hidden',
                          height: currentTab === 1 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          Workgroup Information 
                        </Typography>
                        <Typography variant="caption">
                          Workgroups Information regarding a workspace needs to be provided. 
                        </Typography>
                      </div>
                      <div
                        style={{
                          visibility: currentTab === 2 ? 'visible' : 'hidden',
                          height: currentTab === 3 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          Environment Information 
                        </Typography>
                        <Typography variant="caption">
                          Environment Information regarding a workspace needs to be provided. 
                        </Typography>
                      </div>
                    </div>
                  </Grid>
                  {
                    !workspace || !workspace.workspaceName ? (
                      <Grid item xs={12} md={8} xl={9}>
                        <CircularProgress style={{marginRight: 12}} />
                        Loading ...
                      </Grid>
                    ) : (
                      <Grid item xs={12} md={8} xl={9}>
                        <div
                          style={{
                            visibility: currentTab === 0 ? 'visible' : 'hidden',
                            height: currentTab === 0 ? 'auto' : 0,
                          }}>
                          <GeneralEditForm workspace={workspace} { ...methods } />
                        </div>
                        <div
                          style={{
                            visibility: currentTab === 1 ? 'visible' : 'hidden',
                            height: currentTab === 1 ? 'auto' : 0,
                          }}>
                          <GroupsEditForm workspace={workspace} { ...methods } /> 
                        </div>
                        <div
                      style={{
                        visibility: currentTab === 2 ? 'visible' : 'hidden',
                        height: currentTab === 2 ? 'auto' : 0,
                      }}>
                      <EnvironmentConfig workspace={workspace} action="edit" { ...methods } />
                    </div>
                      </Grid>
                    )
                  }
                </Grid>
              </div>
    
            </form>
          </Grid>
        </Grid>
      <HPaaSFooter />
    </Wrapper>
  )
}

export default EditWorkspace;
