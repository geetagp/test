import React, { Fragment } from 'react'
import { Typography, TextField, Button } from '@material-ui/core';
import { FormElementWrapper } from '../styledComponents';
import { HtmlTooltip } from '../common/utils';

const GroupsForm = ({ errors, register, control }) => {
  return (
    <div style={{padding: '0 12px 12px'}}>
      
      <Typography variant="subtitle1">
        Update Workgroup information 
      </Typography>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: false,
                message: 'ServiceNow Workgroup name is required.',
              },
              minLength: {
                value: 3,
                message: 'ServiceNow Workgroup name should be min 3 char.',
              },
              maxLength: {
                value: 20,
                message: 'ServiceNow Workgroup name should be max 20 char.',
              },
            
            })
          }
          error={errors.hasOwnProperty('serviceNowWorkGroupName')}
          helperText={errors.hasOwnProperty('serviceNowWorkGroupName') && errors.serviceNowWorkGroupName.message}
          name="serviceNowWorkGroupName"
          id="serviceNowWorkGroupName"
          placeholder="Enter ServiceNow Workgroup Name"
          label="ServiceNow Workgroup Name"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Workgroup Name</Typography>
            <em>{"Enter workgroup name"}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

    </div>
  )
}

GroupsForm.propTypes = {

}

export default GroupsForm
