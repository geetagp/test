import React, { useState } from 'react'
import PropTypes from 'prop-types'
import { Button, IconButton, Dialog, DialogTitle, DialogContent, DialogContentText, TextField, DialogActions } from '@material-ui/core';
import MUIDataTable from 'mui-datatables';
import { MdEdit, MdDelete, MdAdd } from 'react-icons/md';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

export function CreateEditEnvDialog(props) {
  const { action, serviceEntry } = props;
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      {
        action === 'edit' ? (
          <IconButton onClick={handleClickOpen}>
            <MdEdit />
          </IconButton>
        ) : (
          <Button
            onClick={handleClickOpen}
            startIcon={<MdAdd />}
            style={{ marginBottom: 20 }}>
            Add Service Entry
          </Button>
        )
      }
      
      <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
        <DialogTitle>
          { action === 'edit' ? 'Edit entry' : 'Create entry' }
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            Some information about adding/editing an environment config entry.
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="protocol"
            label="Protocol"
            type="text"
            fullWidth
          />
          <TextField
            margin="dense"
            id="ports"
            label="Ports"
            type="number"
            fullWidth
          />
          <TextField
            margin="dense"
            id="host"
            label="Host"
            type="url"
            fullWidth
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleClose} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export function DeleteEnvDialog(props) {
  const { action, serviceEntry } = props;
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <IconButton onClick={handleClickOpen}>
        <MdDelete />
      </IconButton>
      <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
        <DialogTitle>Delete entry</DialogTitle>
        <DialogContent>
          <DialogContentText>
            This cannot be undone, are you sure?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleClose} color="primary">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}
