import React, { Fragment } from 'react'
import { Typography, TextField, Button } from '@material-ui/core';
import { FormElementWrapper } from '../styledComponents';
import { HtmlTooltip } from '../common/utils';

const GeneralForm = ({ errors, register, control }) => {
  return (
    <div style={{padding: '0 12px 12px'}}>
      
      <Typography variant="subtitle1">
        Update general information 
      </Typography>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Workspace name is required.',
              },
              minLength: {
                value: 3,
                message: 'Workspace name should be min 3 char.',
              },
              maxLength: {
                value: 63,
                message: 'Workspace name should be max 63 char.',
              },
              pattern: {
                value: /^[a-z]([-a-z0-9]*[a-z0-9])?$/,
                message: `Workspace names may only contain lower-case letters, numbers and dashes (-). Can't start or end with a dash. Can't start with a number.`
              }
            })
          }
          error={errors.hasOwnProperty('workspaceName')}
          helperText={errors.hasOwnProperty('workspaceName') && errors.workspaceName.message}
          name="workspaceName"
          id="workspaceName"
          placeholder="Enter Workspace Name"
          label="* Workspace Name"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Workspace Name</Typography>
            <em>{"Enter an unique name of a workspace"}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'CAR Id is required.',
              },
              pattern: {
                value: /[0-9]/,
                message: `CAR Id should contain only numbers.`
              },
              pattern: {
                value: /^\d{9}$/,
                message: `CAR Id should contain exactly 9 digits.`
              },
            })
          }
          error={errors.hasOwnProperty('carId')}
          helperText={errors.hasOwnProperty('carId') && errors.carId.message}
          name="carId"
          id="carId"
          placeholder="Enter CAR ID"
          label="* CAR ID"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">CAR ID</Typography>
            <em>{"Learn more about CAR (Central Asset Registry)"}</em> <a href='https://square.americanexpress.com/docs/DOC-55683' target='_blank'>here</a>
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>


      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Business Justification is required.',
              },
              minLength: {
                value: 20,
                message: 'Business Justification should be min 20 char.',
              },
              maxLength: {
                value: 253,
                message: 'Business Justification should be max 253 char.',
              }
            })
          }
          error={errors.hasOwnProperty('businessJustification')}
          helperText={errors.hasOwnProperty('businessJustification') && errors.businessJustification.message}
          name="businessJustification"
          id="businessJustification"
          placeholder="Enter Business Justification"
          label="* Business Justification"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Business Justification</Typography>
            <em>{"Enter details about why you want to create this workspace."}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Members are required.',
              }
            })
          }
          error={errors.hasOwnProperty('members')}
          helperText={errors.hasOwnProperty('members') && errors.members.message}
          name="members"
          id="members"
          placeholder="Enter Members"
          label="* Members"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Members</Typography>
            <em>{"Members' ADS ids, should be separated by commas"}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Description is required.',
              },
              minLength: {
                value: 10,
                message: 'Description should be min 10 char.',
              },
              maxLength: {
                value: 253,
                message: 'Description should be max 253 char.',
              }
            })
          }
          error={errors.hasOwnProperty('description')}
          helperText={errors.hasOwnProperty('description') && errors.description.message}
          name="description"
          id="description"
          placeholder="Enter Description"
          label="* Description"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Description</Typography>
            <em>{"Enter the workspace description."}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

          
    </div>
  )
}

GeneralForm.propTypes = {

}

export default GeneralForm
