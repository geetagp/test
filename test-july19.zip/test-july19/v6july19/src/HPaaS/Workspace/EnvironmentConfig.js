import React, { useState } from 'react'
import PropTypes from 'prop-types'
import { Button, IconButton, Dialog, DialogTitle, DialogContent, DialogContentText, TextField, DialogActions } from '@material-ui/core';
import MUIDataTable from 'mui-datatables';
import { MdEdit, MdDelete, MdAdd } from 'react-icons/md';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  CreateEditEnvDialog,
  DeleteEnvDialog
} from './EnvironmentConfigDialogs';

const tableHeadData = [
  { name: 'serviceEntry.id', label: 'ID' },
  { name: 'serviceEntry.protocol', label: 'Protocol' },
  {
    name: 'serviceEntry.ports',
    label: 'Ports',
    options: {
      customBodyRender: ports => ports.join(','),
    }
  },
  { name: 'serviceEntry.host', label: 'Host' },
  {
    name: 'serviceEntry', 
    label: 'Edit',
    options: {
      customBodyRender: serviceEntry => <CreateEditEnvDialog serviceEntry={serviceEntry} action="edit" />,
    },
  },
  {
    name: 'serviceEntry', 
    label: 'Delete',
    options: {
      customBodyRender: serviceEntry => <DeleteEnvDialog serviceEntry={serviceEntry} />,
    },
  }
];

const environmentConfigs = [
  {
    "env": "e1",
    "serviceEntries": [
      {
        "serviceEntry": {
          "id":  1,
          "protocol": "https",
          "ports": [
            443,
            8433
          ],
          "host": "abc-qa.aexp.com"
        }
      },
      {
        "serviceEntry": {
          "id":  2,
          "protocol": "https",
          "ports": [
            443
          ],
          "host": "abc1-qa.aexp.com"
        }
      }
    ]
  }
];

function EnvironmentConfig(props) {
  const configEntries = props.action === 'edit' ? environmentConfigs[0].serviceEntries : [];

  return (
    <div>
      <h2>Environment Configuration E1 ({configEntries.length})</h2>
      <CreateEditEnvDialog action="create" />
      <MUIDataTable
        columns={tableHeadData}
        data={configEntries}
        title={null}
        options={{
          selectableRows: 'none',
          search: false,
          print: false,
          download: false,
          viewColumns: false,
          filter: false,
          elevation: 1,
          rowsPerPage: 5,
          textLabels: {
            body: {
              noMatch: 'You have no environment configurations. Start by clicking the "Add Service Entry" button above.'
            }
          }
        }}
      />
    </div>
  )
}

EnvironmentConfig.propTypes = {

}

export default EnvironmentConfig
