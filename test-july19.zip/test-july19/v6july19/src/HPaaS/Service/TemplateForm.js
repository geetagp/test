import React, { Fragment } from 'react'
import PropTypes from 'prop-types'
import { Typography, TextField, Select, FormControl, InputLabel, Button } from '@material-ui/core';
import { useForm, Controller } from 'react-hook-form';
import { FormElementWrapper } from '../styledComponents';
import { HtmlTooltip } from '../common/utils';

const TemplateForm = ({ errors, register, control }) => {

  return (
    <div style={{padding: '0 12px 12px'}}>
      
      <Typography variant="subtitle1">
        Enter template information 
      </Typography>

      <FormElementWrapper>
        <FormControl fullWidth  style={{margin: '30px 0 15px 0'}}>
          <InputLabel htmlFor="age-native-simple">* Template Type</InputLabel>
          <Controller
            as={(
              <Select>
                <option value='byoi'>Bring Your Own Image</option>
                <option value='other' disabled={true}>other</option>
              </Select>
            )}
            control={control}
            inputRef={
              register({
                required: {
                  value: true,
                  message: 'Template Type is required.',
                },
              })
            }
            error={errors.hasOwnProperty('region')}
            native
            value='byoi'
            id="template"
            name="template"
          />
        </FormControl>
        <HtmlTooltip interactive
          title={
            <Fragment>
              <Typography color="inherit">Template Type</Typography>
              <em>{"Template Type default is Bring your owm image."}</em> <a href='' target='_blank'></a>
            </Fragment>
          }>
          <Button>?</Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Image Repository name is required.',
              }
            })
          }
          error={errors.hasOwnProperty('imageRepo')}
          helperText={errors.hasOwnProperty('imageRepo') && errors.imageRepo.message}
          name="imageRepo"
          id="imageRepo"
          placeholder="Enter Image Repository Name"
          label="* Image Repository Name"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Image Repository Name</Typography>
            <em>{"Image Repository Name of your application. example: gcr.io/ecp-e0-svc-gcr-paas-200005750/cicd/hpaas-jar-poc"}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'NFS mount path is required.',
              }
            })
          }
          error={errors.hasOwnProperty('nfsMountPath')}
          helperText={errors.hasOwnProperty('nfsMountPath') && errors.nfsMountPath.message}
          name="nfsMountPath"
          id="nfsMountPath"
          placeholder="Enter NFS Mount Path"
          label="* NFS Mount Path"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">NFS Mount Path</Typography>
            <em>{"NFS Mount Path example: /mnt/volume"}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'CD Url is required.',
              }
            })
          }
          error={errors.hasOwnProperty('cdUrl')}
          helperText={errors.hasOwnProperty('cdUrl') && errors.cdUrl.message}
          name="cdUrl"
          id="cdUrl"
          placeholder="Enter CD Url"
          label="* CD Url"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">CD Url</Typography>
            <em>{"CD Url example: https://cd.aexp.com/id"}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

    </div>
  )
}

TemplateForm.propTypes = {

}

export default TemplateForm
