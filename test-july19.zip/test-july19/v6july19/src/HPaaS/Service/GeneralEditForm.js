import React, { Fragment } from 'react'
import { Typography, TextField, Select, Checkbox, FormControl, InputLabel, FormControlLabel, Button, Radio, RadioGroup, FormLabel } from '@material-ui/core';
import { Controller } from 'react-hook-form';

import { FormElementWrapper } from '../styledComponents';
import { HtmlTooltip } from '../common/utils';

const GeneralForm = ({ errors, register, control, watch, application }) => {
  const gdha = watch('gdha');
  const { serviceName } = application;
  const { description, region, pii, deploymentMethod, gtm, maxEnv } = application.metadata;

  return (
    <div style={{padding: '0 12px 12px'}}>
      
      <Typography variant="subtitle1">
        Update general information 
      </Typography>
      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Application name is required.',
              },
              maxLength: {
                value: 16,
                message: 'Application name name should be max 16 char',
              },
              pattern: {
                value: /^[a-z]([-a-z0-9]*[a-z0-9])?$/,
                message: `Application names may only contain lower-case letters, numbers and dashes (-). Can't start or end with a dash. Can't start with a number.`
              }
            })
          }
          error={errors.hasOwnProperty('serviceName')}
          helperText={errors.hasOwnProperty('serviceName') && errors.serviceName.message}
          name="serviceName"
          id="serviceName"
          placeholder="Enter Application Name"
          label="* Application Name"
          margin="dense"
          fullWidth
          disabled
          defaultValue={serviceName}
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Application Name</Typography>
            <em>{"A unique name of a service"}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Application description is required.',
              },
              minLength: {
                value: 10,
                message: 'Application description should be min 10 char.',
              },
              maxLength: {
                value: 253,
                message: 'Application description should be max 253 char.',
              },
            })
          }
          error={errors.hasOwnProperty('description')}
          helperText={errors.hasOwnProperty('description') && errors.description.message}
          name="description"
          id="description"
          placeholder="Enter Application Description"
          label="* Application Description"
          margin="dense"
          fullWidth
          defaultValue={description}
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Application Description</Typography>
            <em>{""}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <FormControl fullWidth  style={{margin: '10px 0 15px 0'}}>
          <InputLabel htmlFor="age-native-simple">* Application Type</InputLabel>
          <Controller
            as={(
              <Select>
                <option value='intranet'>Intranet</option>
                <option value='internet' disabled={true}>Internet</option>
              </Select>
            )}
            control={control}
            inputRef={
              register({
                required: {
                  value: true,
                  message: 'Application Type is required.',
                },
              })
            }
            error={errors.hasOwnProperty('region')}
            native
            value="intranet"
            id="region"
            name="region"
            defaultValue={region}
            disabled
          />
        </FormControl>
        <HtmlTooltip interactive
          title={
            <Fragment>
              <Typography color="inherit">Application Type - Internet </Typography>
              <em>{"On-boarding internet applications requires "}</em> <a href='https://enterprise-confluence.aexp.com/confluence/display/ED/Creating+a+Team+Project#CreatingaTeamProject-1' target='_blank'>additional steps.</a>
            </Fragment>
          }>
          <Button>?</Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper>
        <FormControlLabel
          label="Personal Identifiable Information"
          control={
            <Controller
              as={<Checkbox />}
              control={control}
              color="primary"
              name="pii"
              id="pii"
              disabled
              defaultValue={pii}
            />
          } />
        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">PII </Typography>
          <em>{"Application requires access to downstream systems with personal identifiable information (PII) like customer names, social security numbers, etc."}</em> 
          </Fragment>
          }
          >
          <Button>?</Button>
        </HtmlTooltip>
      </FormElementWrapper> 

      <FormElementWrapper style={{margin: '30px 0'}}>
        <FormControl component="fieldset">
          <FormLabel component="legend">Maximum Environment</FormLabel>
          <Controller 
            as={
              <RadioGroup aria-label="maxEnv">
                <FormControlLabel value="e1" control={<Radio />} label="E1 Only" disabled/>
                <FormControlLabel value="e2" control={<Radio />} label="E1 and E2 Only"  disabled/>
                <FormControlLabel value="e3" control={<Radio />} label="All Environments - E1, E2 and E3" disabled/>
              </RadioGroup>
            }
            control={control}
            name="maxEnv"
            id="maxEnv"
            margin="dense"
            defaultValue={maxEnv}
            />
        </FormControl>
      </FormElementWrapper>

      <FormElementWrapper style={{margin: '30px 0'}}>
        <FormControl component="fieldset">
          <FormLabel component="legend">Deployment Method</FormLabel>
          <Controller 
            as={
              <RadioGroup aria-label="deploymentMethod">
                <FormControlLabel value="rolling" control={<Radio />} label="Rolling deployment – reduce risk further by enabling application health check with each increment" disabled />
                <FormControlLabel value="bluegreen" control={<Radio />} label=" Blue/Green deployment – enable instantaneous switching back to previous application version in the event latest deployed version suffered unexpected failure" disabled />
                {/*<FormControlLabel value="live_stage" control={<Radio />} label="Live Stage deployment" disabled />
                <FormControlLabel value="canary" control={<Radio />} label="Canary deployment" disabled />*/}
              </RadioGroup>
            }
            control={control}
            name="deploymentMethod"
            id="deploymentMethod"
            margin="dense"
            defaultValue={deploymentMethod}
            />
        </FormControl>
      </FormElementWrapper>

      <FormElementWrapper>
        <FormControlLabel
          label="Enable GDHA"
          control={
            <Controller
              as={<Checkbox />}
              control={control}
              color="primary"
              name="gdha"
              id="gdha"
              defaultValue={application.metadata.gdha}
            />
          } />
        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">GDHA </Typography>
          <em>{""}</em> 
          </Fragment>
          }
          >
          <Button>?</Button>
        </HtmlTooltip>
      </FormElementWrapper> 

      {gdha && (
        <FormElementWrapper>
          <FormControl component="fieldset">
            <FormLabel component="legend">Deployment Mode</FormLabel>
            <Controller 
              as={
                <RadioGroup aria-label="gtm">
                  <FormControlLabel value="active_passive" control={<Radio />} label="Active-Passive" disabled />
                  <FormControlLabel value="active_active" control={<Radio />} label="Active-Active" disabled />
                  <FormControlLabel value="other" control={<Radio />} label="Other" disabled />
                  <FormControlLabel value="nogdha" control={<Radio />} label="No GDHA" disabled/>
                </RadioGroup>
              }
              control={control}
              name="gtm"
              id="gtm"
              margin="dense"
              defaultValue={gtm}
            />
        </FormControl>
      </FormElementWrapper>
    )}
    </div>
  )
}

GeneralForm.propTypes = {

}

export default GeneralForm
