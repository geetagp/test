import React from 'react'
import PropTypes from 'prop-types'
import { HtmlTooltip } from '../common/utils';

const EnvConfigForm = props => {
  return (
    <div>
      env config form
    </div>
  )
}

EnvConfigForm.propTypes = {

}

export default EnvConfigForm
