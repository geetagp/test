import React, { Fragment } from 'react'
import { Typography, TextField, FormControl, FormControlLabel, Button, RadioGroup, Radio, FormLabel, Checkbox } from '@material-ui/core';
import { Controller } from 'react-hook-form';
import { FormElementWrapper } from '../styledComponents';
import { HtmlTooltip } from '../common/utils';

const HealthCheckForm = ({ errors, register, control, watch }) => {

  const routable = watch('routable'); 
  const gdha = watch('gdha');
  return (
    <div style={{padding: '0 12px 12px'}}>
      <Typography variant="subtitle1">
        Health Check information 
      </Typography>

      <FormElementWrapper style={{margin: '10px 0 15px 0'}}>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'GTM Health Check URI is required.',
              }
            })
          }
          error={errors.hasOwnProperty('gtmHealthcheckUri')}
          helperText={errors.hasOwnProperty('gtmHealthcheckUri') && errors.gtmHealthcheckUri.message}
          name="gtmHealthcheckUri"
          id="gtmHealthcheckUri"
          defaultValue="/"
          placeholder="Enter GTM Health Check URI"
          label="* Enter GTM Health Check URI"
          margin="dense"
          fullWidth
          disabled={!gdha}
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">GTM Health Check URI</Typography>
            <em>{""}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper style={{margin: '10px 0 15px 0'}}>
        <TextField
          inputRef={
            register({
              required: {
                value: true,
                message: 'Application URL Prefix is required.',
              },
              maxLength: {
                value: 30,
                message: 'Application URL Prefix should be max 30 char',
              },
              pattern: {
                value: /^[a-z0-9]*$/,
                message: `Application URL prefix can only include letters, numbers and be 30 characters or less.`
              }
            })
          }
          error={errors.hasOwnProperty('applicationUrlPrefix')}
          helperText={errors.hasOwnProperty('applicationUrlPrefix') && errors.applicationUrlPrefix.message}
          name="applicationUrlPrefix"
          id="applicationUrlPrefix"
          placeholder="Enter Application URL Prefix"
          label="* Application URL Prefix"
          margin="dense"
          fullWidth
        />

        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Application URL Prefix</Typography>
            <em>{"Prefix to be used for each environment's application URLs."}</em> 
          </Fragment>
          }
          >
          <Button size="small">?
          </Button>
        </HtmlTooltip>
      </FormElementWrapper>

      <FormElementWrapper style={{margin: '15px 0'}}>
        <FormControlLabel
          label="Enable Routability"
          control={
            <Controller
              as={<Checkbox />}
              control={control}
              color="primary"
              name="routable"
              id="routable"
              defaultValue= {true}
            />
          } />
        <HtmlTooltip interactive
          title={
          <Fragment>
          <Typography color="inherit">Routable </Typography>
          <em>{""}</em> 
          </Fragment>
          }
          >
          <Button>?</Button>
        </HtmlTooltip>
      </FormElementWrapper> 

      {routable && (
        <FormElementWrapper>
          <FormControl component="fieldset">
            <FormLabel component="legend">SSO</FormLabel>
            <Controller 
              as={
                <RadioGroup aria-label="sso">
                  <FormControlLabel value="auth_blue" control={<Radio />} label="Routable with AuthBlue SSO." disabled/>
                  <FormControlLabel value="default" control={<Radio />} label="Routable with SSO - Application is accessible from outside project. All application pages require SSO authentication." disabled/>
                  <FormControlLabel value="other" control={<Radio />} label="Other" disabled/>
                </RadioGroup>
              }
              control={control}
              name="sso"
              id="sso"
              margin="dense"
              value="auth_blue"
              disabled
              />
          </FormControl>
        </FormElementWrapper>
      )}
    </div>
  )
}

HealthCheckForm.propTypes = {

}

export default HealthCheckForm

