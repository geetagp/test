import React, { useState, useEffect } from 'react'
import { Grid, Typography, Tab, Tabs, Divider, Link, Button, Breadcrumbs } from '@material-ui/core';
import { useForm } from 'react-hook-form';
import { useDispatch, useStore, useSelector } from 'react-redux';
import styled from 'styled-components';

import HPaaSHeader from '../HPaaSHeader';
import HPaaSFooter from '../HPaaSFooter';
import GeneralForm from './GeneralForm';
import HealthCheckForm from './HealthCheckForm';
import PodInfoForm from './PodInfoForm';
import TemplateForm from './TemplateForm';
import { TopBar, TopBarActions} from '../styledComponents';
import { useParams, useHistory } from 'react-router-dom';
import { generateServiceCreateObj } from '../common/utils';

const Wrapper = styled.div`
  display: flex;
  flex-grow: 1;
  flex: 1;
  min-height: 100%;

  .form-info {
    padding: 0 40px 0 0;
  }
  
`;

function CreateService(props) {
  const dispatch = useDispatch();
  const [ currentTab, setCurrentTab ] = useState(0);
  const response = useSelector(state => state.application.response);
  const { workspaceName } = useParams();
  const history = useHistory();

  const createServiceFormDefaults = {
    workspaceName: workspaceName,
    healthcheckUri: '/',
    gtmHealthcheckUri: '/',
    maxEnv: 'e3',
    status: 'pending',
    region: 'intranet',
    pii: false,
    deploymentMethod: 'rolling',
    availability: 'active_passive',
    podSize: 'small',
    logging: 'none',
    gtm: 'active_passive',
    gdha: true,
    sso: 'auth_blue',
    routable: true
  }

  const methods = useForm({
    reValidateMode: 'onBlur',
    mode: 'onBlur',
    validateCriteriaMode: "firstErrorDetected",
    submitFocusError: true,
    nativeValidation: false,
    defaultValues: createServiceFormDefaults,
  });
  const {
    handleSubmit, errors, formState, reset,
  } = methods;

  const store = useStore();
  

  useEffect(() => {
    dispatch.wspace.getWorkspace(workspaceName);
    dispatch.application.setResponse('');
  }, [dispatch, workspaceName]);

  const { workspace } = store.getState().wspace;

  const displayResponse = (response) => {
    switch(response.status) {
      case "success":   return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>{response.message}</span>;
      case "fail":   return <span style={{ color: 'red', fontSize: 12, fontWeight: 600}}>{response.message}</span>;
      default: return <span></span>
    }
  }

  const onSubmit = async data => {
    const serviceSubmitObj = generateServiceCreateObj(data);
    console.log(serviceSubmitObj);
    //const createApplicationRes = await dispatch.application.submitCreateAppicationForm(serviceSubmitObj);
  }

  const onReset = () => {
    reset();
    history.push(`/hpaas/workspace/${workspaceName}`);
  }

  return (
    <Wrapper>
      <HPaaSHeader user='suser' host='localhost' resetModel='false' />
        <Grid container style={{ flex: 1 }}>
          <Grid item xs={12}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <TopBar>
                <Breadcrumbs separator="›" aria-label="breadcrumb">
                  <Link color="inherit" href="/hpaas/dashboard">
                    Dashboard
                  </Link>
                  <Link color="inherit" href={`/hpaas/workspace/${workspaceName}`}>
                    List Applications
                  </Link>
                  <Typography color="textPrimary">Create Application</Typography>
                </Breadcrumbs>

                <TopBarActions>
                  <Typography variant="h6">
                    Service Settings
                  </Typography>
                  <Typography variant="subtitle1">
                    {displayResponse(response)}
                  </Typography>
                  <Button variant="contained" color="primary" spacing={2} type="submit" disabled={!formState.isValid}>
                    Save
                  </Button>
                  <Button variant="contained" color="default" onClick={onReset} type="button">
                    Cancel
                  </Button>
                </TopBarActions>
              </TopBar>

              <Divider light align="bottom"/>
              <Tabs
                indicatorColor="primary"
                textColor="primary"
                value={currentTab}
                onChange={(e, newTab) => setCurrentTab(newTab)}>
                <Tab label="General" />
                <Tab label="Health Check" />
                <Tab label="Pod Info" />
                {/*<Tab label="Template Info" />*/}
                <Tab label="Environment Configuration" disabled />
              </Tabs>

              <div style={{padding: '24px 12px 12px', display: 'flex', flexGrow: 1, flex: 1}}>
                <Grid container>
                <Grid item xs={12} md={4} xl={3}>
                    <div className="form-info">
                      <div
                        style={{
                          visibility: currentTab === 0 ? 'visible' : 'hidden',
                          height: currentTab === 0 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          General Information 
                        </Typography>
                        <Typography variant="caption">
                          General Information regarding an application needs to be provided. 
                        </Typography>
                      </div>
                      <div
                        style={{
                          visibility: currentTab === 1 ? 'visible' : 'hidden',
                          height: currentTab === 1 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          Health Check Information 
                        </Typography>
                        <Typography variant="caption">
                          Health Check Information needs to be provided. 
                        </Typography>
                      </div>
                      <div
                        style={{
                          visibility: currentTab === 2 ? 'visible' : 'hidden',
                          height: currentTab === 2 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          Pod Information 
                        </Typography>
                        <Typography variant="caption">
                          Pod Information needs to be provided. 
                        </Typography>
                      </div>
                      <div
                        style={{
                          visibility: currentTab === 3 ? 'visible' : 'hidden',
                          height: currentTab === 3 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          Template Information 
                        </Typography>
                        <Typography variant="caption">
                          Template Information needs to be provided. 
                        </Typography>
                      </div>
                      <div
                        style={{
                          visibility: currentTab === 4 ? 'visible' : 'hidden',
                          height: currentTab === 4 ? 'auto' : 0,
                        }}>
                        <Typography variant="subtitle1">
                          Environment Information 
                        </Typography>
                        <Typography variant="caption">
                          Environment Information regarding a workspace needs to be provided. 
                        </Typography>
                      </div>
                    </div>
                  </Grid>
                  <Grid item xs={12} md={8} xl={9}> 
                    <div
                      style={{
                        visibility: currentTab === 0 ? 'visible' : 'hidden',
                        height: currentTab === 0 ? 'auto' : 0,
                      }}>
                      <GeneralForm { ...methods } />
                    </div>
                    <div
                      style={{
                        visibility: currentTab === 1 ? 'visible' : 'hidden',
                        height: currentTab === 1 ? 'auto' : 0,
                      }}>
                      <HealthCheckForm { ...methods } />
                    </div>
                    <div
                      style={{
                        visibility: currentTab === 2 ? 'visible' : 'hidden',
                        height: currentTab === 2 ? 'auto' : 0,
                      }}>
                      <PodInfoForm { ...methods } />
                    </div>
                    {/*<div
                      style={{
                        visibility: currentTab === 3 ? 'visible' : 'hidden',
                        height: currentTab === 3 ? 'auto' : 0,
                      }}>
                      <TemplateForm { ...methods } />
                    </div>*/}
                  </Grid>
                </Grid>
              </div>
            </form>
          </Grid>
        </Grid>
      <HPaaSFooter />
    </Wrapper>
  )
}

export default CreateService
