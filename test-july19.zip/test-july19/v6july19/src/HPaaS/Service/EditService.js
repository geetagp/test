import React, { useEffect, useState } from 'react'
import { Grid, Typography, Tab, Tabs, Divider, Link, Button, Breadcrumbs, CircularProgress } from '@material-ui/core';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components';

import HPaaSHeader from '../HPaaSHeader';
import HPaaSFooter from '../HPaaSFooter';
import GeneralEditForm from './GeneralEditForm';
import HealthCheckEditForm from './HealthCheckEditForm';
import PodInfoEditForm from './PodInfoEditForm';
import TemplateEditForm from './TemplateEditForm';
import { TopBar, TopBarActions } from '../styledComponents';
import { useParams, useHistory } from 'react-router-dom';
import { generateServiceUpdateObj } from '../common/utils';

const Wrapper = styled.div`
  //padding: 12px;
  display: flex;
  flex-grow: 1;

  .form-info {
    padding: 0 40px 0 0;
  }
`;

function EditService(props) {
  const dispatch = useDispatch();
  const [ currentTab, setCurrentTab ] = useState(0);
  const { serviceId } = useParams();
  const application = useSelector(state => state.application.application);
  const response = useSelector(state => state.application.response);
  const history = useHistory();

  const methods = useForm({
    reValidateMode: 'onBlur',
    mode: 'onBlur',
    validateCriteriaMode: "firstErrorDetected",
    submitFocusError: true,
    nativeValidation: false,
    defaultValues: application,
  });

  const { handleSubmit, reset, formState } = methods;

  useEffect(() => {
    reset();
    dispatch.application.resetModel();
    dispatch.application.getApplication(serviceId);
    dispatch.application.setResponse('');
  }, [dispatch, serviceId]);

  const onSubmit = async data => {
    //await dispatch.application.submitEditApplicationForm({ ...application, ...data });
    const serviceUpdateObj = generateServiceUpdateObj(data, application);
    let serviceSubmitObj = {};
    serviceSubmitObj.serviceName = data.serviceName;
    serviceSubmitObj.patchData = serviceUpdateObj;

    console.log(serviceSubmitObj.patchData);
    //const editeWorkspaceRes = await dispatch.wspace.submitEditWorkspaceForm(workspaceSubmitObj);
  }

  const displayResponse = (response) => {
    switch(response.status) {
      case "success":   return <span style={{ color: 'green', fontSize: 12, fontWeight: 600 }}>{response.message}</span>;
      case "error":   return <span style={{ color: 'red', fontSize: 12, fontWeight: 600}}>{response.message}</span>;
      default: return <span></span>
    }
  }

  const onReset = () => {
    reset();
    dispatch.application.resetModel();
    history.push(`/hpaas/workspace/${application.projectUID}`);
  }

  return (
    <Wrapper>
      <HPaaSHeader user='suser' host='localhost' resetModel='false' />
        <Grid container style={{ flex: 1 }}>
          <Grid item xs={12}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <TopBar>
                <Breadcrumbs separator="›" aria-label="breadcrumb">
                  <Link color="inherit" href="/hpaas/dashboard">
                    Dashboard
                  </Link>
                  <Link color="inherit" onClick={onReset}>
                    List Applications
                  </Link>
                  <Typography color="textPrimary">Update Application</Typography>
                </Breadcrumbs>

                <TopBarActions>
                  <Typography variant="h6">
                    Service Settings
                  </Typography>
                  <Typography variant="subtitle1">
                    {displayResponse(response)}
                  </Typography>
                  <Button variant="contained" color="primary" spacing={2} type="submit" disabled={!formState.isValid}>
                    Save
                  </Button>
                  <Button variant="contained" color="default" onClick={onReset} type="button">
                    Cancel
                  </Button>
                </TopBarActions>
              </TopBar>

              <Divider light align="bottom"/>
              <Tabs
                indicatorColor="primary"
                textColor="primary"
                value={currentTab}
                onChange={(e, newTab) => setCurrentTab(newTab)}>
                <Tab label="General" />
                <Tab label="Health Check" />
                <Tab label="Pod Info" />
                {/*<Tab label="Template Info" disabled />*/}
                <Tab label="Environment Configuration" disabled />
              </Tabs>

              <div style={{padding: '24px 12px 12px', display: 'flex', flexGrow: 1, flex: 1}}>
                <Grid container>
                  <Grid item xs={12} md={4} xl={3}>
                    <div className="form-info">
                      <Typography variant="subtitle1">
                        General Information 
                      </Typography>
                      <Typography variant="caption">
                        General Information regarding a project needs to be provided. 
                      </Typography>
                    </div>
                  </Grid>
                    {
                      !application || !application.serviceName
                        ? (
                          <Grid item xs={12} md={8} xl={9}>
                            <CircularProgress style={{marginRight: 12}} />
                            Loading ...
                          </Grid>
                        ) : (
                          <Grid item xs={12} md={8} xl={9}>
                            <div
                              style={{
                                visibility: currentTab === 0 ? 'visible' : 'hidden',
                                height: currentTab === 0 ? 'auto' : 0,
                              }}>
                              <GeneralEditForm application={application} { ...methods } />
                            </div>
                            <div
                              style={{
                                visibility: currentTab === 1 ? 'visible' : 'hidden',
                                height: currentTab === 1 ? 'auto' : 0,
                              }}>
                              <HealthCheckEditForm application={application} { ...methods } />
                            </div>
                            <div
                              style={{
                                visibility: currentTab === 2 ? 'visible' : 'hidden',
                                height: currentTab === 2 ? 'auto' : 0,
                              }}>
                              <PodInfoEditForm application={application} { ...methods } />
                            </div>
                            {/*<div
                              style={{
                                visibility: currentTab === 3 ? 'visible' : 'hidden',
                                height: currentTab === 3 ? 'auto' : 0,
                              }}>
                              <TemplateEditForm application={application}  { ...methods } />
                            </div>*/}
                          </Grid>
                        )
                    }
                </Grid>
              </div>
            </form>
          </Grid>
        </Grid>
      <HPaaSFooter />
    </Wrapper>
  )
}

export default EditService;