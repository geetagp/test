import { createApplication, fetchApplication, updateApplication, fetchApplicationsByWorkSpace } from './applicationService';
import history from '../App/history';

const initialState = {
  applications: [],
  application: {},
  response: {},
};

const model = {
  state: { ...initialState },

  reducers: {
    storeApplications: (state, applications) => ({
      ...state,
      applications,
    }),
    storeApplication: (state, application) => ({
      ...state,
      application,
    }),
    storeParams: (state, params) => ({
      ...state,
      ...params,
    }),
    resetModel: (state) => ({ ...initialState }),
    setResponse: (state, response) => ({ ...state, response }),
  },

  effects: dispatch => ({
  
    async getApplicationsByWorkspace(workspaceId, state) {

      //test data
      let applicationsResponse = {};
      applicationsResponse.data = require('./localdata/applications-bom.json'); // load dummy data
      applicationsResponse.status = 'success';
      console.log(applicationsResponse);
      //end of test data

      //const applicationsResponse = await fetchApplicationsByWorkSpace(workspaceId, state.app.okta.idToken);
      if (applicationsResponse && applicationsResponse.status === "success") {
        dispatch.applications.storeApplications(applicationsResponse.data);
      } else {
        // handle error here
        console.log('error fetching applications');
      }
    },

    async getApplication(payload, state) {

      //test data
      let applicationsResponse = {};
      applicationsResponse.data = require('./localdata/application-bom.json'); // load dummy data
      applicationsResponse.status = 'success';
      console.log(applicationsResponse);
      //end of test data

      //const applicationRes = await fetchApplication(payload, state.app.okta.idToken);
      
      if ( applicationsResponse &&  applicationsResponse.status === "success") {
        dispatch.application.storeApplication( applicationsResponse.data);
      } else {
        // handle error here
        console.log('error fetching application');
      }
    },

    async submitCreateAppicationForm(payload, state) {
      const applicationResponse = await createApplication(payload, state.app.okta.idToken);
      let applicationRes = {};
        
      //check for success
      if (applicationResponse && applicationResponse.status === "success") {
        applicationRes = {
          "status": applicationResponse.status,
          "message": "Application created successfully.",
        };
        history.push(`/hpaas/workspace/${payload.projectUID}`);
        history.go(`/hpaas/workspace/${payload.projectUID}`);
      }

      //check for error 
      if (applicationResponse && applicationResponse.status === "fail") {
        let errorsObj = applicationResponse.errors ;
        let message = Object.keys(errorsObj)[0]+ ": " + errorsObj[Object.keys(errorsObj)[0]]; 

        applicationRes = {
          "status": applicationResponse.status ,
          "message": message,
        };
      }

      dispatch.application.resetModel();
      dispatch.application.setResponse(applicationRes);

    },

    async submitEditApplicationForm(payload, state) {
      const applicationResponse = await updateApplication(payload, state.app.okta.idToken);
      let applicationRes = {};
    
      if (applicationResponse) {
        dispatch.application.getApplication(payload.serviceUID)
        applicationRes = {
          "status": "success",
          "message": "Application updated successfully.",
        };
        dispatch.application.resetModel();
        dispatch.application.setResponse(applicationRes);
      } else {
        // handle error here
        console.log('error editing application');
      }
    },
  })
}

export default model;
