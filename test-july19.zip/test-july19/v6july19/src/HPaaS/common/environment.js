export const getApiHost = () => {
  let host = window.location.host;
  //e1 and e2
  let apiHost = 'v5apieng1-dev.aexp.com';
  if (host.includes('qa1-dev')) {
    apiHost = 'v5apiqa1-dev.aexp.com';
  } else{
  if (host.includes('prod-dev')) { 
    apiHost = 'v5apiprod-dev.aexp.com';
  } else {
    if (host.includes('prod-qa')) { 
      apiHost = 'v5apiprod-qa.aexp.com';
    }
  }
  }
  //e3
  if (host.includes('eng1.aexp')) {
  apiHost = 'v5apieng1.aexp.com';
  } else{
  if (host.includes('qa1.aexp')) { 
    apiHost = 'v5apiqa1.aexp.com';
  } else{
    if (host.includes('prod.aexp')) { 
      apiHost = 'v5apiprod.aexp.com';
    }
  }
  }
  return apiHost;
}

export const getConfigObj = () => {
  let configObj = { "clientId": "", "issuer": "" }
  let host = window.location.host;
  configObj.clientId = "0oaoe1i2biw6HptVw0x7";
  configObj.issuer = "https://aexp.okta.com/";
  if (host.includes('portalqa')) {
    configObj.clientId = "0oaoe1id1t5vIwPwR0x7";
  } else if (host.includes('portalprod')) { 
    configObj.clientId = "0oaoe1g4juSFNp5LE0x7";
  }
  return configObj;
}
