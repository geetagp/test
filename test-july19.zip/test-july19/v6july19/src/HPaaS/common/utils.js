import { withStyles} from '@material-ui/core/styles';
import {Tooltip} from '@material-ui/core';

export const HtmlTooltip = withStyles(theme => ({
  tooltip: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}))(Tooltip);

const hasValue = value => !(!value || value.length < 1);

export const getUserAdsId = (name) => {
  if (hasValue(name)) {
     return name.substring(0, name.indexOf('@'));
  }
}

export const generateWorkspaceCreateObj = (workspaceformData) => {
  const { workspaceName, description, businessJustification, carId, creatorADS, members, owners, serviceNowWorkGroupName } = workspaceformData;

  const workspaceObj = {
      "workspaceName":  "",
      "metadata": {
        "description": "",
        "businessJustification": "",
        "carId": "",
        "directorEmail": "test@aexp.com",
        "directorName": "test",
        "creatorADS": "",
        "supportEmail": "support@aexp.com",
      },
      "members": [],
      "owners": [],
      "ownersGroup": "test",
      "loggingGroup": "test",
      "monitoringGroup": "test",
      "serviceNowWorkGroup": "test",
      "serviceCountLimit": 5
    }
    
  if (hasValue(workspaceName)) workspaceObj.workspaceName = workspaceName;
  if (hasValue(description)) workspaceObj.metadata.description = description;
  if (hasValue(businessJustification)) workspaceObj.metadata.businessJustification = businessJustification;
  if (hasValue(carId)) workspaceObj.metadata.carId = carId;
  if (hasValue(creatorADS)) workspaceObj.metadata.creatorADS = creatorADS;
  if (hasValue(carId)) workspaceObj.serviceNowWorkGroupName = serviceNowWorkGroupName;
  if (hasValue(members)) workspaceObj.members = members.split(',');
  if (hasValue(owners)) workspaceObj.owners = owners;

  return workspaceObj;
};

export const generateWorkspaceUpdateObj = (workspaceformData, workspaceGetData) => {
  const { description, businessJustification, carId, members, serviceNowWorkGroupName } = workspaceformData;

  let workspacePatchObj = [] ;
  let workspaceObj = { "op": "", "path": "", "value": "" }
  const membersGetString = new Array(workspaceGetData.members).join(',');

  if (hasValue(description) && description !== workspaceGetData.metadata.description)  {
    workspaceObj = { "op": "replace", "path": "/metadata/description", "value": description }
    workspacePatchObj.push(workspaceObj);
  }
  if (hasValue(businessJustification) && businessJustification !== workspaceGetData.metadata.businessJustification)  {
    workspaceObj = { "op": "replace", "path": "/metadata/businessJustification", "value": businessJustification }
    workspacePatchObj.push(workspaceObj);
  }
  if (hasValue(carId) && carId != workspaceGetData.metadata.carId)  {
    workspaceObj = { "op": "replace", "path": "/metadata/carId", "value": carId }
    workspacePatchObj.push(workspaceObj);
  }
  if (hasValue(serviceNowWorkGroupName) && serviceNowWorkGroupName !== workspaceGetData.metadata.serviceNowWorkGroup)  {
    workspaceObj = { "op": "replace", "path": "/serviceNowWorkGroup", "value": serviceNowWorkGroupName }
    workspacePatchObj.push(workspaceObj);
  }
  if (hasValue(members) && members !== membersGetString)  { 
    workspaceObj = { "op": "replace", "path": "/members", "value":  members.split(',') }
    workspacePatchObj.push(workspaceObj);
  }

  return workspacePatchObj ;
};


export const generateServiceCreateObj = (serviceformData) => { 
  const { serviceName, description, template, deploymentMethod, applicationUrlPrefix, healthCheckUri, gdha, gtm, routable, sso, monitoring, logging, maxEnv, imageRepo, nfsMountPath, region, pii, cdUrl, podSize, status } = serviceformData;

  const serviceObj = {
    "serviceName": "",
     "metadata": {
       "description": "",
       "template": "",
       "deploymentMethod": "",
       "applicationUrlPrefix": "",
       "healthCheckUri": "/",
       "monitoring": "",
       "logging": "",
       "maxEnv": "e3",
       "imageRepo": "",
       "nfsMountPath": "",
       "region": "",
       "pii": false,
       "gdha": true,
       "gtm": "",
       "routable": false,
       "sso": "",
       "cdUrl": "",
       "podSize": "",
       "status": "pending"
     },
     "features": [
       {
         "name": "vault",
         "enabled": true
       },
       {
         "name": "multiContainer",
         "enabled": true
       },
       {
         "name": "livenessprobe",
         "enabled": true
       }
     ]
    }
    
  if (hasValue(serviceName)) serviceObj.serviceName = serviceName;
  if (hasValue(description)) serviceObj.metadata.description = description;
  if (hasValue(template)) serviceObj.metadata.template = template;
  if (hasValue(deploymentMethod)) serviceObj.metadata.deploymentMethod = deploymentMethod;
  if (hasValue(applicationUrlPrefix)) serviceObj.metadata.applicationUrlPrefix = applicationUrlPrefix;
  if (hasValue(healthCheckUri)) serviceObj.metadata.healthCheckUri = healthCheckUri;
  if (hasValue(monitoring)) serviceObj.metadata.monitoring = monitoring;
  if (hasValue(logging)) serviceObj.metadata.logging = logging;
  if (hasValue(maxEnv)) serviceObj.metadata.maxEnv = maxEnv;
  if (hasValue(imageRepo)) serviceObj.metadata.imageRepo = imageRepo;
  if (hasValue(nfsMountPath)) serviceObj.metadata.nfsMountPath = nfsMountPath;
  if (hasValue(region)) serviceObj.metadata.region = region;
  if (hasValue(gtm)) serviceObj.metadata.gtm = gtm;
  if (hasValue(sso)) serviceObj.metadata.sso = sso;
  if (hasValue(cdUrl)) serviceObj.metadata.cdUrl = cdUrl;
  if (hasValue(podSize)) serviceObj.metadata.podSize = podSize;
  if (hasValue(status)) serviceObj.metadata.status = status;
  serviceObj.metadata.pii = pii;
  serviceObj.metadata.gdha = gdha;
  serviceObj.metadata.routable = routable;

  return serviceObj;
};

export const generateServiceUpdateObj = (serviceformData, serviceGetData) => {
  const { serviceName, description, template, deploymentMethod, applicationUrlPrefix, healthCheckUri, gdha, gtm, routable, sso, monitoring, logging, maxEnv, imageRepo, nfsMountPath, region, pii, cdUrl, podSize, status  } = serviceformData;

  let servicePatchObj = [] ;
  let serviceObj = { "op": "", "path": "", "value": "" }

  if (hasValue(serviceName) && serviceName !== serviceGetData.serviceName)  {
    serviceObj = { "op": "replace", "path": "/serviceName", "value": serviceName }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(description) && description !== serviceGetData.metadata.description)  {
    serviceObj = { "op": "replace", "path": "/metadata/description", "value": description }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(template) && template !== serviceGetData.metadata.template)  {
    serviceObj = { "op": "replace", "path": "/metadata/template", "value": template }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(deploymentMethod) && deploymentMethod !== serviceGetData.metadata.deploymentMethod)  {
    serviceObj = { "op": "replace", "path": "/metadata/deploymentMethod", "value": deploymentMethod }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(applicationUrlPrefix) && applicationUrlPrefix !== serviceGetData.metadata.applicationUrlPrefix)  {
    serviceObj = { "op": "replace", "path": "/metadata/applicationUrlPrefix", "value": applicationUrlPrefix }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(healthCheckUri) && healthCheckUri !== serviceGetData.metadata.healthCheckUri)  {
    serviceObj = { "op": "replace", "path": "/metadata/healthCheckUri", "value": healthCheckUri }
    servicePatchObj.push(serviceObj);
  }
  if (gdha !== serviceGetData.metadata.gdha)  {
    serviceObj = { "op": "replace", "path": "/metadata/gdha", "value": gdha }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(gtm) && gtm !== serviceGetData.metadata.gtm)  {
    serviceObj = { "op": "replace", "path": "/metadata/gtm", "value": gtm }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(routable) && routable !== serviceGetData.metadata.routable)  {
    serviceObj = { "op": "replace", "path": "/metadata/routable", "value": routable }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(sso) && sso !== serviceGetData.metadata.sso)  {
    serviceObj = { "op": "replace", "path": "/metadata/sso", "value": sso }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(monitoring) && monitoring !== serviceGetData.metadata.monitoring)  {
    serviceObj = { "op": "replace", "path": "/metadata/monitoring", "value": monitoring }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(logging) && logging !== serviceGetData.metadata.logging)  {
    serviceObj = { "op": "replace", "path": "/metadata/logging", "value": logging }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(maxEnv) && maxEnv !== serviceGetData.metadata.maxEnv)  {
    serviceObj = { "op": "replace", "path": "/metadata/maxEnv", "value": maxEnv }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(imageRepo) && imageRepo !== serviceGetData.metadata.imageRepo)  {
    serviceObj = { "op": "replace", "path": "/metadata/imageRepo", "value": imageRepo }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(nfsMountPath) && nfsMountPath !== serviceGetData.metadata.nfsMountPath)  {
    serviceObj = { "op": "replace", "path": "/metadata/nfsMountPath", "value": nfsMountPath }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(pii) && pii !== serviceGetData.metadata.pii)  {
    serviceObj = { "op": "replace", "path": "/metadata/pii", "value": pii }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(region) && region !== serviceGetData.metadata.region)  {
    serviceObj = { "op": "replace", "path": "/metadata/region", "value": region }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(cdUrl) && cdUrl !== serviceGetData.metadata.cdUrl)  {
    serviceObj = { "op": "replace", "path": "/metadata/cdUrl", "value": cdUrl }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(podSize) && podSize !== serviceGetData.metadata.podSize)  {
    serviceObj = { "op": "replace", "path": "/metadata/podSize", "value": podSize }
    servicePatchObj.push(serviceObj);
  }
  if (hasValue(status) && status !== serviceGetData.metadata.status)  {
    serviceObj = { "op": "replace", "path": "/metadata/status", "value": status }
    servicePatchObj.push(serviceObj);
  }

  return servicePatchObj ;
};