import React from 'react';
import {makeStyles} from '@material-ui/styles';
import {Radio} from '@material-ui/core';
import clsx from 'clsx';

const useStyles = makeStyles({
    root: {
      '&:hover': {
        backgroundColor: 'transparent',
      },
    },
    icon: {
      borderRadius: '50%',
      width: 16,
      height: 16,
      boxShadow: 'inset 0 0 1px 1px rgba(0,0,0,1), inset 0 70px 0 rgba(0,0,0,0)',
      backgroundColor: '#fff',
      '$root.Mui-focusVisible &': {
        outline: '2px auto rgba(0,0,0,0)',
        outlineOffset: 2,
      },
      'input:disabled ~ &': {
        boxShadow: 'inset 0 0 1px 1px rgba(0, 0, 0, 0.38)',
      },
    },
    checkedIcon: {
      backgroundColor: '#fff',
      '&:before': {
        display: 'block',
        width: 16,
        height: 16,
        backgroundImage: 'radial-gradient(#000000 35%,transparent 12%)',
        content: '""',
      },
    },
  });
  
  function StyledRadio(props) {
    const classes = useStyles();
  
    return (
      <Radio
        className={classes.root}
        disableRipple
        color="default"
        checkedIcon={<span className={clsx(classes.icon, classes.checkedIcon)} />}
        icon={<span className={classes.icon} />}
        {...props}
      />
    );
  }

export default StyledRadio;

//TBD-Use as: <FormControlLabel value="active_passive" control={<StyledRadio  />} label="Active-Passive" />