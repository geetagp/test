import React from 'react';
import { Provider } from 'react-redux';
import { ThemeProvider } from '@material-ui/core/styles';
import { getPersistor } from '@rematch/persist'
import { PersistGate } from 'redux-persist/lib/integration/react'

import store from './store';
import './App.css';
import Header from './Header';
import muiTheme from './muiTheme';
import Routes, {
  CERTIFICATE_MANAGER_URL, CERTIFICATE_STATUS_URL, HPAAS_MANAGER_URL, HPAAS_EDIT_WORKSPACE_URL,
  HPAAS_CREATE_WORKSPACE_URL, HPAAS_WORKSPACE_OVERVIEW_URL, HPAAS_CREATE_SERVICE_URL 
} from './Routes';

const persistor = getPersistor();

const routesToHideHeader = [
  CERTIFICATE_MANAGER_URL,
  CERTIFICATE_STATUS_URL,
  HPAAS_MANAGER_URL,
  HPAAS_EDIT_WORKSPACE_URL,
  HPAAS_CREATE_WORKSPACE_URL,
  HPAAS_WORKSPACE_OVERVIEW_URL,
  HPAAS_CREATE_SERVICE_URL,
];

const shouldShowHeader = routesToHideHeader.includes(window.location.pathname) !== true;

function App() {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
        <ThemeProvider theme={muiTheme}>
          {
            // hide <Header /> component if included in the Array routesToHideHeader
            // shouldShowHeader && <Header title="Cloud Portal" />
          }
          <Routes />
        </ThemeProvider>
      </PersistGate>
    </Provider>
  );
}

export default App;
