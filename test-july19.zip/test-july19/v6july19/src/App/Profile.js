import React from 'react';
import { useOktaAuth } from '@okta/okta-react';
import { useSelector } from 'react-redux';
import HPaaSHeader from '../HPaaS/HPaaSHeader';


const Profile = () => {
  const { authState, authService } = useOktaAuth();
  const okta = useSelector(state => state.app.okta);

  return (
    <div>
      <HPaaSHeader />
      <div style={{
          padding: '0 24px',
        }}>
          {
            !okta ? (
              <div>
                <p>Fetching user profile...</p>
              </div>
            ) : (
              <div>
                <h1>
                  My User Profile (ID Token Claims)
                </h1>
                <p>
                  This route is protected with the 
                  {' '}
                  <code>&lt;SecureRoute&gt;</code>
                  {' '}
                  component, which will ensure that this page cannot be accessed until you have authenticated.
                </p>
                <table style={{ tableLayout: 'fixed', width: '100%' }}>
                  <thead>
                    <tr style={{ textAlign: 'left' }}>
                      <th width="200px" style={{ paddingBottom: 20 }}>Claim</th>
                      <th style={{ paddingBottom: 20 }}>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(okta).filter(entry => !entry[0].includes('Token')).map((claimEntry) => {
                      const claimName = claimEntry[0];
                      const claimValue = claimEntry[1];
                      const claimId = `claim-${claimName}`;
                      return (
                        <tr key={claimName}>
                          <td>{claimName}</td>
                          <td id={claimId}>{claimValue}</td>
                        </tr>
                      );
                    })}
                    <tr>
                      <td>Access Token</td>
                      <td style={{wordWrap: 'break-word', padding: '50px 0' }}>{authState.accessToken}</td>
                    </tr>
                    <tr>
                      <td>ID Token</td>
                      <td style={{wordWrap: 'break-word'}}>{authState.idToken}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )
          }
      </div>
    </div>
  );
};

export default Profile;
