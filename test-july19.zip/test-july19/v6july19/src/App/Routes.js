import React, { useEffect } from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from 'react-router-dom';
import { Security, SecureRoute, LoginCallback } from '@okta/okta-react';

import oktaConfig from './oktaConfig';
import history from './history';
import CertManager from '../CertManager/CertManager';
import CertStatus from '../CertManager/CertStatus';
import HPaaSManager from '../HPaaS/HPaaSManager';
import HPaaSCreateWorkspace from '../HPaaS/Workspace/CreateWorkspace';
import HPaaSEditWorkSpace from '../HPaaS/Workspace/EditWorkspace';
import HPaaSWorkspaceOverview from '../HPaaS/WorkspaceOverview';
import HPaaSCreateService from '../HPaaS/Service/CreateService';
import HPaaSEditService from '../HPaaS/Service/EditService';

import Profile from './Profile';

export const CERTIFICATE_MANAGER_URL = '/certificate-manager';
export const CERTIFICATE_STATUS_URL = '/certificate-status';
export const HPAAS_MANAGER_URL = '/hpaas/dashboard';
export const HPAAS_EDIT_WORKSPACE_URL = '/hpaas/workspace/:workspaceId/edit';
export const HPAAS_CREATE_WORKSPACE_URL = '/hpaas/workspace/create';
export const HPAAS_WORKSPACE_OVERVIEW_URL = '/hpaas/workspace/:workspaceId';
export const HPAAS_CREATE_SERVICE_URL = '/hpaas/workspace/:workspaceId/service/create';
export const HPAAS_EDIT_SERVICE_URL = '/hpaas/workspace/service/:serviceId/edit';


export const HOME_URL = '/';

// Our route config is just an array of logical 'routes'
// with `path` and `component` props, ordered the same
// way you'd do inside a `<Switch>`.
const routesConfig = [
  {
    path: CERTIFICATE_MANAGER_URL,
    component: CertManager,
  },
  {
    path: CERTIFICATE_STATUS_URL,
    component: CertStatus,
  },
  {
    path: HPAAS_MANAGER_URL,
    component: HPaaSManager,
  },
  {
    path: HPAAS_EDIT_WORKSPACE_URL,
    component: HPaaSEditWorkSpace,
  },
  {
    path: HPAAS_CREATE_WORKSPACE_URL,
    component: HPaaSCreateWorkspace,
  },
  {
    path: HPAAS_CREATE_SERVICE_URL,
    component: HPaaSCreateService,
  },
  {
    path: HPAAS_EDIT_SERVICE_URL,
    component: HPaaSEditService,
  },
  {
    path: HPAAS_WORKSPACE_OVERVIEW_URL,
    component: HPaaSWorkspaceOverview,
  },
];

const Routes = () => {
  return (
    <Router history={history}>
      <Security {...oktaConfig.oidc}>
        <Switch>
          <Route path="/implicit/callback" component={LoginCallback} />
          {
            routesConfig.map((route, i) => (
              <SecureRoute key={i} {...route} />
            ))
          }
          <SecureRoute path="/profile" component={Profile} />
          <SecureRoute path="/" exact component={HPaaSManager} />
        </Switch>
      </Security>
    </Router>
    
  );
}

export default Routes;
