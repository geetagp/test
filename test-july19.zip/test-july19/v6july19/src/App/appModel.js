export default {
  state: {
    showSidebar: false,
    okta: null,
  },

  reducers: {
    setShowSidebar: state => ({
      ...state,
      showSidebar: !state.showSidebar,
    }),
    setOkta: (state, okta) => ({
      ...state,
      okta,
    }),
  },

  effects: dispatch => ({})
}