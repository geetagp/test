import React, { useEffect } from 'react';
import styled from 'styled-components';
import CertRenewalHeader from './CertManagerHeader';
import CertStatusGrid from './CertStatusGrid';
import CertRenewalFooter from './CertManagerFooter';
import { connect } from 'react-redux';

const Wrapper = styled.div``;

const CertRenewal = ({
  certificates,
  getCertificates,
  user,
}) => {
  useEffect(() => {
    getCertificates()
  }, [getCertificates])

  return (
    <Wrapper>
      <CertRenewalHeader user={user} />
      <CertStatusGrid certificates={certificates} />
      <CertRenewalFooter />
    </Wrapper>
  )
}

const mapProps = state => ({
  certificates: state.certs.certificates,
  user: state.certs.user,
})

const mapDispatch = dispatch => ({
  getCertificates: dispatch.certs.getCertificates,
})

export default connect(mapProps, mapDispatch)(CertRenewal)
