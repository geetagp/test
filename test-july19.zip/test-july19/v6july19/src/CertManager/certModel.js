import { fetchCerts, updateCerts } from './certService';

const initialState = {
  certificates: [],
  renewalDate: null,
  user: '',
  token: '',
  host: '',
  hasAuth: false,
  checkedAuth: false,
};

const model = {
  state: { ...initialState },

  reducers: {
    storeCertificates: (state, certificates) => ({
      ...state,
      certificates,
      hasAuth: true,
    }),
    setRenewalDate: (state, renewalDate) => ({ ...state, renewalDate }),
    storeParams: (state, params) => ({
      ...state,
      ...params,
    }),
    resetModel: (state) => ({...initialState}),
    setCheckedAuth: (state, checkedAuth) => ({ ...state, checkedAuth }),
  },

  effects: dispatch => ({
    async getCertificates(payload, state) {
      const { token, host } = state.certs;
      let certs = [];

      if (token && host) {
        const certsResponse = await fetchCerts({token, host});
        certs = !certsResponse ? [] : certsResponse; 

        if (certsResponse && certsResponse[0].code === 401) {
          dispatch.certs.resetModel();
          dispatch.certs.setCheckedAuth(true);
        } else {
          // certs = require('../data/certsData.json').data; // uncomment to load dummy data
          dispatch.certs.storeCertificates(certs);
          dispatch.certs.setCheckedAuth(true);
        }

      }
      
    },

    async updateCertificates({selectedCerts, certificates}, state) {
      const { token, host } = state.certs;
      const certs = certificates
        .filter((cert, i) => selectedCerts.includes(i))
        .map(cert => ({...cert, renewalActivated: true}));

      await updateCerts({token, host, certs});

      dispatch.certs.getCertificates();
      
    }
  })
}

export default model;
