import React, { useEffect, Fragment } from 'react';
import styled from 'styled-components';
import { Dialog, DialogTitle, DialogContent, DialogContentText } from '@material-ui/core';
import CertRenewalHeader from './CertManagerHeader';
import ProcessInfo from './ProcessInfo';
import ApplicationGrid from './ApplicationGrid';
import CertRenewalFooter from './CertManagerFooter';
import { connect } from 'react-redux';
// import { CERTIFICATE_MANAGER_URL } from '../App/Routes';

const Wrapper = styled.div``;

const CertRenewal = ({
  certificates,
  getCertificates,
  selectedCerts,
  location,
  storeParams,
  user,
  updateCertificates,
  resetModel,
  hasAuth,
  checkedAuth,
  host,
}) => {
  useEffect(() => {
    const {search} = location;
    if (search.length > 0) {
      const paramsObj = JSON.parse('{"' + decodeURI(search.substring(1)).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g,'":"') + '"}');
      storeParams(paramsObj);
      // window.history.replaceState({}, document.title, CERTIFICATE_MANAGER_URL);
    }
    getCertificates();
  }, [getCertificates, location, storeParams])

  return (
    <Fragment>
      <Wrapper>
        <CertRenewalHeader user={!user ? null : user} host={!host ? null : host} resetModel={resetModel} />
        <ProcessInfo />
        <ApplicationGrid
          certificates={hasAuth && certificates.length && certificates[0].hasOwnProperty('serviceName') ? certificates : []}
          selectedCerts={selectedCerts}
          updateCertificates={updateCertificates}
        />
        <CertRenewalFooter />
      </Wrapper>
      
      <Dialog open={!hasAuth && checkedAuth}>
        <DialogTitle>You don't have Authorization</DialogTitle>
        <DialogContent>
          <DialogContentText>Your session may have expired, or you're trying to navigate to this page without access rights.</DialogContentText>
          <DialogContentText>Please login to the eCP Console, and access the Certificate Renewal Manager again.</DialogContentText>
        </DialogContent>
      </Dialog>
    </Fragment>
  )
}

const mapProps = state => ({
  certificates: state.certs.certificates,
  renewalDate: state.certs.renewalDate,
  selectedCerts: state.certs.selected,
  user: state.certs.user,
  hasAuth: state.certs.hasAuth,
  checkedAuth: state.certs.checkedAuth,
  host: state.certs.host,
})

const mapDispatch = dispatch => ({
  getCertificates: dispatch.certs.getCertificates,
  setRenewalDate: dispatch.certs.setRenewalDate,
  storeParams: dispatch.certs.storeParams,
  updateCertificates: dispatch.certs.updateCertificates,
  resetModel: dispatch.certs.resetModel,
})

export default connect(mapProps, mapDispatch)(CertRenewal)
