import React, { Fragment } from 'react';
import {
  Button, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions
} from '@material-ui/core';

export default function ScheduleRenewalButton (props) {
  const {selectedCerts, certificates, updateCertificates, storeSelectedCerts} = props;
  const [openConfirmModal, setOpenConfirmModal] = React.useState(false);
  const hasCertsSelected = selectedCerts && selectedCerts.length;

  const handleClose = () => {
    setOpenConfirmModal(false);
    storeSelectedCerts([]);
  }

  const handleInstall = () => {
    updateCertificates({selectedCerts, certificates});
    setOpenConfirmModal(true);
  }

  return (
    <Fragment>
      <Button
        variant="contained"
        color="primary"
        size="large"
        disabled={!hasCertsSelected}
        onClick={handleInstall}
      >Confirm Install</Button>

      <Dialog open={openConfirmModal} onClose={() => setOpenConfirmModal(false)}>
        <DialogTitle>Certificate Installation Request Submitted</DialogTitle>
        <DialogContent>
          <DialogContentText>Selected certificate(s) will take effect with your next deployment.</DialogContentText>
          <ol>
            {
              selectedCerts.map(dataIndex => (
                <li key={dataIndex}>
                  {
                    certificates[dataIndex] && `${certificates[dataIndex].env.toUpperCase()}: ${certificates[dataIndex].serviceName}`
                  }
                </li>
              ))
            }
          </ol>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Okay
          </Button>
        </DialogActions>
      </Dialog>
    </Fragment>
  )
}
