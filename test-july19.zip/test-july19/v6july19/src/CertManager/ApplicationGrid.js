import React, { Component } from 'react';
import { FiRefreshCw } from 'react-icons/fi';
import TimeAgo from 'react-timeago';
import { Button } from '@material-ui/core';
import MUIDataTable from 'mui-datatables';
import styled from 'styled-components';
import ScheduleRenewalButton from './ScheduleRenewalButton';
import { getEnvNumberFromString } from '../common/utils';

const Wrapper = styled.div`
  padding: 24px;
  flex: 1;
  display: flex;
  flex-direction: column;

  .header {
    display: flex;
    align-items: center;
    margin-bottom: 18px;
  }

  tr {
    > th:first-child, > td:first-child {
      padding-left: 16px;
      padding-right: 8px;
    }
  }
`;

const DEPLOY = 'deploy';
const DEFAULT = 'default';
const E2_PROMOTE = 'e2_promote';
const DUE_FOR_INSTALL = 'due_for_install';
const INSTALL_PENDING = 'install_pending';
const INSTALL_FAILED = 'install_failed';
const INSTALLED = 'installed';
const EXPIRED = 'expired';
const RENEW_FAILED = 'renew_failed';
const RENEW_PENDING = 'renew_pending';
// const APPLICATION_ENVS = ['E1', 'E2', 'E3'];

const getTableColumns = (filterList, columnSort) => ([
  {
    name: 'serviceName',
    label: 'Application',
    options: {
      filterList: filterList[0],
      sortDirection: !columnSort.serviceName ? 'none' : columnSort.serviceName,
    },
  },
  {
    name: 'projectName',
    label: 'Project',
    options: {
      filterList: filterList[1],
      sortDirection: !columnSort.projectName ? 'none' : columnSort.projectName,
    },
  },
  { name: 'env', 
    label: 'Certificate environment',
    options: {
      customBodyRender: env => env.toUpperCase(),
      filterList: filterList[2],
      sortDirection: !columnSort.env ? 'none' : columnSort.env,
    },
  },
  { name: 'renewStatus', 
    label: 'Status',
    options: {
      filterList: filterList[3],
      sortDirection: !columnSort.renewStatus ? 'none' : columnSort.renewStatus,
      customBodyRender: renewStatus => ({
        [DUE_FOR_INSTALL]: (
          <div>
            due for install
          </div>
        ),
        [INSTALL_PENDING]: (
          <div>
            install pending
          </div>
        ),
        [INSTALL_FAILED]: (
          <div>
            install failed
          </div>
        ),
        [INSTALLED]: (
          <div>
            installed
          </div>
        ),
        [EXPIRED]: (
          <div>
            expired
          </div>
        ),
        [RENEW_FAILED]: (
          <div>
            renew failed
          </div>
        ),
      })[renewStatus],
    }
  },
  {
    name: 'expiryDate',
    label: 'Expires in',
    options: {
      customBodyRender: expirationDate => <TimeAgo date={expirationDate} />,
      filterList: filterList[4],
      sortDirection: !columnSort.expiryDate ? 'none' : columnSort.expiryDate,
    },
  },
  {
    name: 'certRenewUserAction',
    label: 'Action required',
    options: {
      filterList: filterList[5],
      sortDirection: !columnSort.certRenewUserAction ? 'none' : columnSort.certRenewUserAction,
      customBodyRender: certRenewUserAction => ({
        [DEPLOY]: (
          <span style={{
            display: 'flex',
            alignItems: 'center',
          }}>
            <FiRefreshCw style={{
              marginRight: 6,
            }}
            />
            deploy app to install cert
          </span>
        ),
        [DEFAULT]: (
          <div>
            confirm install
          </div>
        ),
        [E2_PROMOTE]: (<span>Promote to E2</span>)
      })[certRenewUserAction],
    }
  },
]);

const getCertsToDisplay = allCerts => {
  let certsToDisplay = [];
  const dontShowTheseStatuses = [INSTALLED, RENEW_FAILED, RENEW_PENDING];
  // use regex to filter out unwanted data from table
  certsToDisplay = allCerts.filter(cert => !new RegExp(dontShowTheseStatuses.join('|')).test(cert.renewStatus));
  return certsToDisplay;
}

export default class ApplicationGrid extends Component {
  state = {
    applicationEnv: 'Show all',
    page: 0,
    filterList: [],
    selectedCerts: [],
    columnSort: {},
    rowsPerPage: 10,
  }

  componentWillUnmount() {
    this.setState({ applicationEnv: 'Show all', page: 0, filterList: [], columnSort: {}, rowsPerPage: 10 });
  }

  onSelectCert = (currentRowsSelected, allRowsSelected) => {
    const { certificates } = this.props;
    let selectedCertsIndexes = allRowsSelected.map(row => row.dataIndex);
    let lesserEnvCertsIndexes = [];
    const certsToDisplay = getCertsToDisplay(certificates);

    selectedCertsIndexes.forEach(dataIndex => {
      const cert = certsToDisplay[dataIndex];
      const {env, serviceName, projectName} = cert;
      const selectedCertEnvNumber = getEnvNumberFromString(env);

      certsToDisplay.forEach((item, i) => {
        const itemEnvNumber = getEnvNumberFromString(item.env);
        if (item.serviceName === serviceName && itemEnvNumber < selectedCertEnvNumber) {
          lesserEnvCertsIndexes.push(i);
        }
      })
    });

    const allIndexesNoDupes = [...new Set([...selectedCertsIndexes, ...lesserEnvCertsIndexes])];
    this.setState({ selectedCerts: allIndexesNoDupes });
  }

  onColumnSortChange = (changedColumn, direction) => {
    let directionAbbreviation;
    switch (direction) {
      case 'descending':
        directionAbbreviation = 'desc';
        break;
      case 'ascending':
        directionAbbreviation = 'asc';
        break;
      default:
        directionAbbreviation = 'none';
        break;
    }
    this.setState({ columnSort: { [changedColumn]: directionAbbreviation } });
  }

  render() {
    const { applicationEnv, page, filterList, selectedCerts, columnSort, rowsPerPage } = this.state;
    const { certificates, updateCertificates } = this.props;
    const applicationData = getCertsToDisplay(certificates);
      
    return (
      <Wrapper>
        <div className="header">
          {`My Applications (${selectedCerts.length > 0 ? selectedCerts.length + ' of ' + applicationData.length + ' selected' : applicationData.length})`}
          <Button
            color="primary"
            href="/certificate-status"
            style={{marginLeft: 60}}>
              Completed / scheduled installations
          </Button>
          {/* commenting this filter, since material ui table has filter option*/}
          
          {/* <Select
            labelId="select-env-label"
            id="select-env"
            value={applicationEnv}
            onChange={e => this.setState({applicationEnv: e.target.value})}
            style={{marginLeft: 40}}
          >
            <MenuItem key={'all'} value={'Show all'}>Show all</MenuItem>
            {
              APPLICATION_ENVS.map((item, i) => (
                <MenuItem key={i} value={item}>
                  Filter by {item}
                </MenuItem>
              ))
            }
          </Select> */}
         
        </div>
        {/* Jamal comments : Disable Row : not needed for now : isRowSelectable: index => !applicationData[index].renewalActivated,*/}
        <div style={{ width: '100%' }}>
          <MUIDataTable
            key={selectedCerts.toString()}
            columns={getTableColumns(filterList, columnSort)}
            data={applicationData}
            options={{
              selection: true,
              search: false,
              disableToolbarSelect: true,
              rowsSelected: selectedCerts,
              onRowsSelect: this.onSelectCert,
              selectableRowsOnClick: true,
              selectableRowsHeader: true,
              filter: true,
              print: false,
              download: false,
              viewColumns: false,
              page,
              rowsPerPage,
              rowsPerPageOptions: [10, 25, 50, 100],
              onChangePage: page => this.setState({ page }),
              onFilterChange: (changedColumn, filterList, type) => this.setState({ filterList }),
              onColumnSortChange: this.onColumnSortChange,
              onChangeRowsPerPage: rowsPerPage => this.setState({rowsPerPage})
            }}
          />
        </div>
        <div style={{
          display: 'flex',
          justifyContent: 'flex-end',
          margin: '32px 0',
        }}>
          <ScheduleRenewalButton
            selectedCerts={selectedCerts}
            certificates={applicationData}
            updateCertificates={updateCertificates}
            storeSelectedCerts={selectedCerts => this.setState({ selectedCerts })}
          />
        </div>
      </Wrapper>
    )
  }
}
