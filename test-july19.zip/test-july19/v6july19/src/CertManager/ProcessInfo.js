import React, { PureComponent, Fragment } from 'react';
import styled from 'styled-components';
import { FiChevronRight } from 'react-icons/fi';
import { Step1Icon, Step2Icon, Step3Icon } from './Icons';

const Wrapper = styled.div`
  background: #ecedee;
  padding: 24px;

  h2 {
    text-align: center;
    padding-top: 0;
    margin: 0 0 32px 0;
  }
`;

const Steps = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  // text-align: center;
  justify-content: center;
  align-content: center;

  .next-icon {
    align-self: center;
  }
`;

const Step = styled.div`
  display: flex;
  flex-direction: column;
  padding: 0 40px;
  max-width: calc(20% - 80px);

  &.last-step {}

  .step-title {
    text-align: center;
    margin-bottom: 24px;
    font-size: 22px;
  }

  .step-description {
    text-align: center;
  }

  b {
    display: block;
    margin-bottom: 6px;
  }

  p {
    font-size: 14px;
    margin: 0 0 12px 0;
    color: #555;
  }

  .icon {
    display: flex;
    align-self: center;
    margin-bottom: 24px;
  }
`;

const stepsData = [
  {
    title: 'Step 1',
    icon: <Step1Icon width={40} />,
    description: (
      <div className="step-description">
        <b>Select</b>
        <p>Select the certificates that are due for renewal and click Confirm Install. Renewed certificate versions have been generated and are ready to be installed. If only selecting E3 environment, corresponding certificates in E1 and E2 will be auto-selected to ensure renewed certificates work successfully in lower environments.</p>
      </div>
    )
  },
  {
    title: 'Step 2',
    icon: <Step2Icon width={55} style={{marginRight: 10}} />,
    description: (
      <div className="step-description">
        <b>Redeploy</b>
        <p>Redeploy your application so that renewed certificates are installed in E1. You need to test that renewed certificates work in E1 before promoting to E2.</p>
      </div>
    )
  },
  {
    title: 'Step 3',
    icon: <Step3Icon width={55} style={{marginLeft: 10}} />,
    description: (
      <div className="step-description">
        <b>Promote</b>
        <p>Promote your application to E2 to install certificates in that environment . Test that renewed certificates work in E2 before promoting to E3. If successful, promote to E3 to install renewed certificates in E3.</p>
      </div>
    )
  }
];

export default class ProcessInfo extends PureComponent {
  render() {
    return (
      <Wrapper>
        <h2>Certificate Installation Process</h2>
        <Steps>
          {
            stepsData.map((step, i) => {
              const isLast = i === stepsData.length - 1;
              return (
                <Fragment key={i}>
                  <Step className={isLast ? 'last-step' : null}>
                    <div className="step-title">{step.title}</div>
                    <div className="icon">{step.icon}</div>
                    {step.description}
                  </Step>
                  {
                    isLast ? null : <FiChevronRight className="next-icon" size={64} />
                  }
                </Fragment>
              )
            })
          }
        </Steps>
      </Wrapper>
    )
  }
}
