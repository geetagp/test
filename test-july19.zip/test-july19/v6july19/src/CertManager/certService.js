const buildCertApiUrl = host => `https://${host}/api/v3/epaas/certificates`;

export const fetchCerts = async ({token, host}) => {
  // const url = buildCertApiUrl(host);
  // const apiHost = host === 'e1bluecloud.aexp.com' ? 'e1qastg-v3.aexp.com' : host;
  const apiHost = host === 'e1cloud.aexp.com' ? 'e1bluecloud-v3.aexp.com' : 'e1qastg-v3.aexp.com';
  const url = buildCertApiUrl(apiHost);

  return new Promise(async (res, rej) => {
  
    return await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      }
    })
      .then(res => res.json())
      .then(data => !data.data || data.status === 'error' ? res([JSON.parse(data.message)]) : res(data.data))
      .catch(err => rej(err));

  })
}

export const updateCerts = async ({certs, host, token}) => {
  // const apiHost = host === 'e1bluecloud.aexp.com' ? 'e1qastg-v3.aexp.com' : host;
  const apiHost = host === 'e1cloud.aexp.com' ? 'e1bluecloud-v3.aexp.com' : 'e1qastg-v3.aexp.com';
  const url = buildCertApiUrl(apiHost);
  
    return await fetch(url, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({data: certs}),
    })
      .then(res => res.json())
      .then(data => !data.data || data.status === 'error' ? [] : data.data)
      .catch(err => []);

}
