"use strict"
import React from 'react';
import {Row, Col, Well, Button, Table, FormControl, FormGroup, ControlLabel, Pagination, Modal } from 'react-bootstrap';
import {findDOMNode} from 'react-dom';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {getNodes} from '../../actions/nodesActions';

class Nodes extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            nodes: [],
            showModal: false
        };
        //this.searchTable = this.searchTable.bind(this);
        //this.open = this.open.bind(this);
    }

    open(node) {
        this.setState({
            nodes: this.state.nodes,
            showModal:true,
            name:node.name
        });
    }

    close() {
        this.setState({
            nodes: this.state.nodes,
            showModal:false
        });
    }

    componentDidMount() {
        if (this.state.showModal === false) {
            this.props.getNodes();
            this.setState({nodes: this.props.nodes}); //from mapStateToProps
        }
    }

    searchTable() {
        const searchString = findDOMNode(this.refs.search).value;
        const data = this.props.nodes.filter(function (node) {
            return node.name.toLowerCase().search(searchString.toLowerCase()) !== -1;
        });
        this.setState({nodes: data});
    }

    render() {
        return (
            <div id="nodes-table">
                <div>
                    <FormGroup controlId ='title'>
                        <ControlLabel>Hosts</ControlLabel>
                        <FormControl type='text'
                            placeholder='Search'
                            ref='search' onChange={this.searchTable.bind(this)}/>
                    </FormGroup>
                    <Table responsive className="table table-hover table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>name</th>
                                <th>role</th>
                                <th>ip</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.nodes.length === 0 ? '' : this.renderResultRows()}
                        </tbody>
                    </Table>
                </div>
                <div className ='pull-right'>
                    <Pagination
                        className={this.state.nodes.length === 0 ? 'hidden' : 'shown'}
                        prev
                        next
                        first
                        last
                        ellipsis
                        items={6}
                        activePage={this.state.activePage}
                        onSelect={this.handleSelect}>
                    </Pagination>
                </div>

                <Modal show={this.state.showModal} onHide={this.close.bind(this)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Host </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <h6> name: {this.state.name} </h6>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.close.bind(this)}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        );
    }

    renderResultRows = () => {
        return this.state.nodes.map((node, index) => {
            return (
                <tr key={index} data-item={node} >
                    <td data-title="Name" href='' onClick={this.open.bind(this, node)}> <u>{node.name}</u></td>
                    <td data-title="Role">{node.role}</td>
                    <td data-title="IP">{node.ip}</td>
                </tr>
            );
        });
    }
}

function mapStateToProps(state) {
    return {
        nodes: state.nodes.nodes
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({getNodes: getNodes}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Nodes)
