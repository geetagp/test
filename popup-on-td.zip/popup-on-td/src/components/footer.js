// Component: Footer
// Author : Gita
// This is display only component, that forms the footer of single page app

'use strict'
import React from 'react';

class Footer extends React.Component {
    render() {
        return (
            <footer className='footer text-center'>
                <div className='container'>
                    <p className='footer-text'> 2017 American Express Company. All Rights Reserved.</p>
                </div>
            </footer>
        );
    }
}
export default Footer
