// Gita : define actions for nodes

'use strict'

// Get nodes
export function getNodes()  {
    return {
        type:"GET_NODES",
    }
}


//****** api calls to be implemeted ******// **** also will need api.js to set up base url*********/////
//***** needs axios (http client , supports promise and allows to write xml http request)
//***** and redux-thunk (for asyc action dispatch)
/*
import axios from 'axios';
// GET NODES
export function getNodes(){
  return function(dispatch){
    axios.get("/api/nodes")
      .then(function(response){
        dispatch({type:"GET_NODES", payload:response.data})
      })
      .catch(function(err){
        dispatch({type:"GET_NODES_REJECTED", payload:err})
      })
  }
}
*/
