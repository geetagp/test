// Gita : test helper code
import _$ from 'jquery';
import React from 'react';
import ReactDOM from 'react-dom';
import TestUtils from 'react-addons-test-utils';
import jsdom from 'jsdom';
import chai, { expect } from 'chai';
import chaiJquery from 'chai-jquery';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import reducers from '../src/reducers/index.js';

// Gita: Step 1 : set up testing environment to run like a browser in command line
// Gita : use jsdom to create fake document element
// Gita : create global window and navigator - check jsdom documentation for details
global.document = jsdom.jsdom('<!doctype html><html><body></body></html>');
global.window = global.document.defaultView;
global.navigator = global.window.navigator;
const $ = _$(window);  // Gita: tell jquery to look for window variable where it can find Dom. Otherwise it will try to reach somewhere and will fail

// Gita : Step 4 : set up chai-jquery
chaiJquery(chai, chai.util, $);

// Gita : Step 2 : build a renderComponent helper that should render a given react class
// renderIntoDocument works only if Dom is available - check test-utils documentation for details
// pass 1. class 2. props that will be used by component and 3. state of redux store  or app data
function renderComponent(ComponentClass, props = {}, state = {}) {
  // Gita: componentInstance constant holds the rendered version of the component
  // component needs reference to redux store
  const componentInstance =  TestUtils.renderIntoDocument(
    <Provider store={createStore(reducers, state)}>
      <ComponentClass {...props} />
    </Provider>
  );

  return $(ReactDOM.findDOMNode(componentInstance));  // Gita : produces html from the component instance ; wrap this html with jquery
  // Gita: the purpose of jquery is to utilize some handy functions
}

// Gita : Step 3 : build helper for simulating events
// add a method to jquery using $.fn.<function name>
// then every jquery instance craeted hereafter will have access to $.simulate
$.fn.simulate = function(eventName, value) {
  // get handle of html element using 'this'
  if (value) {
    this.val(value);
  }
  // use Tesutils.Simulate to simulate the event (eventname e.g onclick , onchange) on first html element (this[0])
  TestUtils.Simulate[eventName](this[0]);
};

export {renderComponent, expect};
