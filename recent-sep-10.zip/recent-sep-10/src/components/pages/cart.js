// Component: Cart
// Author : Gita
// Cart component displays items in cart
// dispatches deleteCartItem and updateCart actions

"use strict"
import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {deleteCartItem,updateCart} from '../../actions/cartActions';
import {Modal, ButtonGroup, Label, Panel, Col, Row, Well, Button} from 'react-bootstrap';


class Cart extends React.Component{
    constructor(props){
        super(props);
        this.state = {showModal:false};
        this.open = this.open.bind(this);
    }
    open(){
        this.setState({showModal:true});
    }
    close(){
        this.setState({showModal:false});
    }
    onDelete(_id){
        // Create copy of current array of books
        const currentBookToDelete = this.props.cart;

        // find the index of the book to be deleted
        const indexToDelete = currentBookToDelete.findIndex(
            function(cart){
                return cart._id = _id;
            }
        )
        // Gita: cart after delete is still a array of books, since cart size can be great than 1
        let cartAfterDelete =  [...currentBookToDelete.slice(0,indexToDelete) , ...currentBookToDelete.slice(indexToDelete + 1)];
        this.props.deleteCartItem(cartAfterDelete) ; // Gita : dispatch delete cart item

    }
    onIncrement(_id){
        this.props.updateCart(_id, 1);
    }

    onDecrement(_id, quantity){
        if(quantity > 1){
            this.props.updateCart(_id, -1);
        }
    }

    // Gita : check if cart is empty, if yes render empty div else render cart
    render(){
        if(this.props.cart[0]) {
            return this.renderCart();
        } else {
            return this.renderEmpty();
        }
    }
    renderEmpty(){
            return(<div></div>)
    }
    renderCart(){
        const cartItemsList = this.props.cart.map(function(cartArr){
            return(
                <Panel key={cartArr._id}>
                <Row>
                    <Col xs={12} sm={4}>
                        <h6>{cartArr.title}</h6><span>    </span>
                    </Col>
                    <Col xs={12} sm={2}>
                        <h6>usd. {cartArr.price}</h6>
                    </Col>
                    <Col xs={12} sm={2}>
                        <h6>qty. <Label bsStyle="success">{cartArr.quantity}</Label></h6>
                    </Col>
                    <Col xs={6} sm={4}>
                        <ButtonGroup>
                            <Button  onClick={this.onDecrement.bind(this, cartArr._id, cartArr.quantity)} bsStyle="default" bsSize="small">-</Button>
                            <Button onClick={this.onIncrement.bind(this, cartArr._id)}  bsStyle="default" bsSize="small">+</Button>
                            <span>     </span>
                            <Button bsStyle="danger" onClick={this.onDelete.bind(this, cartArr._id)} bsSize="small">DELETE</Button>
                        </ButtonGroup>
                    </Col>

                </Row>
                </Panel> )
        },this)
        return(
            <Panel header="Cart" bsStyle="primary">
                {cartItemsList}
                <Row>
                    <Col xs={12}>
                        <h6> Total Amount: $ {this.props.totalAmount}</h6>
                        <Button bsStyle='success' onClick={this.open.bind(this)}  bsSize='small'>PROCEED TO CHECKOUT </Button>
                    </Col>
                </Row>

                <Modal show={this.state.showModal} onHide={this.close.bind(this)}>
                    <Modal.Header closeButton>
                    <Modal.Title>Thank Tou ! </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                    <h6> Your order has been saved. </h6>
                    <p> You will recieve an email confirmation. </p>
                    </Modal.Body>
                    <Modal.Footer>
                    <Button onClick={this.close.bind(this)}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </Panel>
        )
    }
}

function mapStateToProps(state){
  return{
    cart: state.cart.cart,
    totalAmount: state.cart.totalAmount
  }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({deleteCartItem,updateCart}, dispatch);
}

export default connect(mapStateToProps,mapDispatchToProps)(Cart);
