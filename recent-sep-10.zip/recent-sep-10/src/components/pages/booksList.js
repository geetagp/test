// Component: BookList
// Author : Gita
// BookList component displays differrent books as a list of BookItem component. Also displays a form BooksForm to add /delete books in the shop
// dispatches getBooks action

"use strict"
import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux'; // to dispatch action from react component
import {getBooks} from '../../actions/booksActions'; // to dispatch action from react component
import {Grid,Col,Row,Button} from 'react-bootstrap';  // import styling lib
import BookItem from './bookItem'; //recieves props from BookList component and is displayed as list of components
import BooksForm from './booksForm';
import Cart from './cart';


// Gita: Import connect and use connect(mapStateToProps) in component to subscribe to the store to get the current state of app to be used in local component
class BooksList extends React.Component{

    componentDidMount(){
        // Gita : Dispath action to get books to get default list of books
        // e.g when component mounts , display default content for books from store
        this.props.getBooks();
    }

    render() {
        //console.log("are we accessing the state in BookList component ?", this.props.books); // Gita : check if component is connected to redux and is recieving state from store.
        // Gita: multiple rows display - create bookList that will be used in render return ()
        const booksList = this.props.books.map(function(booksArr){
            return(
                <Col xs={12} sm={6} md={4} key={booksArr._id}>
                    <BookItem _id={booksArr._id} title={booksArr.title} description={booksArr.description} price={booksArr.price} />
                </Col>
        )})

        // Gita : return for rendor()
        // BooksForm is a component that is imported directly
        // booksList is a list of components that is created after importing the compoent BookItem
        return (
            <Grid>
                <Row>
                    <Cart/>
                </Row>
                <Row>
                    <Col xs={12} sm={6}>
                        <BooksForm/>
                    </Col>
                    {booksList}
                </Row>
            </Grid>
        )
    }
}

// Gita :to pass state from store to component
function mapStateToProps(state){
    return{
        books: state.books.books  //Gita : why books.books ? - store has books object that has books array as initial value - change this obj/array name, if needed
    }
}

// Gita: to dispatch action from react component
function mapDispatchToProps(dispatch){
    // Gita : pre-binding the action creators to redux store
    return bindActionCreators({getBooks: getBooks}, dispatch);
}
// Gita: export with connect for access for state props and dispatch
// this is where react component gets connected to redux store
export default connect(mapStateToProps, mapDispatchToProps)(BooksList)
